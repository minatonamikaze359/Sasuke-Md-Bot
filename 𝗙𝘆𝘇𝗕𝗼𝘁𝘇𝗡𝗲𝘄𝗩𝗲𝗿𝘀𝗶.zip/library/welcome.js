/* 

   </> 𝗙𝘆𝘇𝘇𝗕𝗼𝘁𝘇𝘇 𝗕𝘆 𝗙𝘆𝘇𝘇𝗢𝗳𝗳𝗰𝗶𝗮𝗹 </>
   
   Buy Script no Enc: 
   - Telegram (t.me/FixzzCok)
   - Whatsapp ( https://wa.me/6281313532320 ) 
   
   Follow Channel Developer:
   - FyzzOffcial ( https://whatsapp.com/channel/0029VbBFQNb17En3MAIHaU3R ) 
   
   # Penting
   Jangan hapus credits atau nama developer
   hargai pembuat script ini!

*/

const canvafy = require("canvafy")

async function welcomeBanner(avatar, name, subject, type) {
    const title = name
    const desc = (type == "welcome" ? "Selamat datang di " : "Telah keluar dari grup ") + subject
    const background = "https://img101.pixhost.to/images/642/557922982_skyzopedia.jpg"
    const welcome = await new canvafy.WelcomeLeave()
    .setAvatar(avatar)
    .setBackground("image", background)
    .setTitle(title.length > 20 ? (title.substring(0, 16) + "..") : title)
    .setDescription(desc.length > 70 ? (desc.substring(0, 65) + "..") : desc)
    .setBorder("#2a2e35")
    .setAvatarBorder("#2a2e35")
    .setOverlayOpacity(0.1)
    .build()
    return welcome
}

async function promoteBanner(avatar, name, type) {
    const title = name
    const desc = type == "promote" ? "Telah menjadi admin" : "Telah di berhentikan menjadi admin"
    const background = "https://img101.pixhost.to/images/642/557922982_skyzopedia.jpg"
    const welcome = await new canvafy.WelcomeLeave()
    .setAvatar(avatar)
    .setBackground("image", background)
    .setTitle(title.length > 20 ? (title.substring(0, 16) + "..") : title)
    .setDescription(desc.length > 70 ? (desc.substring(0, 65) + "..") : desc)
    .setBorder("#2a2e35")
    .setAvatarBorder("#2a2e35")
    .setOverlayOpacity(0.1)
    .build()
    return welcome
}

module.exports = { welcomeBanner, promoteBanner }
      
